import asyncio, os, pathlib, sys
sys.dont_write_bytecode = True
allowed = {'PATH', 'HOME', 'USER', 'LOGNAME', 'LANG', 'LC_ALL', 'TMPDIR', 'SHELL', 'SSL_CERT_FILE', 'SSL_CERT_DIR'}
environment = {key: value for key, value in os.environ.items() if key in allowed}
os.environ.clear(); os.environ.update(environment)
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from launchkit.deployment_worker import run
sys.exit(asyncio.run(run(pathlib.Path(sys.argv[1]), 'service')) or 0)
