"""Source-bound wizard admission and observation for a chosen SSH destination."""
from __future__ import annotations

import asyncio
import base64
from contextlib import contextmanager
from copy import deepcopy
import fcntl
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile
import time
import uuid
import zlib

from .artifact_binding import package_matches, proposal_hash
from .deployment import (MAX_PACKAGE_BYTES, package_files, package_configuration_fields, package_console_scope,
                         prepare_private_settings, require_accepted, now)
from .deployment_ports import checked_console_port
from .projects import DraftConflict
from .ssh_transport import SshTransport, SshTransportError, validate_endpoint
from .remote_browser_access import RemoteBrowserAccessService
from .application_access import application_observation
from .remote_destination import connection_prerequisites

PROTOCOL = 1
HASH = re.compile(r"[a-f0-9]{64}")
FINGERPRINT = re.compile(r"SHA256:[A-Za-z0-9+/]{20,90}={0,2}")
ACTIVE = {"connecting", "installing", "checking", "starting", "running", "stopping", "restarting", "recovery-needed"}
PRIVATE_COMPONENTS = {".env", ".venv", ".bin", ".mobkit", ".git", "__pycache__", ".source"}
PRIVATE_ROOTS = {"data", "workspace", "source"}
NEEDED = {"remote_operations.py", "setup.py", "install.sh", "application_configuration.py", "mcp_connections.py"}
MAX_CONTROLLER = 512 * 1024


def source_archive(files):
    """Transfer only declared public package source; preserve the independent ZIP binding."""
    selected = {name: entry for name, entry in files.items()
                if name != "SHA256SUMS" and not PRIVATE_COMPONENTS.intersection(name.split("/"))
                and name.split("/")[0] not in PRIVATE_ROOTS and not name.endswith(".receipt.json")}
    digest = hashlib.sha256()
    rows = []
    for name, (content, _) in sorted(selected.items()):
        hashed = hashlib.sha256(content).hexdigest()
        digest.update(name.encode() + b"\0" + bytes.fromhex(hashed))
        rows.append(hashed + "  " + name + "\n")
    output = io.BytesIO()
    # Destination custody pins the actual archive bytes as well as its source
    # digest. A later transfer of the same accepted package must not gain a new
    # gzip timestamp and look like changed source.
    with gzip.GzipFile(fileobj=output, mode="wb", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w:") as archive:
            for name, (content, mode) in sorted({**selected, "SHA256SUMS": ("".join(rows).encode(), 0o644)}.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(content), mode, 0
                archive.addfile(info, io.BytesIO(content))
    return output.getvalue(), digest.hexdigest()


def private_file(path, maximum=MAX_PACKAGE_BYTES):
    path = Path(path)
    if any(item.is_symlink() for item in (path, *path.parents)):
        raise DraftConflict("The owned remote installation record contains a link. No remote action was taken.")
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(descriptor, "rb") as stream:
        info = os.fstat(stream.fileno())
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_nlink != 1
                or info.st_mode & 0o077 or info.st_size > maximum):
            raise DraftConflict("The owned remote installation record is not private or ordinary.")
        return stream.read(maximum + 1)


def write_bytes(path, content):
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(descriptor, "wb") as stream:
        stream.write(content)
        stream.flush()
        os.fsync(stream.fileno())


def read_receipt(directory):
    return json.loads(private_file(Path(directory) / "receipt.json", 256 * 1024))


def write_private(path, value):
    path = Path(path)
    if any(item.is_symlink() for item in (path, *path.parents)):
        raise DraftConflict("The owned remote installation record contains a link.")
    if path.exists():
        private_file(path, 256 * 1024)
    temporary = path.parent / ("." + path.name + "." + uuid.uuid4().hex + ".pending")
    try:
        write_bytes(temporary, (json.dumps(value, indent=2, allow_nan=False) + "\n").encode())
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


@contextmanager
def receipt_lock(directory):
    path = Path(directory) / "journal.lock"
    if any(item.is_symlink() for item in (path, *path.parents)):
        raise DraftConflict("The owned remote installation lock contains a link.")
    descriptor = os.open(path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        info = os.fstat(descriptor)
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                or info.st_nlink != 1 or info.st_mode & 0o077):
            raise DraftConflict("The remote installation lock is not private and owned.")
        fcntl.flock(descriptor, fcntl.LOCK_EX)
        yield
    finally:
        os.close(descriptor)


def update_receipt(directory, **changes):
    with receipt_lock(directory):
        value = read_receipt(directory)
        value.update(changes, updated_at=now())
        write_private(Path(directory) / "receipt.json", value)
        return value


def journal(directory, message, **changes):
    with receipt_lock(directory):
        value = read_receipt(directory)
        progress = [*value.get("progress", []), {"at": now(), "message": message}][-100:]
        value.update(changes, updated_at=now(), progress=progress, detail=message)
        write_private(Path(directory) / "receipt.json", value)
        return value


def destination_input(value):
    if (not isinstance(value, str) or not value.strip() or len(value) > 2000
            or any(ord(char) < 32 or ord(char) == 127 for char in value)):
        raise ValueError("Choose a project folder on the Linux computer.")
    value = value.strip()
    if not value.startswith(("/", "~/")) or str(PurePosixPath(value)) in {"/", "~"}:
        raise ValueError("Use a project folder such as ~/src/my-team on the Linux computer.")
    if ".." in PurePosixPath(value).parts:
        raise ValueError("Choose a project folder without parent-directory traversal.")
    return value


def binding(receipt):
    return {key: receipt[key] for key in ("guide_id", "guide_version", "build_id", "accepted_source_digest",
            "package_sha256", "transferred_source_digest", "controller_sha256")}


def operation_identity(value):
    try:
        return isinstance(value, str) and str(uuid.UUID(value)) == value
    except (ValueError, AttributeError):
        return False


def retry_observed(receipt):
    """A failed attempt can be replaced only from joined destination evidence."""
    pending = receipt.get("pending_operation")
    service = receipt.get("service")
    if not isinstance(service, dict) or pending is not None and not isinstance(pending, dict):
        return False
    stopped_service = service.get("status") == "not-installed" or (
        receipt.get("service_owned") is True and service.get("status") in {"inactive", "failed"}
        and service.get("quiescent") is True)
    return (receipt.get("status") == "failed" and receipt.get("remote_admission_requested") is True
        and receipt.get("admitted") is True and receipt.get("retryable") is True
        and operation_identity(receipt.get("operation_id"))
        and receipt.get("retry_of_operation_id") == receipt["operation_id"]
        and receipt.get("worker_live") is False and receipt.get("cleanup_confirmed") is True
        and receipt.get("source_current") is True and receipt.get("service_observed") is True
        and stopped_service and (not pending or pending.get("action") == "retry-install"
            and pending.get("previous_operation_id") == receipt["operation_id"]))


def controller_program(content):
    # Bundled canonical helpers grow the immutable controller. Compress its
    # exact bytes so the isolated Python argument stays below Linux limits.
    encoded = base64.b64encode(zlib.compress(content, level=9)).decode("ascii")
    expected = hashlib.sha256(content).hexdigest()
    return ("import base64,hashlib,zlib; s=zlib.decompress(base64.b64decode(" + repr(encoded) + ")); "
            "assert hashlib.sha256(s).hexdigest()==" + repr(expected) + "; "
            "exec(compile(s,'<mobkit-remote-controller>','exec'),"
            "{'__name__':'__main__','CONTROLLER_SOURCE':s})")


class RemoteDeploymentService:
    def __init__(self, root, guide, implementation, local_deployment, *, transport=None, cloud_transport=None):
        self.root = Path(root) / "remote-installations"
        self.guide, self.implementation, self.local = guide, implementation, local_deployment
        self.transport = transport or SshTransport()
        self.cloud_transport = cloud_transport
        self.cloud_removal_status = None
        self.lock = asyncio.Lock()
        self.observation_locks = {}
        self.tasks = {}
        self.last_observed = {}
        self.browser_access = RemoteBrowserAccessService(self)

    async def cloud_status(self, receipt):
        if receipt.get("target") != "gcp" or self.cloud_removal_status is None:
            return None
        try:
            value = await self.cloud_removal_status(receipt["endpoint"])
            if value is not None and value not in {"removing", "removal-required", "removed"}:
                raise ValueError()
            return value
        except (ValueError, LookupError, OSError, RuntimeError, TypeError, KeyError):
            raise DraftConflict("The original cloud removal state could not be verified. No remote connection was requested.") from None

    async def require_cloud_available(self, receipt):
        if await self.cloud_status(receipt) is not None:
            raise DraftConflict("Cloud resource removal has been requested. This installation cannot admit another remote operation.")

    async def prepare_cloud_removal(self, value):
        """Join local custody only; deleting the VM can end destination-owned work."""
        from .gcp_transport import validate_gcp_endpoint
        try:
            guide_id, operation_id = value["guide_id"], value["operation_id"]
            if not operation_identity(guide_id) or not operation_identity(operation_id):
                raise ValueError()
            endpoint = value.get("endpoint")
            if endpoint is not None:
                endpoint = validate_gcp_endpoint(endpoint)
                destination = value["destination"]
                if (endpoint["operation_id"] != operation_id or endpoint["account"] != value["account"]
                        or endpoint["ownership_token"] != value["ownership_token"]
                        or endpoint["instance_id"] != value["resources"]["vm"]["id"]
                        or any(endpoint[key] != destination[key] for key in ("project", "zone", "instance"))):
                    raise ValueError()
        except (SshTransportError, ValueError, KeyError, TypeError, AttributeError):
            raise DraftConflict("The original cloud removal destination could not be joined to its saved installation.") from None
        async with self.lock:
            parent = self.root / guide_id
            if any(path.is_symlink() for path in (parent, *parent.parents)):
                raise DraftConflict("The saved remote installation inventory contains a link.")
            if not parent.exists():
                return True
            for index, directory in enumerate(parent.iterdir()):
                if index >= 1024:
                    raise DraftConflict("The saved remote installation inventory exceeds its bound.")
                if directory.name == "latest.json":
                    continue
                if directory.is_symlink() or not directory.is_dir() or not operation_identity(directory.name):
                    raise DraftConflict("The saved remote installation inventory could not be verified.")
                receipt = read_receipt(directory)
                if not isinstance(receipt, dict):
                    raise DraftConflict("The saved remote installation receipt could not be verified.")
                selected = receipt.get("endpoint")
                if receipt.get("target") == "gcp" and not isinstance(selected, dict):
                    raise DraftConflict("The saved cloud installation has no verified original endpoint.")
                if (not isinstance(selected, dict) or selected.get("operation_id") != operation_id) and receipt.get("cloud_operation_id") != operation_id:
                    continue
                if receipt.get("target") != "gcp":
                    raise DraftConflict("The saved cloud installation has a different destination type.")
                _, receipt = self.stored(guide_id, directory.name)
                if endpoint is None or receipt.get("endpoint") != endpoint or receipt.get("cloud_operation_id") != operation_id:
                    raise DraftConflict("The saved remote installation belongs to a different cloud removal destination.")
                task = self.tasks.get(directory.name)
                if task is not None:
                    # Local SSH observation owns its cleanup until it returns.
                    # Its destination worker/operation receipt remains historical.
                    await asyncio.shield(task)
                async with self.operation_lock(directory):
                    _, receipt = self.stored(guide_id, directory.name)
                    if receipt.get("endpoint") != endpoint or receipt.get("cloud_operation_id") != operation_id:
                        raise DraftConflict("The saved cloud installation changed during removal coordination.")
                    closed = await self.browser_access.revoke(guide_id, directory.name,
                        "Browser access is closed because this cloud computer is being removed.")
                    key = self.browser_access.key(guide_id, directory.name)
                    if closed.get("cleanup_confirmed") is not True or any(
                            self.browser_access.public(candidate).get("cleanup_confirmed") is not True
                            for candidate in self.browser_access.deployment_keys(key)):
                        raise DraftConflict("The local browser connection has not confirmed cleanup. Close it again before cloud removal.")
            return True

    def directory(self, guide_id, deployment_id=None):
        try:
            if str(uuid.UUID(guide_id)) != guide_id:
                raise ValueError
            parent = self.root / guide_id
            if deployment_id is None:
                deployment_id = json.loads(private_file(parent / "latest.json", 4096))["deployment_id"]
            if str(uuid.UUID(deployment_id)) != deployment_id:
                raise ValueError
        except FileNotFoundError:
            raise LookupError("No remote installation is selected for this setup.") from None
        except (ValueError, KeyError, TypeError):
            raise ValueError("Choose an exact owned remote installation.") from None
        return parent / deployment_id

    def stored(self, guide_id, deployment_id=None):
        directory = self.directory(guide_id, deployment_id)
        receipt = json.loads(private_file(directory / "receipt.json", 256 * 1024))
        if receipt.get("guide_id") != guide_id or receipt.get("deployment_id") != directory.name:
            raise DraftConflict("The remote installation ownership changed. No remote action was taken.")
        self.frozen(directory, receipt)
        return directory, receipt

    def frozen(self, directory, receipt):
        payload = private_file(directory / "package.zip")
        content = private_file(directory / "controller.py", MAX_CONTROLLER)
        if (hashlib.sha256(payload).hexdigest() != receipt["package_sha256"]
                or hashlib.sha256(content).hexdigest() != receipt["controller_sha256"]):
            raise DraftConflict("The owned remote package or controller changed. Preserve this installation and inspect its source.")
        files = package_files(payload)
        archive, digest = source_archive(files)
        if digest != receipt["transferred_source_digest"]:
            raise DraftConflict("The owned remote source manifest changed. No remote action was taken.")
        return files, archive, content

    async def accepted(self, guide_id, version, build_id, *, target="linux"):
        state = await self.local._guide(guide_id)
        if state["version"] != version or (state.get("operation") or {}).get("status") == "running":
            raise DraftConflict("The guide changed. Connect or install only its current accepted application.")
        if target not in {"linux", "gcp"} or (state.get("proposal") or state.get("blueprint") or {}).get("target") != target:
            raise DraftConflict("Connect only the accepted application's chosen destination.")
        checked = await self.implementation.status(guide_id)
        require_accepted(checked)
        if (checked["build_id"] != build_id or not checked.get("current") or not checked.get("ready_to_package")
                or checked["guide_version"] != version or not HASH.fullmatch(checked.get("source_digest", ""))):
            raise DraftConflict("Build and accept the current application before connecting its destination.")
        payload, slug = await self.implementation.package(guide_id, build_id)
        files = package_files(payload)
        spec = json.loads(files["deployment.json"][0])
        report = json.loads(files["implementation-report.json"][0])
        if (report.get("build_id") != build_id or not package_matches(report, state)
                or report.get("verification", {}).get("digest") != checked["source_digest"]
                or report.get("blueprint_hash") != proposal_hash(state.get("proposal") or state.get("blueprint"))
                or spec.get("target") != target):
            raise DraftConflict("The accepted package differs from this proposal or application source.")
        if not NEEDED.issubset(files):
            raise DraftConflict("This accepted package lacks guided Linux setup support. Continue implementation before deploying it.")
        fields = package_configuration_fields(spec, files)
        return {"state": state, "checked": checked, "payload": payload, "files": files,
                "spec": spec, "fields": fields, "slug": slug,
                "console_scope": package_console_scope(files, fields, state)}

    async def current(self, receipt):
        try:
            selected = await self.accepted(receipt["guide_id"], receipt["guide_version"], receipt["build_id"], target=receipt.get("target", "linux"))
            return (selected["checked"]["source_digest"] == receipt["accepted_source_digest"]
                    and hashlib.sha256(selected["payload"]).hexdigest() == receipt["package_sha256"])
        except (ValueError, LookupError):
            return False

    async def connect(self, guide_id, version, build_id, host, user, ssh_port=22, destination=""):
        try:
            endpoint = validate_endpoint({"host": host, "user": user, "ssh_port": ssh_port})
        except SshTransportError:
            raise ValueError("Enter a computer address, SSH user and valid SSH port.") from None
        return await self._connect(guide_id, version, build_id, endpoint, destination)

    async def connect_cloud(self, guide_id, version, build_id, cloud):
        if (self.cloud_transport is None or not isinstance(cloud, dict) or cloud.get("status") != "vm-ready"
                or cloud.get("vm_verified") is not True or cloud.get("guide_id") != guide_id):
            raise DraftConflict("Verify the owned cloud computer before connecting its application.")
        from .gcp_transport import validate_gcp_endpoint
        try:
            endpoint = validate_gcp_endpoint(cloud.get("endpoint"))
        except SshTransportError:
            raise DraftConflict("The owned cloud computer has invalid connection evidence.") from None
        destination = cloud.get("destination")
        if (not isinstance(destination, dict) or cloud.get("operation_id") != endpoint["operation_id"]
                or any(destination.get(key) != endpoint[key] for key in ("project", "zone", "instance"))
                or "account" in cloud and cloud["account"] != endpoint["account"]):
            raise DraftConflict("The cloud operation and computer do not match.")
        await self.require_cloud_available({"target": "gcp", "endpoint": endpoint})
        if await self.cloud_transport.verify(endpoint) != endpoint:
            raise DraftConflict("The cloud computer identity changed. No destination was reserved.")
        return await self._connect(guide_id, version, build_id, endpoint,
            "~/src/" + cloud["destination"]["instance"], cloud=cloud)

    def browser_transport(self, receipt):
        if receipt.get("target") == "gcp":
            if self.cloud_transport is None:
                raise DraftConflict("The owned cloud transport is unavailable.")
            return self.cloud_transport
        select = getattr(self.transport, "browser_transport", None)
        if callable(select):
            return select(receipt["endpoint"])
        return None

    async def _connect(self, guide_id, version, build_id, endpoint, destination, *, cloud=None):
        destination = destination_input(destination)
        target = "gcp" if cloud is not None else "linux"
        async with self.lock:
            await self.require_cloud_available({"target": target, "endpoint": endpoint})
            selected = await self.accepted(guide_id, version, build_id, target=target)
            if cloud is not None:
                expected = {"guide_id": guide_id, "guide_version": version, "build_id": build_id,
                    "blueprint_hash": proposal_hash(selected["state"].get("proposal") or selected["state"].get("blueprint")),
                    "source_digest": selected["checked"]["source_digest"], "package_sha256": hashlib.sha256(selected["payload"]).hexdigest()}
                proposal = selected["state"].get("proposal") or selected["state"].get("blueprint")
                if (cloud.get("binding") != expected or endpoint != cloud.get("endpoint")
                        or endpoint.get("project") != proposal.get("gcp", {}).get("project")
                        or endpoint.get("zone") != proposal.get("gcp", {}).get("zone")
                        or endpoint.get("instance") != selected["spec"]["slug"]):
                    raise DraftConflict("The cloud computer belongs to another accepted package or destination.")
                if await self.cloud_transport.verify(endpoint) != endpoint:
                    raise DraftConflict("The cloud computer identity changed. No destination was reserved.")
            previous = None
            try:
                directory, previous = self.stored(guide_id)
            except LookupError:
                pass
            same = previous and previous["endpoint"] == endpoint and previous["destination_input"] == destination and (
                previous["build_id"] == build_id and previous["accepted_source_digest"] == selected["checked"]["source_digest"])
            safe_previous = previous and ((previous["status"] == "stopped" and previous.get("worker_live") is False)
                or (previous["status"] == "not-installed" and previous.get("admitted") is False))
            if previous and (previous["status"] in ACTIVE or previous["status"] == "observation-unavailable"
                    or previous.get("remote_admission_requested") and not safe_previous):
                if same:
                    return self.public(previous, current=await self.current(previous))
                raise DraftConflict("Stop and verify the current remote installation before choosing another destination.")
            if same:
                self.start_task(directory, "preflight")
                return self.public(read_receipt(directory), current=True)
            identity = str(uuid.uuid4())
            if any(item.is_symlink() for item in (self.root, *self.root.parents)):
                raise DraftConflict("The owned remote installation store contains a link.")
            self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
            for folder in (self.root, self.root / guide_id):
                folder.mkdir(exist_ok=True, mode=0o700)
                info = folder.lstat()
                if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid():
                    raise DraftConflict("The remote installation store is not an owned directory.")
                folder.chmod(0o700)
            directory = self.root / guide_id / identity
            directory.mkdir(parents=True, mode=0o700)
            directory.parent.chmod(0o700)
            from .remote_interface_bundle import controller_bytes
            controller = controller_bytes()
            _, transferred = source_archive(selected["files"])
            receipt = {"protocol": PROTOCOL, "deployment_id": identity, "guide_id": guide_id,
                "guide_version": version, "build_id": build_id,
                "accepted_source_digest": selected["checked"]["source_digest"],
                "package_sha256": hashlib.sha256(selected["payload"]).hexdigest(),
                "transferred_source_digest": transferred, "controller_sha256": hashlib.sha256(controller).hexdigest(),
                "endpoint": endpoint, "destination_input": destination, "destination": destination,
                "status": "connecting", "last_known_status": None, "created_at": now(), "updated_at": now(),
                "fields": selected["fields"], "console_scope": selected["console_scope"],
                "preflight": None, "progress": [], "checks": [],
                "scope": "native-bootstrap-and-console", "custom_interfaces_verified": False,
                "external_workflows_verified": False, "remote_admission_requested": False,
                "observation": {"available": False}, "detail": "Checking the chosen Linux computer through its existing trusted SSH connection."}
            write_bytes(directory / "package.zip", selected["payload"])
            write_bytes(directory / "controller.py", controller)
            if cloud is not None:
                receipt.update(target="gcp", cloud_operation_id=cloud["operation_id"],
                    detail="Checking the owned Google Cloud computer through its verified IAP SSH connection.")
            write_private(directory / "receipt.json", receipt)
            write_private(directory.parent / "latest.json", {"deployment_id": identity})
            self.start_task(directory, "preflight")
            return self.public(receipt, current=True)

    def start_task(self, directory, action):
        identity = directory.name
        if identity in self.tasks:
            return
        self.tasks[identity] = asyncio.create_task(self.probe(directory, action))
        def finished(task):
            self.tasks.pop(identity, None)
            if not task.cancelled():
                task.exception()  # Consume a failed observer without changing remote custody.
        self.tasks[identity].add_done_callback(finished)

    async def rpc(self, directory, receipt, action, **extra):
        await self.require_cloud_available(receipt)
        _, _, content = self.frozen(directory, receipt)
        body = {"action": action, "deployment_id": receipt["deployment_id"], "binding": binding(receipt),
                "destination": receipt["destination"], **extra}
        if receipt.get("host"):
            body["expected_host"] = {key: receipt["host"][key] for key in ("uid", "home", "destination")}
        transport = self.cloud_transport if receipt.get("target") == "gcp" else self.transport
        if transport is None:
            raise DraftConflict("The owned cloud transport is unavailable.")
        value = await transport.request(receipt["endpoint"], controller_program(content), body, timeout=30,
            expected_fingerprint=receipt.get("host_key_fingerprint"))
        observed = value.pop("_transport", {})
        fingerprint = observed.get("host_key_fingerprint")
        if not isinstance(fingerprint, str) or not FINGERPRINT.fullmatch(fingerprint):
            raise SshTransportError("invalid_response")
        if receipt.get("host_key_fingerprint") and receipt["host_key_fingerprint"] != fingerprint:
            raise DraftConflict("The SSH server identity changed. The existing installation is preserved; verify the destination before any action.")
        if (value.get("protocol") != PROTOCOL or value.get("deployment_id") != receipt["deployment_id"]
                or value.get("binding") != binding(receipt)):
            raise DraftConflict("The remote response belongs to another installation. Its result was not adopted.")
        return value, fingerprint

    def operation_lock(self, directory):
        return self.observation_locks.setdefault(directory.name, asyncio.Lock())

    async def probe(self, directory, action):
        async with self.operation_lock(directory):
            await self._probe(directory, action)

    async def _probe(self, directory, action):
        try:
            receipt = read_receipt(directory)
            if await self.cloud_status(receipt) is not None:
                return
            files, _, _ = self.frozen(directory, receipt)
            spec = json.loads(files["deployment.json"][0])
            value, fingerprint = await self.rpc(directory, receipt, action,
                **({"knowledge_mode": spec["knowledge"]["mode"], **connection_prerequisites(spec)}
                   if action == "preflight" else {}))
            if action == "preflight":
                if not await self.current(receipt):
                    journal(directory, "The application changed during the destination check. Rebuild or reconnect its current accepted source.", status="failed")
                    return
                host = value.get("host")
                if (not isinstance(host, dict) or type(host.get("uid")) is not int or host["uid"] < 0
                        or not isinstance(host.get("home"), str) or not host["home"].startswith("/")
                        or not isinstance(host.get("destination"), str) or not host["destination"].startswith("/")):
                    raise DraftConflict("The destination did not return its actual user and owned project folder.")
                if receipt.get("host") and any(host.get(key) != receipt["host"].get(key) for key in ("uid", "home", "destination")):
                    raise DraftConflict("The destination user or owned project folder changed. No private setup was sent.")
                if value.get("ready") is True:
                    try:
                        python = tuple(int(part) for part in host["python"].split(".")[:2])
                    except (KeyError, AttributeError, ValueError):
                        python = ()
                    if host.get("platform") != "linux" or python < (3, 11):
                        raise DraftConflict("Guided remote installation requires a verified Linux destination with Python 3.11 or newer.")
                status = "configuration-required" if value.get("ready") is True else "failed"
                journal(directory, "The destination checks passed. Enter private setup to install." if status == "configuration-required"
                    else "The destination needs attention. Resolve the failed checks, then check it again.",
                    status=status, preflight=value, host=host, destination=host["destination"],
                    host_key_fingerprint=fingerprint, checks=value.get("checks", []), observation={"available": True})
            else:
                self.adopt(directory, receipt, value)
            self.last_observed[directory.name] = time.monotonic()
        except (SshTransportError, TimeoutError, OSError) as error:
            self.unavailable(directory, error=error)
        except (ValueError, LookupError):
            journal(directory, "The remote installation response could not be joined to its owned source and destination. Preserve it and check the connection again.",
                    status="observation-unavailable", observation={"available": False})
        except asyncio.CancelledError:
            raise
        finally:
            self.last_observed[directory.name] = time.monotonic()

    def unavailable(self, directory, *, error=None):
        previous = read_receipt(directory)
        last = previous.get("last_known_status") if previous["status"] == "observation-unavailable" else previous["status"]
        update_receipt(directory, status="observation-unavailable", last_known_status=last,
            observation={"available": False}, detail=(str(error)
                if isinstance(error, SshTransportError) and error.code == "configuration_unavailable"
                else "The trusted SSH connection is unavailable. The destination may still be working; recheck this installation before retrying or stopping."))

    def adopt(self, directory, receipt, value, *, expected_operation=None):
        typed_observation = value.get("status") in {"failed", "recovery-needed"}
        if expected_operation and (not value.get("error") or typed_observation) and value.get("operation_id") != expected_operation:
            raise DraftConflict("The destination did not confirm this exact remote operation. Recheck its saved custody before retrying.")
        if value.get("error") and value.get("status") not in {"failed", "recovery-needed"}:
            error = value["error"]
            if not isinstance(error, dict) or not isinstance(error.get("code"), str) or len(error["code"]) > 100:
                raise DraftConflict("The destination did not return a recognized operation result.")
            update_receipt(directory, status="recovery-needed", last_known_status=receipt.get("last_known_status") or receipt["status"],
                observation={"available": True}, remote_error_code=error["code"],
                detail="The destination refused this operation. Preserve the installation and recheck its ownership and operation before retrying.")
            return
        allowed = {"configuration-required", "installing", "checking", "starting", "running", "stopping", "restarting", "stopped", "failed", "not-installed", "recovery-needed"}
        status = value.get("status")
        if status not in allowed:
            raise DraftConflict("The remote operation has no recognized authoritative state.")
        if status == "failed" and (value.get("cleanup_confirmed") is not True or value.get("worker_live") is not False):
            status = "recovery-needed"
        details = {key: value[key] for key in ("checks", "progress", "service", "worker_pid", "worker_live", "source_current", "ready", "detail", "phase", "operation_id", "admitted", "service_owned", "service_observed", "cleanup_confirmed") if key in value}
        # Capabilities and attempt ancestry never inherit from an older observation.
        details.update(retryable=value.get("retryable") is True,
            retry_of_operation_id=value.get("retry_of_operation_id"),
            previous_operation_id=value.get("previous_operation_id"),
            failure_phase=value.get("failure_phase"))
        details["ready"] = status == "running" and value.get("ready") is True and value.get("source_current") is True
        # Native access authority comes from this observation. An incomplete
        # response must not inherit a previous service or worker observation.
        details.update(service=value.get("service") if isinstance(value.get("service"), dict) else {},
            service_owned=value.get("service_owned") is True, service_observed=value.get("service_observed") is True,
            worker_live=value.get("worker_live") if type(value.get("worker_live")) is bool else None,
            source_current=value.get("source_current") is True, admitted=value.get("admitted") is True)
        from .remote_browser_access import console_port
        files, _, _ = self.frozen(directory, receipt)
        details["application_experiences"] = application_observation(files, receipt,
            value.get("application_experiences"), console_port(details["service"].get("console_url")))
        details.setdefault("detail", {
            "installing": "The destination admitted the accepted source and is preparing its dependencies and private runtime.",
            "checking": "The destination is running the accepted application's installation checks.",
            "starting": "The destination is checking startup of its owned native runtime and console.",
            "running": "The owned service is running. Native readiness, custom interfaces and external workflows have separate verification scopes.",
            "stopping": "The destination admitted an exact owned service stop. Recheck until its exit is observed.",
            "restarting": "The destination admitted a restart of the current accepted owned source.",
            "stopped": "The destination observed its owned service stopped. Its private configuration and data are preserved.",
            "failed": "The remote operation needs attention. Its observed service and worker custody remain visible below.",
            "not-installed": "The destination did not admit this installation. You can deliberately re-enter private setup and retry the same owned request.",
            "recovery-needed": "Remote ownership or worker cleanup needs inspection. Preserve this installation and recheck before starting replacement work.",
        }.get(status, "The destination returned its owned installation status."))
        if value.get("error"):
            error = value["error"]
            if not isinstance(error, dict) or not isinstance(error.get("code"), str) or len(error["code"]) > 100:
                raise DraftConflict("The destination did not return a recognized operation result.")
            details["remote_error_code"] = error["code"]
        pending = receipt.get("pending_operation")
        if pending is not None and not isinstance(pending, dict):
            raise DraftConflict("The saved remote operation custody is invalid. Preserve it before another action.")
        if pending and value.get("operation_id") == pending["id"] and value.get("worker_live") is False:
            details["pending_operation"] = None
        update_receipt(directory, **details, status=status, last_known_status=status,
            observation={"available": True})

    def public(self, receipt, *, current, cloud_status=None):
        value = deepcopy(receipt)
        value["source_binding_current"] = current
        observed = (value.get("observation") or {}).get("available") is True
        can_admit = (value["status"] == "configuration-required" and not value.get("remote_admission_requested")) or (
            value["status"] == "not-installed" and value.get("admitted") is False)
        value["can_install"] = current and observed and can_admit and (value.get("preflight") or {}).get("ready") is True
        value["can_retry_install"] = current and observed and retry_observed(value)
        controlled = observed and value.get("worker_live") is False and value.get("service_owned") is True and value.get("service_observed") is True
        value["can_stop"] = bool(value.get("remote_admission_requested")) and controlled and value["status"] not in {"stopped", "recovery-needed"}
        value["can_restart"] = current and controlled and value["status"] == "stopped" and value.get("source_current") is True
        if not value["can_install"] and not value["can_retry_install"]:
            value["fields"] = []
        if cloud_status is not None:
            value.update(cloud_status=cloud_status, ready=False, fields=[], can_install=False,
                can_retry_install=False, can_stop=False, can_restart=False,
                observation={"available": False},
                detail="Cloud resource removal is in progress. Application status is the last observed destination state."
                    if cloud_status == "removing" else
                    "Cloud resource removal needs attention. Application status is the last observed destination state."
                    if cloud_status == "removal-required" else
                    "The original cloud resources were removed. Application status is historical; no graceful service stop is claimed.")
        return value

    async def status(self, guide_id, *, force=False):
        directory, receipt = self.stored(guide_id)
        if await self.cloud_status(receipt) is None and receipt["deployment_id"] not in self.tasks and (force or time.monotonic() - self.last_observed.get(directory.name, -100) >= 3):
            async with self.operation_lock(directory):
                receipt = read_receipt(directory)
                if force or time.monotonic() - self.last_observed.get(directory.name, -100) >= 3:
                    await self._probe(directory, "status" if receipt.get("remote_admission_requested") else "preflight")
        receipt = read_receipt(directory)
        current = await self.current(receipt)
        value = self.public(receipt, current=current, cloud_status=await self.cloud_status(receipt))
        await self.browser_access.reconcile(value, current)
        return value

    async def install(self, guide_id, version, build_id, deployment_id, settings):
        async with self.lock:
            directory, receipt = self.stored(guide_id, deployment_id)
            async with self.operation_lock(directory):
                receipt = read_receipt(directory)
                await self.require_cloud_available(receipt)
                if self.directory(guide_id) != directory:
                    raise DraftConflict("Choose the selected remote installation before entering private setup.")
                selected = await self.accepted(guide_id, version, build_id, target=receipt.get("target", "linux"))
                if (receipt["guide_version"] != version or receipt["build_id"] != build_id
                        or receipt["accepted_source_digest"] != selected["checked"]["source_digest"]
                        or receipt["package_sha256"] != hashlib.sha256(selected["payload"]).hexdigest()):
                    raise DraftConflict("The application changed. Connect its current accepted source before installing.")
                retry = receipt.get("remote_admission_requested") and receipt["status"] == "not-installed" and receipt.get("admitted") is False
                if receipt.get("remote_admission_requested") and not retry:
                    await self._probe(directory, "status")
                    receipt = read_receipt(directory)
                    return self.public(receipt, current=await self.current(receipt))
                if not self.public(receipt, current=True)["can_install"]:
                    raise DraftConflict("Complete the exact destination check before private setup.")
                port = selected["spec"]["port"]
                if retry and "requested_console_port" in receipt:
                    port = checked_console_port(receipt["requested_console_port"])
                validator = directory / ("settings-validation-" + uuid.uuid4().hex)
                values = prepare_private_settings(validator, selected["fields"], settings, False,
                    port=port, console_authentication=selected["console_scope"]["authentication"])
                try:
                    await self._probe(directory, "preflight")
                    receipt = read_receipt(directory)
                    if receipt["status"] != "configuration-required" or not await self.current(receipt):
                        raise DraftConflict("The destination or application changed before installation. Check it again.")
                    _, archive, _ = self.frozen(directory, receipt)
                    operation_id = receipt.get("install_operation_id") or str(uuid.uuid4())
                    await self.require_cloud_available(receipt)
                    # Custody and nonsecret requested port intent are durable
                    # before SSH admission. Private values are not stored here.
                    journal(directory, "Sending the exact accepted package and private setup through the verified SSH connection.",
                        status="installing", remote_admission_requested=True, install_operation_id=operation_id,
                        requested_console_port=checked_console_port(int(values["MOBKIT_PORT"])),
                        pending_operation={"id": operation_id, "action": "install"})
                    receipt = read_receipt(directory)
                    try:
                        value, _ = await self.rpc(directory, receipt, "install", operation_id=operation_id,
                            archive=base64.b64encode(archive).decode("ascii"), settings=values)
                        self.adopt(directory, receipt, value, expected_operation=operation_id)
                    except (SshTransportError, TimeoutError, OSError, ValueError, LookupError) as error:
                        self.unavailable(directory, error=error)
                finally:
                    values.clear()
                receipt = read_receipt(directory)
                return self.public(receipt, current=await self.current(receipt))

    async def retry_install(self, guide_id, version, build_id, deployment_id, previous_operation_id, settings):
        if not operation_identity(previous_operation_id):
            raise ValueError("Choose the exact failed installation attempt before retrying.")
        async with self.lock:
            directory, receipt = self.stored(guide_id, deployment_id)
            async with self.operation_lock(directory):
                await self.require_cloud_available(receipt)
                if self.directory(guide_id) != directory:
                    raise DraftConflict("Choose the selected remote installation before retrying private setup.")
                selected = await self.accepted(guide_id, version, build_id, target=receipt.get("target", "linux"))
                if (receipt["guide_version"] != version or receipt["build_id"] != build_id
                        or receipt["accepted_source_digest"] != selected["checked"]["source_digest"]
                        or receipt["package_sha256"] != hashlib.sha256(selected["payload"]).hexdigest()):
                    raise DraftConflict("The application changed. Retry only its exact accepted installed source.")
                # A POST replay is an observation until the predecessor is proven
                # eligible now. It never turns an expired response into fresh work.
                await self._probe(directory, "status")
                receipt = read_receipt(directory)
                if receipt.get("operation_id") != previous_operation_id:
                    if (receipt.get("previous_operation_id") == previous_operation_id
                            and receipt.get("operation_id") == receipt.get("retry_install_operation_id")):
                        return self.public(receipt, current=await self.current(receipt))
                    raise DraftConflict("The failed attempt changed. Recheck its current owned status before retrying.")
                if not self.public(receipt, current=True)["can_retry_install"]:
                    raise DraftConflict("Retry needs a verified failed installer, completed cleanup and its unchanged accepted source.")
                pending = receipt.get("pending_operation")
                if pending and (pending.get("action") != "retry-install"
                        or pending.get("previous_operation_id") != previous_operation_id
                        or not operation_identity(pending.get("id"))):
                    raise DraftConflict("Recheck the pending remote operation before requesting another attempt.")
                # Refresh host identity and prerequisites without replacing the
                # failed attempt with an initial-setup projection.
                try:
                    checked, _ = await self.rpc(directory, receipt, "preflight",
                        knowledge_mode=selected["spec"]["knowledge"]["mode"],
                        **connection_prerequisites(selected["spec"]))
                except (SshTransportError, TimeoutError, OSError) as error:
                    self.unavailable(directory, error=error)
                    receipt = read_receipt(directory)
                    return self.public(receipt, current=await self.current(receipt))
                host = checked.get("host")
                if (not isinstance(host, dict) or any(host.get(key) != receipt["host"].get(key)
                        for key in ("uid", "home", "destination"))):
                    raise DraftConflict("The destination identity changed. No private retry settings were sent.")
                try:
                    python = tuple(int(part) for part in host["python"].split(".")[:2])
                except (KeyError, AttributeError, ValueError):
                    python = ()
                if host.get("platform") != "linux" or python < (3, 11):
                    raise DraftConflict("Retry requires the same verified Linux destination with Python 3.11 or newer.")
                update_receipt(directory, retry_checks=checked.get("checks", []),
                    retry_preflight_ready=checked.get("ready") is True)
                if checked.get("ready") is not True or not await self.current(receipt):
                    raise DraftConflict("The destination or accepted source needs attention before another installation attempt.")
                validator = directory / ("settings-validation-" + uuid.uuid4().hex)
                values = prepare_private_settings(validator, selected["fields"], settings, False,
                    port=selected["spec"]["port"], console_authentication=selected["console_scope"]["authentication"])
                requested_port = {}
                if settings.get("MOBKIT_PORT"):
                    requested_port["requested_console_port"] = checked_console_port(int(values["MOBKIT_PORT"]))
                else:
                    # An admitted installation's private .env remains the
                    # authority unless this retry explicitly replaces its port.
                    values.pop("MOBKIT_PORT", None)
                try:
                    operation_id = pending["id"] if pending else str(uuid.uuid4())
                    await self.require_cloud_available(receipt)
                    journal(directory, "Admitting a deliberate retry of the exact failed installation; existing data and prior attempt evidence are preserved.",
                        status="installing", retry_install_operation_id=operation_id,
                        retry_install_previous_operation_id=previous_operation_id,
                        **requested_port,
                        pending_operation={"id": operation_id, "action": "retry-install",
                            "previous_operation_id": previous_operation_id})
                    receipt = read_receipt(directory)
                    try:
                        result, _ = await self.rpc(directory, receipt, "retry-install", operation_id=operation_id,
                            previous_operation_id=previous_operation_id, settings=values)
                        self.adopt(directory, receipt, result, expected_operation=operation_id)
                    except (SshTransportError, TimeoutError, OSError, ValueError, LookupError) as error:
                        self.unavailable(directory, error=error)
                finally:
                    values.clear()
                receipt = read_receipt(directory)
                return self.public(receipt, current=await self.current(receipt))

    async def action(self, guide_id, deployment_id, action):
        if action not in {"stop", "restart"}:
            raise ValueError("Choose stop or restart for this owned remote installation.")
        async with self.lock:
            directory, receipt = self.stored(guide_id, deployment_id)
            async with self.operation_lock(directory):
                receipt = read_receipt(directory)
                await self.require_cloud_available(receipt)
                if not receipt.get("remote_admission_requested"):
                    raise DraftConflict("This remote installation has not admitted an application yet.")
                current = await self.current(receipt)
                if action == "restart" and not current:
                    raise DraftConflict("Restart only the current accepted installed source. The older installation can still be stopped.")
                pending = receipt.get("pending_operation")
                if pending:
                    if pending["action"] != action:
                        raise DraftConflict("Recheck the pending remote operation before requesting a different control action.")
                    operation_id = pending["id"]
                else:
                    if not self.public(receipt, current=current)["can_" + action]:
                        raise DraftConflict("Recheck this owned service before requesting its control operation.")
                    operation_id = str(uuid.uuid4())
                await self.browser_access.revoke(guide_id, deployment_id,
                    "Browser access is closed while the owned remote service changes. Reconnect after its readiness is verified.")
                await self.require_cloud_available(receipt)
                journal(directory, "Requesting an owned remote service operation.", status="stopping" if action == "stop" else "restarting",
                        pending_operation={"id": operation_id, "action": action})
                receipt = read_receipt(directory)
                try:
                    value, _ = await self.rpc(directory, receipt, action, operation_id=operation_id)
                    self.adopt(directory, receipt, value, expected_operation=operation_id)
                except (SshTransportError, TimeoutError, OSError, ValueError, LookupError) as error:
                    self.unavailable(directory, error=error)
                receipt = read_receipt(directory)
                return self.public(receipt, current=await self.current(receipt))

    async def use(self, guide_id, deployment_id=None):
        from .remote_installed_feedback import remote_application_use
        return await remote_application_use(self, guide_id, deployment_id)

    async def record_success(self, guide_id, version, deployment_id, build_id, source_digest,
                             package_sha256, *, request_id, task):
        from .installed_feedback import record_remote_success
        return await record_remote_success(self, guide_id, version, deployment_id, build_id,
            source_digest, package_sha256, request_id=request_id, task=task)

    async def feedback(self, guide_id, version, remote_binding, continuation_build_id,
                       continuation_source_digest, *, request, outcome, task="",
                       continue_current_candidate=False):
        from .remote_installed_feedback import improve_remote_application
        return await improve_remote_application(self, guide_id, version, remote_binding,
            continuation_build_id, continuation_source_digest, request=request, outcome=outcome,
            task=task, continue_current_candidate=continue_current_candidate)

    async def shutdown(self):
        await self.browser_access.shutdown()
        tasks = list(self.tasks.values())
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        # Remote workers/services keep their destination-owned custody. Shutdown
        # closes local observation only and never claims a remote stop.
