"""Freeze canonical declaration helpers into one standalone destination controller."""
from pathlib import Path


def controller_bytes():
    """Return exact controller and helper bytes under a single controller digest.

    Existing stored controllers are never rewritten. The injected literal runs
    before main() and is also available to the existing detached worker loader.
    """
    root = Path(__file__).parent
    source = (root / "remote_destination.py").read_bytes()
    parser = (root / "application_experiences.py").read_bytes()
    console = (root / "templates_v2/console_configuration.py").read_bytes()
    marker = b"\nif __name__ == '__main__':\n"
    if source.count(marker) != 1:
        raise ValueError("The standalone destination controller entry point changed.")
    payload = b"\nAPPLICATION_EXPERIENCES_SOURCE = " + repr(parser).encode("ascii") + b"\n"
    payload += b"CONSOLE_CONFIGURATION_SOURCE = " + repr(console).encode("ascii") + b"\n"
    return source.replace(marker, payload + marker)
