"""User-admitted local deployment of an immutable, checked application package."""
from __future__ import annotations

import asyncio
from copy import deepcopy
from contextlib import contextmanager, nullcontext
from datetime import datetime, timezone
import fcntl
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tempfile
import uuid
import zipfile
from urllib.parse import quote, urlencode

from .projects import DraftConflict, fingerprint
from .templates.storage_setup import project_lock, write_private
from .templates_v2.application_configuration import validate_application_fields, validate_configuration_values
from .templates_v2.console_configuration import (console_configuration,
    console_authentication as declared_console_authentication, validate_console_configuration_values)
from .artifact_binding import package_matches, report_brief_hash, matches as artifact_matches, current_version, proposal_hash
from .deployment_deadlines import WORKER_STOP_TIMEOUT, PROCESS_FORCE_REAP_TIMEOUT
from .deployment_ports import observe_local_console_port, require_available_console_port, installed_console_port
from .deployment_sources import compile_native_source, read_package_source, native_fields, NATIVE_SOURCE, NATIVE_KEYS

ACTIVE = {"queued", "installing", "checking", "starting", "running", "stopping"}
PROVIDER_KEYS = {"OPENAI_API_KEY", "ANTHROPIC_API_KEY", "GEMINI_API_KEY"}
MAX_PACKAGE_BYTES = 64 * 1024 * 1024
OWNER_FILE = ".mobkit/launch-deployment-owner.json"


def now():
    return datetime.now(timezone.utc).isoformat()


def read_receipt(root):
    return json.loads((Path(root) / "receipt.json").read_text())


@contextmanager
def receipt_lock(root):
    descriptor = os.open(Path(root) / "journal.lock", os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(descriptor, fcntl.LOCK_EX)
        yield
    finally:
        os.close(descriptor)


def update_receipt(root, **changes):
    with receipt_lock(root):
        value = read_receipt(root)
        value.update(changes, updated_at=now())
        write_private(Path(root) / "receipt.json", value)
        return value


def journal(root, message, **changes):
    with receipt_lock(root):
        value = read_receipt(root)
        entries = [*value.get("progress", []), {"at": now(), "message": message}][-100:]
        value.update(changes, updated_at=now(), progress=entries, detail=message)
        write_private(Path(root) / "receipt.json", value)
        return value


def interactive_cleanup_matches(receipt, *, require_worker_exit=True):
    """A failed receipt or an available project lease is not teardown evidence."""
    cleanup = receipt.get("interactive_cleanup")
    identity = receipt.get("interactive_lifecycle_id")
    try:
        valid_id = isinstance(identity, str) and str(uuid.UUID(identity)) == identity
    except (ValueError, AttributeError):
        valid_id = False
    return bool(valid_id and isinstance(cleanup, dict) and cleanup.get("confirmed") is True
        and (not require_worker_exit or cleanup.get("worker_exit_confirmed") is True
             or cleanup.get("worker_exit_confirmed") is False
             and cleanup.get("supervisor_absence_confirmed") is True
             and cleanup.get("supervisor_absence_scope") == "cold-host-owned-native-teardown"
             and cleanup.get("boundary") == "owned-process-groups-absent")
        and cleanup.get("lifecycle_id") == identity
        and all(cleanup.get(key) == receipt.get(key) for key in
                ("deployment_id", "guide_id", "build_id", "guide_version", "blueprint_hash",
                 "destination", "package_sha256"))
        and all(cleanup.get(key) == value for key, value in native_fields(receipt).items())
        and "interactive_cleanup_attempt_id" in receipt
        and cleanup.get("startup_attempt_id") == receipt["interactive_cleanup_attempt_id"]
        and (receipt.get("startup_attempt_id") is None
             or receipt["startup_attempt_id"] == receipt["interactive_cleanup_attempt_id"])
        and all(isinstance(cleanup.get(key), str) and re.fullmatch(r"[a-f0-9]{64}", cleanup[key])
                for key in ("source_digest", "owner_sha256"))
        and type(cleanup.get("supervisor_pid")) is int and cleanup["supervisor_pid"] > 0
        and cleanup.get("boundary") in {"owned-process-groups-absent", "worker-not-admitted"}
        and (cleanup.get("boundary") != "worker-not-admitted" or receipt.get("startup_attempt_id") is None)
        and type(cleanup.get("return_code")) is int and cleanup["return_code"] in (0, 1))


def interactive_source_binding(directory, receipt, *, allow_missing=False):
    from .deployment_updates import checked_package
    _, files = checked_package(Path(directory), "package.zip", receipt["package_sha256"])
    source = read_package_source(files, receipt)
    digest = source["source_digest"]
    destination = verify_destination(receipt, files, allow_missing=allow_missing)
    owner = destination / OWNER_FILE
    info = owner.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_nlink != 1:
        raise ValueError("The cleaned installation's owner could not be verified.")
    return {"source_digest": digest, "owner_sha256": hashlib.sha256(owner.read_bytes()).hexdigest()}


async def require_owned_group_absent(process, *, timeout=1):
    """Observe the group created for this actual child handle, without signaling it."""
    deadline = asyncio.get_running_loop().time() + timeout
    while True:
        if process.returncode is None:
            raise ValueError("The owned application parent has not confirmed exit.")
        try:
            os.killpg(process.pid, 0)
        except ProcessLookupError:
            return
        except PermissionError:
            raise ValueError("The owned application group cleanup could not be observed.") from None
        if asyncio.get_running_loop().time() >= deadline:
            raise ValueError("The owned application group has not confirmed exit.")
        await asyncio.sleep(0.05)


async def interactive_worker(directory, mode, lifecycle_id):
    """Confirm only a normal return through the fixed worker's teardown boundary."""
    from . import deployment_worker as worker
    receipt = read_receipt(directory)
    if (mode not in {"install", "start", "update", "rollback", "recover-current"}
            or receipt.get("execution_mode", "interactive") != "interactive"
            or receipt.get("service") or receipt.get("interactive_lifecycle_id") != lifecycle_id):
        raise ValueError("The owned interactive worker admission changed.")
    binding_keys = ("deployment_id", "guide_id", "build_id", "guide_version",
        "blueprint_hash", "destination", "package_sha256")
    transaction_admission = None
    transaction_update = None
    transaction_sources = None
    if mode in {"update", "rollback", "recover-current"}:
        from .deployment_updates import transaction
        transaction_admission = receipt.get("update_action") or {}
        if (transaction_admission.get("action") != ("apply-update" if mode == "update" else mode)
                or not transaction_admission.get("update_id")):
            raise ValueError("The owned interactive update admission changed.")
        receipt, _, update = transaction(directory, transaction_admission["update_id"])
        transaction_update = deepcopy(update)
        transaction_sources = {update["previous_package_sha256"]: update["from_build_id"],
                               update["package_sha256"]: update["to_build_id"]}
        if transaction_sources.get(receipt.get("package_sha256")) != receipt.get("build_id"):
            raise ValueError("The owned interactive update source changed.")
        # The same transaction may leave either checked source installed. Its
        # deployment and destination remain fixed while actual child handles
        # supply teardown evidence for every attempted source.
        binding_keys = ("deployment_id", "guide_id", "destination")
    binding = {key: receipt.get(key) for key in binding_keys}
    binding.update(native_fields(receipt))
    # This runs in a dedicated fixed host process. Capture actual child handles
    # at the existing teardown seam; do not reconstruct ownership from receipts.
    original = worker.Supervisor
    supervisors = []

    class InteractiveSupervisor(original):
        def __init__(self, root):
            super().__init__(root)
            self.cleanup_observed = False
            self.cleanup_groups = {}
            supervisors.append(self)

        async def terminate(self, *args, **kwargs):
            process = self.child
            self.cleanup_observed = False
            if process is not None:
                self.cleanup_groups[id(process)] = (process, False)
            await super().terminate(*args, **kwargs)
            if process is not None:
                await require_owned_group_absent(process)
                self.cleanup_groups[id(process)] = (process, True)
            self.cleanup_observed = True

    worker.Supervisor = InteractiveSupervisor
    try:
        code = await worker.run(Path(directory), mode)
    finally:
        worker.Supervisor = original
    if (asyncio.current_task().cancelling() or not supervisors
            or any(not item.cleanup_observed or any(not confirmed for _, confirmed in item.cleanup_groups.values())
                   for item in supervisors)):
        raise ValueError("The interactive worker did not confirm uncancelled cleanup.")
    if code is not None and (type(code) is not int or code not in (0, 1)):
        raise ValueError("The interactive worker returned an unknown result.")
    if transaction_sources is not None:
        latest, _, update = transaction(directory, transaction_admission["update_id"],
            cleanup_update=transaction_update)
        if (latest.get("update_action") != transaction_admission
                or {update["previous_package_sha256"]: update["from_build_id"],
                    update["package_sha256"]: update["to_build_id"]} != transaction_sources
                or transaction_sources.get(latest.get("package_sha256")) != latest.get("build_id")
                or any(latest.get(key) != value for key, value in binding.items())):
            raise ValueError("The owned interactive update changed during cleanup.")
        binding = {key: latest.get(key) for key in ("deployment_id", "guide_id", "build_id", "guide_version",
            "blueprint_hash", "destination", "package_sha256")}
        binding.update(native_fields(latest))
    with receipt_lock(directory):
        latest = read_receipt(directory)
        if (latest.get("interactive_lifecycle_id") != lifecycle_id
                or transaction_admission is not None and latest.get("update_action") != transaction_admission
                or any(latest.get(key) != value for key, value in binding.items())):
            raise ValueError("The interactive worker ownership changed during cleanup.")
        source_binding = interactive_source_binding(directory, latest)
        latest.update(interactive_cleanup={**binding, "lifecycle_id": lifecycle_id, "confirmed": True,
            **source_binding, "boundary": "owned-process-groups-absent",
            "startup_attempt_id": latest.get("startup_attempt_id"), "supervisor_pid": os.getpid(),
            "return_code": code or 0, "completed_at": now(), "worker_exit_confirmed": False},
            interactive_cleanup_attempt_id=latest.get("startup_attempt_id"), updated_at=now())
        write_private(Path(directory) / "receipt.json", latest)
    return code


def local_target(blueprint):
    expected = {"darwin": "mac", "linux": "linux"}.get(sys.platform)
    if not expected or blueprint.get("target") != expected:
        raise ValueError("This proposal targets another host. Ask the guide to choose this computer's operating system before local installation; GCP remains a separate deployment adapter.")


def require_accepted(status):
    if (status.get("acceptance_current") is not True or status.get("acceptance_trusted") is not True
            or (status.get("acceptance") or {}).get("status") != "pass"):
        raise ValueError("Run independent acceptance for the current checked source before installing. An older source-only package is not accepted deployment evidence.")


def configuration_fields(definition, application_fields=None):
    fields = [dict(field) for field in definition["environment"]]
    knowledge = definition["knowledge"]
    if knowledge["mode"] == "local":
        generated = {knowledge["token_env"], knowledge["space_env"]}
        fields = [{**field, "required": False, "automatic": True} if field["key"] in generated else field
                  for field in fields]
        if not any(field["key"] == "OPENAI_API_KEY" for field in fields):
            fields.append({"key": "OPENAI_API_KEY", "label": "OpenAI API key for knowledge embeddings",
                           "secret": True, "required": True})
    if application_fields is not None:
        value = application_fields if isinstance(application_fields, dict) else {"fields": application_fields}
        fields.extend(validate_application_fields(value, {field["key"] for field in fields} | PROVIDER_KEYS))
    return fields


def package_configuration_fields(definition, files):
    """Read declarative private fields only from the immutable checked package."""
    entry = files.get("application/configuration.json")
    if entry is None:
        return configuration_fields(definition)
    if len(entry[0]) > 256_000:
        raise ValueError("Application configuration must be a bounded ordinary JSON file.")
    try:
        value = json.loads(entry[0].decode("utf-8"))
    except (ValueError, UnicodeError):
        raise ValueError("Application configuration must contain valid UTF-8 JSON.") from None
    return configuration_fields(definition, value)


def deployment_handoff(definition, files, proposal, guide_id, build_id):
    """Describe only commands supported by this immutable package, without running them."""
    target = definition.get("target")
    if target not in {"mac", "linux", "gcp"} or target != proposal.get("target"):
        raise DraftConflict("The package destination differs from this proposal. Rebuild before installing.")
    host_target = {"darwin": "mac", "linux": "linux"}.get(sys.platform)
    local = target == host_target
    handoff = {"mode": "local" if local else "remote-package", "status": "not-connected",
               "package_url": f"/api/guide/{quote(guide_id, safe='')}/implementation/package?{urlencode({'build_id': build_id})}",
               "steps": [], "operations": [], "limitations": []}
    if local:
        return target, host_target, handoff
    handoff["limitations"] = [
        "Forge has not connected to or verified a remote deployment. Downloading this accepted source is not a running-system check.",
        "Enter private credentials on the destination using setup.py. This page does not send credentials to another computer.",
        "Custom UI and external chat channel health require their own live checks; a native Console link does not verify them.",
    ]
    required = {"setup.py", "start.sh", "install.sh"}
    if target == "gcp":
        required |= {"deploy/deploy-gcp.sh", "deploy/install-service.sh", "deploy/tunnel-gcp.sh", "remote_operations.py"}
    missing = sorted(required - files.keys())
    if missing:
        handoff["limitations"].append("This accepted package lacks the required handoff scripts: " + ", ".join(missing) + ". Continue implementation before deployment.")
        return target, host_target, handoff
    steps = handoff["steps"]
    steps.append({"title": "Download and extract the accepted package" if target == "gcp" else "Download the accepted package",
                  "where": "this computer",
                  "description": "Use the download button above. " + ("Extract into a new empty folder that you own on this computer. The provisioning and tunnel commands run from this folder." if target == "gcp" else "Keep this exact ZIP for transfer to the destination; Forge does not upload it for you."), "commands": []})
    if target != "gcp":
        steps.append({"title": "Transfer the ZIP and extract it on the destination", "where": "destination computer",
                      "description": "Transfer the downloaded ZIP to your destination using your usual file transfer, then extract it into a new empty folder you own there. If this is the destination computer, extract here. Keep the source unchanged; run the destination commands below from that extracted folder.", "commands": []})
    if target == "gcp":
        cloud = proposal.get("gcp") or {}
        project, zone, slug = cloud.get("project", ""), cloud.get("zone", ""), definition.get("slug", "")
        if (not re.fullmatch(r"[a-z][a-z0-9-]{4,28}[a-z0-9]", project)
                or not re.fullmatch(r"[a-z]+-[a-z]+[0-9]+-[a-z]", zone)
                or not re.fullmatch(r"[a-z][a-z0-9-]{1,39}", slug)):
            handoff["limitations"].append("The checked proposal needs a valid Google Cloud project, zone and project folder before exact cloud instructions are available.")
            handoff["steps"] = []
            return target, host_target, handoff
        steps += [
            {"title": "Prepare Google Cloud access", "where": "your computer",
             "description": f"Install the Google Cloud CLI and sign in to an account authorized for project {project}. The project needs billing and Compute Engine/IAP access. This page does not create cloud resources or sign you in.", "commands": ["gcloud auth login"]},
            {"title": "Review, then create the VM", "where": "your computer",
             "description": f"The script targets {project}, {zone}, VM {slug}. The second command creates billed resources after its project confirmation. It keeps an ownership receipt for recovery; private credentials are excluded from upload.",
             "commands": ["bash deploy/deploy-gcp.sh --dry-run", "bash deploy/deploy-gcp.sh"]},
            {"title": "Configure private credentials on the VM", "where": "SSH session on the VM",
             "description": "Start this SSH command on your computer, then run the folder and setup commands inside that session. Install the selected connector prerequisites on the VM. The private setup interview asks for provider, connector and application fields without editing files.",
             "commands": [f"gcloud compute ssh {slug} --project {project} --zone {zone} --tunnel-through-iap", f"cd ~/src/{slug}", ".venv/bin/python setup.py"]},
        ]
    else:
        steps.append({"title": "Install and enter private configuration", "where": "destination computer",
                      "description": "Install Python 3.11 or newer and the selected connector prerequisites there, then run this command. The setup interview collects private fields without editing files.", "commands": ["bash install.sh"]})
    knowledge = definition.get("knowledge") or {}
    if knowledge.get("mode") != "none" and "knowledge/manage.py" in files:
        commands = ([".venv/bin/python knowledge/manage.py up"] if knowledge.get("mode") == "local" else [])
        steps.append({"title": "Check the selected knowledge service", "where": "VM SSH session" if target == "gcp" else "destination computer",
                      "description": "Local Elephant requires Docker with Compose and Git on the destination. The verification command checks actual authenticated service access.",
                      "commands": [*commands, ".venv/bin/python knowledge/manage.py verify"]})
    checks = ["bash start.sh --doctor", "bash start.sh --application-check"]
    if definition.get("mcpConnections"):
        checks.append("bash start.sh --connections-check")
    service = target == "gcp" or (target == "linux" and {"deploy/install-service.sh", "remote_operations.py"}.issubset(files))
    start_command = "bash deploy/install-service.sh" if target == "gcp" else "bash deploy/install-service.sh start" if service else "bash start.sh"
    start_description = "Resolve failed checks before starting. Starting runs the accepted application's configured startup work. These commands do not prove custom interfaces or live external workflows are working. "
    if service:
        start_description += "The owned background service requires your Linux user systemd manager and waits for native bootstrap and Console health. Running in the background does not guarantee operation after logout or reboot."
    else:
        start_description += "Keep this terminal open while the application runs. Stop it with Control-C."
    steps.append({"title": "Verify, then start the background service" if service else "Verify, then run in this terminal",
                  "where": "VM SSH session" if target == "gcp" else "destination computer",
                  "description": start_description, "commands": [*checks, start_command]})
    port = definition.get("port")
    if type(port) is not int or not 1024 <= port <= 65535:
        raise ValueError("The accepted package has an invalid native Console port.")
    if target != "gcp":
        steps.append({"title": "If the destination is another computer, open a private SSH tunnel",
                      "where": "your computer with the browser, not the destination SSH session",
                      "description": "Skip this step when using a browser on the destination itself. Otherwise replace USER@HOST with your SSH user and destination address. Keep this separate tunnel terminal open; stop the tunnel with Control-C. Do not expose the Console publicly.",
                      "commands": [f"ssh -N -L {port}:127.0.0.1:{port} USER@HOST"]})
    steps.append({"title": "Open the native MobKit Console", "where": "your computer with the browser",
                  "description": f"{'Keep the IAP tunnel open, then visit' if target == 'gcp' else 'Use a browser on the destination, or keep the SSH tunnel above open on your computer, then visit'} http://127.0.0.1:{port}/console. This is the native agent chat and admin Console. Its remote health is not tracked by Forge.",
                  "commands": ["bash deploy/tunnel-gcp.sh"] if target == "gcp" else []})
    if service:
        handoff["operations"] = [
            {"title": "Check service status", "commands": ["bash deploy/install-service.sh status"]},
            {"title": "Stop the application", "commands": ["bash deploy/install-service.sh stop"]},
            {"title": "Restart the same installed application", "commands": ["bash deploy/install-service.sh restart"]},
            {"title": "Remove only the owned service, preserving source, private settings and data", "commands": ["bash deploy/install-service.sh remove-service"]},
            {"title": "Choose logout behavior or change private setup", "commands": ["bash deploy/install-service.sh stop", "bash deploy/install-service.sh setup"]},
            {"title": "Use a terminal instead of the background service", "description": "Choose this alternative when a user systemd manager is unavailable. Stop the background service first if it is running. Keep this terminal open and stop the application with Control-C; do not run both copies.", "commands": ["bash start.sh"]},
        ]
        handoff["limitations"].append("The background service belongs to the destination's current Linux user. The guided service setup asks before enabling operation after logout; that system setting can require sudo. A user manager without that setting normally stops its services on logout. No unattended boot or remote health is established by these instructions.")
    if target == "gcp":
        handoff["limitations"].append("If VM installation stops, keep this exact package folder and use bash deploy/deploy-gcp.sh --resume. Cleanup commands and ownership evidence are in the package README and script output.")
    return target, host_target, handoff


def package_console_scope(files, fields, state):
    """Describe declared Console authentication and the exact scope of host health evidence."""
    authentication = "loopback-only"
    entry = files.get("application/console.json")
    if entry is not None:
        try:
            if len(entry[0]) > 4096 or json.loads(entry[0].decode("utf-8")) != {"authentication": "local-password"}:
                raise ValueError
        except (ValueError, UnicodeError):
            raise ValueError("The accepted package has invalid Console authentication metadata.") from None
        declared = {field["key"]: field for field in fields}
        if any(key not in declared or declared[key].get("required") is not True
               or declared[key].get("secret") is not secret or "default" in declared[key]
               for key, secret in [("CONSOLE_USER_ID", False), ("CONSOLE_LOGIN_PASSWORD", True)]):
            raise ValueError("Authenticated Console metadata needs its required private setup fields.")
        authentication = "local-password"
    interfaces = (state.get("brief") or {}).get("facts", {}).get("interfaces") or {}
    requested = interfaces.get("summary", "") if interfaces.get("source_message_ids") else ""
    return {"authentication": authentication, "health_scope": "native-bootstrap-and-console",
            "requested_interfaces": requested, "custom_interfaces_verified": False}


def parse_setting(value):
    if value.startswith('"'):
        return json.loads(value)
    if len(value) >= 2 and value[0] == value[-1] == "'":
        return value[1:-1]
    return value


def package_files(payload):
    """Reject traversal, links, duplicates, private state, and oversized ZIP data."""
    if len(payload) > MAX_PACKAGE_BYTES:
        raise ValueError("The checked application package is too large.")
    files, original_modes, original_types = {}, {}, {}
    size = 0
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        for item in archive.infolist():
            name = item.filename
            parts = name.split("/")
            mode = item.external_attr >> 16
            if (not name or PurePosixPath(name).is_absolute() or "\\" in name
                    or any(part in {"", ".", ".."} for part in parts)
                    or any(ord(char) < 32 for char in name) or name in files
                    or stat.S_ISLNK(mode) or item.is_dir()
                    or parts[0] in {".venv", ".bin", ".mobkit", "data"}
                    or parts[-1] == ".env"):
                raise ValueError("The checked package contains an unsafe deployment path.")
            size += item.file_size
            if size > MAX_PACKAGE_BYTES or len(files) >= 2048:
                raise ValueError("The checked application package exceeded its file limit.")
            files[name] = (archive.read(item), 0o755 if mode & 0o111 else 0o644)
            original_modes[name] = stat.S_IMODE(mode)
            original_types[name] = stat.S_IFMT(mode)
    if NATIVE_SOURCE in files:
        if (any(mode not in {0o600, 0o644, 0o755} for mode in original_modes.values())
                or any(kind != stat.S_IFREG for kind in original_types.values())):
            raise ValueError("The compiled agent-team package has unsupported source modes.")
        files = {name: (content, original_modes[name]) for name, (content, _) in files.items()}
        read_package_source(files)
    if (not {"deployment.json", "app.py", "install.sh"}.issubset(files)
            or NATIVE_SOURCE not in files and "implementation-report.json" not in files):
        raise ValueError("Use a checked application package containing the native host.")
    return files


def owned_destination(value):
    if not isinstance(value, str) or not value.strip() or len(value) > 2000 or any(ord(c) < 32 for c in value):
        raise ValueError("Choose a destination folder on this computer.")
    path = Path(value.strip()).expanduser()
    if not path.is_absolute():
        raise ValueError("Use an absolute destination, such as ~/src/my-team.")
    path = Path(os.path.abspath(path))
    if path in {Path("/"), Path.home()}:
        raise ValueError("Choose a project folder inside a directory you own.")
    for part in [*reversed(path.parents), path]:
        if part.is_symlink():
            raise ValueError("The destination and its parent folders cannot be symbolic links.")
        if part.exists() and not part.is_dir():
            raise ValueError("The destination must be a folder.")
    existing = next(part for part in [path, *path.parents] if part.exists())
    if existing.stat().st_uid != os.getuid():
        raise ValueError("Choose a destination inside a folder owned by your user.")
    return path


def ownership(receipt):
    return {**{key: receipt[key] for key in ("deployment_id", "guide_id", "build_id", "package_sha256", "destination")},
            **native_fields(receipt)}


def verify_destination(receipt, files, *, allow_missing=False):
    destination = owned_destination(receipt["destination"])
    marker = destination / OWNER_FILE
    if marker.is_symlink() or marker.parent.is_symlink():
        raise DraftConflict("The deployment ownership marker was replaced. No files were changed.")
    try:
        actual = json.loads(marker.read_text())
    except (OSError, ValueError):
        raise DraftConflict("This folder has no matching Forge ownership receipt. No files were changed.") from None
    if actual != ownership(receipt):
        raise DraftConflict("This folder belongs to another deployment. Choose a new folder.")
    for name, (content, mode) in files.items():
        target = destination / name
        if any(part.is_symlink() for part in [target, *target.parents] if part != destination.parent):
            raise DraftConflict("A deployed source path was replaced by a link. No files were changed.")
        if not target.exists() and allow_missing:
            continue
        if not target.is_file() or hashlib.sha256(target.read_bytes()).digest() != hashlib.sha256(content).digest():
            raise DraftConflict("Installed source differs from the checked package. Preserve this folder and choose a new destination.")
        if receipt.get("source_kind") == "native-team" and stat.S_IMODE(target.stat().st_mode) != mode:
            raise DraftConflict("Installed agent-team source permissions differ from its compiled package. Preserve this folder.")
    return destination


def materialize(root):
    receipt = read_receipt(root)
    payload = (Path(root) / "package.zip").read_bytes()
    if hashlib.sha256(payload).hexdigest() != receipt["package_sha256"]:
        raise DraftConflict("The saved checked package changed. No deployment files were changed.")
    files = package_files(payload)
    destination = verify_destination(receipt, files, allow_missing=True)
    for name, (content, mode) in files.items():
        target = destination / name
        if target.exists():
            continue
        target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        descriptor = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode)
        with os.fdopen(descriptor, "wb") as stream:
            if receipt.get("source_kind") == "native-team":
                # These newly created public compiler files retain their exact
                # manifest modes even under the worker's private umask.
                os.fchmod(stream.fileno(), mode)
            stream.write(content)
    verify_destination(receipt, files)
    return files


def prepare_private_settings(destination, fields, submitted, use_host, *, port=None, remove_fields=(), existing_values=None,
                             console_authentication=None):
    """Validate private input without claiming a destination or writing credentials."""
    if not isinstance(submitted, dict) or len(submitted) > 100:
        raise ValueError("Provide configuration values in the private setup form.")
    allowed = {field["key"]: field for field in fields}
    allowed["MOBKIT_PORT"] = {"secret": False, "required": False}
    if set(submitted) - set(allowed):
        raise ValueError("The setup form contains a setting not requested by this package.")
    if (not isinstance(remove_fields, (list, tuple)) or len(remove_fields) > 100
            or any(not isinstance(key, str) for key in remove_fields)
            or len(set(remove_fields)) != len(remove_fields)):
        raise ValueError("Choose each optional setting to remove once.")
    removed = set(remove_fields)
    if any(key not in allowed or key == "MOBKIT_PORT" or allowed[key].get("required")
           or allowed[key].get("automatic") for key in removed):
        raise ValueError("Only optional settings requested by this package can be removed.")
    if any(submitted.get(key) for key in removed):
        raise ValueError("Choose either a replacement or removal for an optional setting.")
    path = destination / ".env"
    if path.is_symlink():
        raise DraftConflict("The private configuration path is a link. No credentials were saved.")
    new_configuration = existing_values is None and not path.exists()
    values = dict(existing_values) if existing_values is not None else {}
    if existing_values is None and path.exists():
        for line in path.read_text().splitlines():
            if not line or line.startswith("#"):
                continue
            key, separator, value = line.partition("=")
            if not separator or not re.fullmatch(r"[A-Z][A-Z0-9_]*", key):
                raise ValueError("Existing private configuration is invalid. Preserve it and inspect the destination.")
            values[key] = parse_setting(value)
    for field in fields:
        key = field["key"]
        if not re.fullmatch(r"[A-Z][A-Z0-9_]*", key):
            raise ValueError("The package requests an invalid configuration name.")
        if key in removed:
            continue
        # Source defaults fill the first setup, never restore an explicit absence.
        if new_configuration and field.get("default") and not field.get("secret"):
            values.setdefault(key, field["default"])
        if use_host and key in PROVIDER_KEYS and os.environ.get(key):
            values[key] = os.environ[key]
    for key, value in submitted.items():
        if not isinstance(value, str) or len(value) > 32768 or "\x00" in value:
            raise ValueError("A configuration value is invalid or too long.")
        if value:
            values[key] = value
    for key in removed:
        values.pop(key, None)
    if port is not None:
        values.setdefault("MOBKIT_PORT", str(port))
    try:
        selected_port = int(values.get("MOBKIT_PORT", "0"))
    except ValueError:
        selected_port = 0
    if not 1024 <= selected_port <= 65535:
        raise ValueError("Choose a Console port between 1024 and 65535.")
    validate_configuration_values(fields, values)
    if console_authentication is None:
        authenticated_console = console_configuration(destination, fields)
    elif console_authentication in {"loopback-only", "local-password"}:
        authenticated_console = console_authentication == "local-password"
        if authenticated_console:
            declared_console_authentication({"authentication": console_authentication}, fields)
    else:
        raise ValueError("The package has unsupported Console authentication metadata.")
    if authenticated_console:
        validate_console_configuration_values(fields, values)
    return values


def private_configuration_snapshot(destination):
    """Read bounded private values and file identity only inside the host boundary."""
    path = destination / ".env"
    try:
        descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except FileNotFoundError:
        return {}, None
    except OSError:
        raise DraftConflict("The private configuration is not an owned ordinary file. No values were changed.") from None
    try:
        info = os.fstat(descriptor)
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_nlink != 1
                or info.st_mode & 0o077 or info.st_size > 256 * 1024):
            raise DraftConflict("The private configuration is not an owned private ordinary file. No values were changed.")
        with os.fdopen(descriptor, "rb", closefd=False) as stream:
            original = stream.read(256 * 1024 + 1)
        if len(original) > 256 * 1024:
            raise DraftConflict("The private configuration exceeded its safe size. No values were changed.")
    finally:
        os.close(descriptor)
    values = {}
    try:
        for line in original.decode("utf-8").splitlines():
            row = line.strip()
            if not row or row.startswith("#"):
                continue
            key, separator, value = row.partition("=")
            if not separator or not re.fullmatch(r"[A-Z][A-Z0-9_]*", key):
                raise ValueError
            value = parse_setting(value.strip())
            if not isinstance(value, str) or len(value) > 32768 or "\x00" in value:
                raise ValueError
            values[key] = value
    except (ValueError, UnicodeError):
        raise DraftConflict("Existing private configuration could not be read safely. No values were changed.") from None
    identity = (info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_nlink, info.st_mtime_ns)
    return values, (original, identity)


def replace_private_configuration(destination, values, expected):
    """Publish atomically only while the checked private file is still unchanged."""
    content = "# Private deployment configuration. Never commit this file.\n" + "".join(
        f"{key}={json.dumps(value, ensure_ascii=True)}\n" for key, value in sorted(values.items()))
    if len(content.encode("utf-8")) > 256 * 1024:
        raise ValueError("The private configuration exceeded its safe size. No values were changed.")
    if private_configuration_snapshot(destination)[1] != expected:
        raise DraftConflict("Private settings changed during setup. Reload; the newer values were preserved.")
    descriptor, name = tempfile.mkstemp(prefix=".env.", suffix=".pending", dir=destination)
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, "w") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        if private_configuration_snapshot(destination)[1] != expected:
            raise DraftConflict("Private settings changed during setup. Reload; the newer values were preserved.")
        os.replace(temporary, destination / ".env")
    finally:
        temporary.unlink(missing_ok=True)


def write_private_settings(destination, values):
    temporary = destination / ".env.launch-pending"
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(fd, "w") as stream:
            os.fchmod(stream.fileno(), 0o600)
            stream.write("# Private deployment configuration. Never commit this file.\n")
            for key, value in sorted(values.items()):
                stream.write(f"{key}={json.dumps(value, ensure_ascii=True)}\n")
            stream.flush()
            os.fsync(stream.fileno())
        temporary.replace(destination / ".env")
    finally:
        temporary.unlink(missing_ok=True)


def private_settings(destination, fields, submitted, use_host, *, port=None):
    values = prepare_private_settings(destination, fields, submitted, use_host, port=port)
    write_private_settings(destination, values)


def validate_installed_console_settings(files, destination):
    """Check retained values against the verified package before restart admission."""
    fields = package_configuration_fields(json.loads(files["deployment.json"][0]), files)
    if package_console_scope(files, fields, {})["authentication"] == "local-password":
        values, _ = private_configuration_snapshot(destination)
        validate_console_configuration_values(fields, values)


def read_configuration_presence(path):
    """Return names only; no private values leave the destination setup boundary."""
    if not path.exists() or path.is_symlink():
        return set()
    result = set()
    for line in path.read_text().splitlines():
        key, separator, value = line.partition("=")
        if separator and re.fullmatch(r"[A-Z][A-Z0-9_]*", key):
            try:
                present = parse_setting(value)
            except ValueError:
                continue
            if present:
                result.add(key)
    return result


class DeploymentService:
    def __init__(self, root, guide, implementation, operations=None, service_manager=None):
        self.root = Path(root) / "deployments"
        self.guide, self.implementation, self.operations = guide, implementation, operations
        self.lock = asyncio.Lock()
        self.tasks, self.processes = {}, {}
        self.worker_admissions = {}
        from .deployment_service import UserServiceManager
        self.service_manager = service_manager or UserServiceManager()

    async def _guide(self, identity):
        return await (self.operations.read(self.guide, identity) if self.operations else self.guide.get(identity))

    def _directory(self, guide_id, deployment_id=None):
        for value in [guide_id, *([deployment_id] if deployment_id else [])]:
            try:
                if str(uuid.UUID(value)) != value:
                    raise ValueError
            except (ValueError, TypeError, AttributeError):
                raise LookupError("This deployment could not be found.") from None
        parent = self.root / guide_id
        if deployment_id is None:
            try:
                deployment_id = json.loads((parent / "latest.json").read_text())["deployment_id"]
            except (OSError, ValueError, KeyError):
                raise LookupError("No local deployment has been started for this setup.") from None
            return self._directory(guide_id, deployment_id)
        return parent / deployment_id

    def _installed_configuration(self, guide_id, deployment_id, *, required_status="stopped"):
        """Authenticate installed bytes independently of the selected implementation."""
        from .deployment_updates import checked_package
        directory = self._directory(guide_id)
        if directory != self._directory(guide_id, deployment_id):
            raise DraftConflict("A different installation is selected. Reload its private settings.")
        receipt = read_receipt(directory)
        if receipt.get("deployment_id") != deployment_id or receipt.get("guide_id") != guide_id:
            raise DraftConflict("The installed configuration belongs to a different setup.")
        process = self.processes.get(deployment_id)
        if (receipt.get("status") != required_status or deployment_id in self.tasks
                or process is not None and process.returncode is None
                or receipt.get("process_live") is True or receipt.get("runtime_pid") is not None):
            raise DraftConflict("Stop this installed application before changing its private settings.")
        if (required_status == "stopped" and receipt.get("execution_mode", "interactive") == "interactive"
                and receipt.get("interactive_lifecycle_id") is not None and not interactive_cleanup_matches(receipt)):
            raise DraftConflict("The owned runtime's cleanup is unconfirmed. No private-settings access was granted.")
        if (receipt.get("update") or {}).get("status") in {
                "snapshotting", "applying", "verifying", "restoring", "recovering-candidate",
                "recovering-current", "recovery-needed"}:
            raise DraftConflict("Finish or recover this installation's source update before changing private settings.")
        _, files = checked_package(directory, "package.zip", receipt["package_sha256"])
        try:
            definition = json.loads(files["deployment.json"][0])
            digest = read_package_source(files, receipt)["source_digest"]
            local_target(definition)
            fields = package_configuration_fields(definition, files)
        except (ValueError, KeyError, TypeError):
            raise DraftConflict("The checked installed configuration could not be verified on this computer.") from None
        destination = verify_destination(receipt, files)
        if (required_status == "stopped" and receipt.get("execution_mode", "interactive") == "interactive"
                and receipt.get("interactive_lifecycle_id") is not None):
            cleanup = receipt["interactive_cleanup"]
            if (cleanup.get("source_digest") != digest
                    or cleanup.get("owner_sha256") != hashlib.sha256((destination / OWNER_FILE).read_bytes()).hexdigest()):
                raise DraftConflict("The cleanup confirmation belongs to different installed source or ownership.")
            self._require_cleanup_supervisor_absent(receipt)
        for name in [*files, OWNER_FILE]:
            info = (destination / name).stat()
            if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_nlink != 1:
                raise DraftConflict("Installed source ownership could not be verified. No private values were changed.")
        lock = destination / ".mobkit/launch.lock"
        if lock.exists() or lock.is_symlink():
            info = lock.lstat()
            if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                    or info.st_nlink != 1 or info.st_mode & 0o077):
                raise DraftConflict("The installed process lock could not be verified. No private values were changed.")
        return directory, receipt, destination, definition, fields, digest

    @staticmethod
    def _configuration_binding(receipt):
        return {key: receipt.get(key) for key in (
            "deployment_id", "guide_id", "guide_version", "build_id", "package_sha256", "blueprint_hash",
            "source_kind", "source_id", "source_digest",
            "brief_hash", "destination", "execution_mode", "service", "service_supervisor_pid",
            "service_instance_id", "service_cleanup_confirmed", "update",
            "interactive_lifecycle_id", "interactive_cleanup_attempt_id", "interactive_cleanup")}

    @staticmethod
    def _installed_cleanup_matches(snapshot):
        _, receipt, destination, _, _, digest = snapshot
        cleanup = receipt.get("interactive_cleanup") or {}
        return bool(interactive_cleanup_matches(receipt) and cleanup.get("source_digest") == digest
                and cleanup.get("owner_sha256") == hashlib.sha256((destination / OWNER_FILE).read_bytes()).hexdigest())

    @staticmethod
    def _require_cleanup_supervisor_absent(receipt):
        cleanup = receipt.get("interactive_cleanup") or {}
        if cleanup.get("boundary") == "worker-not-admitted":
            return
        try:
            os.kill(cleanup["supervisor_pid"], 0)
        except ProcessLookupError:
            return
        except (OSError, OverflowError, KeyError):
            raise DraftConflict("The original owned supervisor's exit could not be observed. Preserve this folder; cleanup remains unconfirmed.") from None
        raise DraftConflict("The original owned supervisor has not confirmed absence. Wait for cleanup before settings or a fresh start.")

    async def _stopped_configuration(self, guide_id, deployment_id, version=None):
        state = await self._guide(guide_id)
        if (state.get("id") != guide_id or type(state.get("version")) is not int
                or version is not None and (type(version) is not int or state["version"] != version)
                or (state.get("operation") or {}).get("status") == "running"):
            raise DraftConflict("The guide changed or is busy. Reload private settings before saving.")
        snapshot = self._installed_configuration(guide_id, deployment_id)
        directory, receipt, *_ = snapshot
        if receipt.get("execution_mode") == "background":
            from .deployment_service import require_stopped_service
            await require_stopped_service(directory, self.service_manager)
        native_team = receipt.get("source_kind") == "native-team"
        try:
            candidate = None if native_team else await self.implementation.status(guide_id)
        except LookupError:
            candidate = None
        except (OSError, ValueError, KeyError, TypeError):
            raise DraftConflict("The application builder's current state could not be verified. Reload before changing private settings.") from None
        if candidate is not None:
            identity = candidate.get("build_id")
            process = getattr(self.implementation, "processes", {}).get(identity)
            if (candidate.get("status") not in {"completed", "failed", "interrupted"}
                    or identity in getattr(self.implementation, "tasks", {})
                    or process is not None and process.returncode is None
                    or any(key in candidate and candidate[key] is not True
                           for key in ("worker_stop_confirmed", "cleanup_confirmed"))):
                raise DraftConflict("Wait for the application builder to stop before changing private settings.")
        current = await self._guide(guide_id)
        fresh = self._installed_configuration(guide_id, deployment_id)
        try:
            selected = None if native_team else self.implementation.selected_build_id(guide_id)
        except LookupError:
            selected = None
        if (current.get("id") != guide_id or current.get("version") != state["version"]
                or type(current.get("version")) is not int
                or (current.get("operation") or {}).get("status") == "running"
                or selected != (candidate.get("build_id") if candidate is not None else None)
                or self._configuration_binding(fresh[1]) != self._configuration_binding(receipt)
                or fresh[-1] != snapshot[-1]):
            raise DraftConflict("The setup or installation changed while preparing private settings. Reload before saving.")
        return current, fresh

    async def settings_options(self, guide_id, deployment_id, *, console_port=None):
        async with self.lock:
            state, snapshot = await self._stopped_configuration(guide_id, deployment_id)
            directory, receipt, destination, definition, fields, digest = snapshot
            with project_lock(destination):
                fresh = self._installed_configuration(guide_id, deployment_id)
                if self._configuration_binding(fresh[1]) != self._configuration_binding(receipt):
                    raise DraftConflict("The installation changed while reading private settings. Reload before saving.")
                values, _ = private_configuration_snapshot(destination)
                public_fields = [{**{key: value for key, value in field.items()
                                    if key != "default" or not field.get("secret")},
                                  "configured": bool(values.get(field["key"])),
                                  "removable": not field.get("required", False) and not field.get("automatic", False)}
                                 for field in fields]
            keys = [field["key"] for field in fields if field["key"] in PROVIDER_KEYS
                    and not field.get("automatic") and os.environ.get(field["key"])]
            observation = observe_local_console_port(console_port, suggest_alternate=True) if console_port is not None else None
            return {"version": state["version"], "deployment_id": deployment_id, "build_id": receipt["build_id"],
                    "source_digest": digest, "package_sha256": receipt["package_sha256"], **native_fields(receipt),
                    **({"current_guide_version": state["version"]} if receipt.get("source_kind") == "native-team" else {}),
                    "guide_version": receipt["guide_version"], "destination": receipt["destination"],
                    "execution_mode": receipt.get("execution_mode", "interactive"), "fields": public_fields,
                    "console_port": definition["port"], "can_use_host_provider_credentials": bool(keys),
                    "host_provider_keys": keys, "source_verified": True, "supported": True,
                    "scope": "verified-installed-private-configuration", "requires_stopped": True,
                    **({"console_port_observation": observation} if observation is not None else {})}

    async def configure(self, guide_id, version, deployment_id, build_id, source_digest, package_sha256,
                        settings=None, remove_fields=None, use_host_provider_credentials=False,
                        *, source_kind=None, source_id=None):
        async with self.lock:
            if type(use_host_provider_credentials) is not bool:
                raise ValueError("Choose whether to use this computer's provider credentials explicitly.")
            _, snapshot = await self._stopped_configuration(guide_id, deployment_id, version)
            directory, receipt, destination, definition, fields, digest = snapshot
            if (receipt.get("source_kind") == "native-team"
                    and (source_kind != "native-team" or source_id != receipt.get("source_id"))
                    or receipt.get("source_kind", "application") == "application"
                    and (source_kind not in {None, "application"} or source_id is not None)):
                raise DraftConflict("The selected installed source changed. Reload its private settings.")
            if (build_id != receipt["build_id"] or source_digest != digest
                    or package_sha256 != receipt["package_sha256"]):
                raise DraftConflict("The installed source changed. Reload its private settings before saving.")
            submitted = settings if settings is not None else {}
            if (not isinstance(submitted, dict) or any(field.get("automatic") and field["key"] in submitted
                                                      for field in fields)):
                raise ValueError("Automatic private settings cannot be replaced through this form.")
            with project_lock(destination):
                fresh = self._installed_configuration(guide_id, deployment_id)
                if self._configuration_binding(fresh[1]) != self._configuration_binding(receipt) or fresh[-1] != digest:
                    raise DraftConflict("The installation changed while saving private settings. Reload before saving.")
                existing, private_snapshot = private_configuration_snapshot(destination)
                values = prepare_private_settings(destination, fields, submitted, use_host_provider_credentials,
                    port=definition["port"], remove_fields=remove_fields if remove_fields is not None else (),
                    existing_values=existing)
                if private_configuration_snapshot(destination)[1] != private_snapshot:
                    raise DraftConflict("Private settings changed during setup. Reload; the newer values were preserved.")
                if values == existing:
                    return read_receipt(directory)
                replace_private_configuration(destination, values, private_snapshot)
                journal(directory, "Private settings saved. This application remains stopped; start it explicitly when ready.",
                        health="unknown", health_checked_at=None, console_url=None,
                        startup_attempt_id=None, startup_console_health=None)
            # No launch, candidate acceptance rewrite or source copy occurs.
            return read_receipt(directory)

    async def native_package(self, guide_id, version):
        state = await self._guide(guide_id)
        if state.get("id") != guide_id:
            raise DraftConflict("The accepted plan belongs to a different guide.")
        payload, source, slug = await asyncio.to_thread(compile_native_source, state, version)
        latest = await self._guide(guide_id)
        if latest.get("id") != guide_id:
            raise DraftConflict("The accepted plan belongs to a different guide.")
        fresh, checked, _ = await asyncio.to_thread(compile_native_source, latest, version)
        if checked != source or fresh != payload:
            raise DraftConflict("The accepted team source changed. Reload before continuing.")
        return payload, source, slug

    async def options(self, guide_id, build_id=None, *, console_port=None, source_kind="application", version=None):
        if source_kind not in {"application", "native-team"}:
            raise ValueError("Choose an application or native-team source.")
        if source_kind == "native-team":
            if build_id is not None:
                raise ValueError("An agent-team package has no application build ID.")
            payload, source, slug = await self.native_package(guide_id, version)
            state = await self._guide(guide_id)
            status = {**source, "current": True}
        else:
            status = await self.implementation.status(guide_id)
            if build_id and status["build_id"] != build_id:
                raise DraftConflict("A newer application build is selected.")
            require_accepted(status)
            state = await self._guide(guide_id)
            payload, slug = await self.implementation.package(guide_id, status["build_id"])
        proposal = state.get("proposal") or state.get("blueprint") or {}
        files = package_files(payload)
        deployment = json.loads(files["deployment.json"][0])
        source = read_package_source(files)
        if source["build_id"] != status["build_id"] or not package_matches(source, state):
            raise DraftConflict("The package belongs to a different proposal or application brief. Reload before installing.")
        if source_kind == "native-team":
            local_target(deployment)
        fields = [{key: value for key, value in field.items() if key != "default" or not field.get("secret")}
                  for field in package_configuration_fields(deployment, files)]
        target, host_target, handoff = deployment_handoff(deployment, files, proposal, guide_id, status["build_id"])
        if source_kind == "native-team":
            handoff["package_url"] = f"/api/guide/{quote(guide_id, safe='')}/deployment/package?{urlencode({'source_kind': 'native-team', 'version': version})}"
        console_scope = package_console_scope(files, fields, state)
        configured, configured_deployment_id, configured_destination = set(), None, None
        try:
            owned = await self.status(guide_id)
            if (owned["build_id"] == status["build_id"] and all(owned.get(key) == value for key, value in native_fields(source).items()) and type(owned.get("guide_version")) is int
                    and owned["guide_version"] == status["guide_version"]):
                configured = read_configuration_presence(Path(owned["destination"]) / ".env")
                configured_deployment_id, configured_destination = owned["deployment_id"], owned["destination"]
        except LookupError:
            pass
        fields = [{**field, "configured": field["key"] in configured} for field in fields]
        keys = [field["key"] for field in fields if field["key"] in PROVIDER_KEYS and os.environ.get(field["key"])]
        supported = target == host_target and host_target is not None
        background = await self.service_manager.capability() if supported else {"available": False}
        if source_kind == "native-team":
            fresh_payload, latest, _ = await self.native_package(guide_id, version)
            if latest != source or fresh_payload != payload:
                raise DraftConflict("The agent team changed while preparing private setup. Reload before installing.")
        else:
            latest = await self.implementation.status(guide_id)
            require_accepted(latest)
            if (latest["build_id"] != status["build_id"] or latest["guide_version"] != status["guide_version"]
                    or not latest["current"] or latest.get("source_digest") != source["source_digest"]):
                raise DraftConflict("The application changed while preparing private setup. Reload before installing.")
        state = await self._guide(guide_id)
        if not package_matches(source, state) or source_kind == "native-team" and state["version"] != version:
            raise DraftConflict("The setup changed while preparing private setup. Reload before installing.")
        observation = observe_local_console_port(deployment["port"] if console_port is None else console_port,
                                                suggest_alternate=True) if supported or console_port is not None else None
        return {"build_id": status["build_id"], "guide_version": status["guide_version"],
                "source_digest": source["source_digest"], **native_fields(source),
                "current_guide_version": state["version"], "current": True,
                "default_destination": str(Path.home() / "src" / slug), "fields": fields,
                "configured_deployment_id": configured_deployment_id, "configured_destination": configured_destination,
                "console_port": deployment["port"], "can_use_host_provider_credentials": bool(keys) and supported,
                "host_provider_keys": keys if supported else [], "target": target, "host_target": host_target,
                "handoff": handoff, "console_scope": console_scope, "knowledge_mode": deployment["knowledge"]["mode"],
                "supported": supported, "default_execution_mode": "interactive",
                **({"console_port_observation": observation} if observation is not None else {}),
                "execution_modes": [
                    {"id": "interactive", "label": "While Forge is open", "available": supported,
                     "description": "Forge owns this process. Closing Forge stops the application and preserves its native state."},
                    {"id": "background", "label": "Run in the background", "available": background["available"],
                     "description": background.get("persistence", "Uses this logged-in user's operating-system service manager."),
                     "reason": background.get("detail"), "host_runtime_dependency": background.get("host_runtime_dependency")} ]}

    async def submit(self, guide_id, version, build_id, destination, settings=None, use_host_provider_credentials=False,
                     execution_mode="interactive", *, source_kind="application", source_id=None, source_digest=None):
        async with self.lock:
            if execution_mode not in {"interactive", "background"}:
                raise ValueError("Choose interactive or background deployment.")
            if execution_mode == "background" and not (await self.service_manager.capability())["available"]:
                raise ValueError("This user's operating-system service manager is unavailable. Choose interactive deployment.")
            state = await self._guide(guide_id)
            if state["version"] != version or state.get("operation", {}).get("status") == "running":
                raise DraftConflict("The guide is changing. Install only the current checked proposal.")
            local_target(state.get("proposal") or state.get("blueprint") or {})
            if source_kind == "native-team":
                if build_id is not None:
                    raise ValueError("An agent-team package has no application build ID.")
                payload, source, _ = await self.native_package(guide_id, version)
                if source_id != source["source_id"] or source_digest != source["source_digest"]:
                    raise DraftConflict("The selected agent-team source changed. Reload its setup before installing.")
            elif source_kind == "application":
                if source_id is not None or source_digest is not None:
                    raise ValueError("Application installation uses its independently accepted build ID.")
                checked = await self.implementation.status(guide_id)
                if checked["build_id"] != build_id:
                    raise DraftConflict("A newer application build is selected.")
                require_accepted(checked)
                payload, _ = await self.implementation.package(guide_id, build_id)
            else:
                raise ValueError("Choose an application or native-team source.")
            files = package_files(payload)
            definition = json.loads(files["deployment.json"][0])
            if "runtimeCandidate" in definition:
                raise DraftConflict("This private runtime candidate is admitted only through the checked update of an existing stopped installation. Use that exact update or its forward recovery.")
            source = read_package_source(files)
            if source["build_id"] != build_id or not package_matches(source, state):
                raise DraftConflict("The package belongs to another proposal.")
            if source["blueprint_hash"] != proposal_hash(state.get("proposal") or state.get("blueprint")):
                raise DraftConflict("The package belongs to another design.")
            fields = package_configuration_fields(definition, files)
            console_authentication = package_console_scope(files, fields, state)["authentication"]
            target = owned_destination(destination)
            previous = None
            try:
                previous = self._directory(guide_id)
                receipt = await self.status(guide_id)
            except LookupError:
                receipt = None
            digest = hashlib.sha256(payload).hexdigest()
            same = receipt and receipt["build_id"] == build_id and receipt.get("source_kind", "application") == source_kind and receipt["package_sha256"] == digest and receipt["destination"] == str(target)
            if same and receipt.get("execution_mode", "interactive") != execution_mode:
                raise DraftConflict("This owned deployment uses another lifecycle mode. Keep its mode or choose a new empty destination.")
            if receipt and receipt["status"] in ACTIVE:
                if same:
                    return receipt
                raise DraftConflict("Stop this setup's current deployment before installing another one.")
            if (same and execution_mode == "interactive" and receipt["status"] != "stopped"):
                raise DraftConflict("Stop and verify cleanup of this installed application before changing settings or retrying setup.")
            if target.exists() and any(target.iterdir()) and not same:
                raise DraftConflict("This folder is not empty. Choose a new empty folder; Forge will not overwrite it.")
            if same:
                verify_destination(receipt, files, allow_missing=True)
            background_receipt = private_snapshot = existing = None
            if same and execution_mode == "background":
                from .deployment_service import require_stopped_service
                from .deployment_updates import checked_package

                def background_snapshot():
                    if self._directory(guide_id) != previous:
                        raise DraftConflict("A different installation is selected. Reload before retrying setup.")
                    current = read_receipt(previous)
                    if self._configuration_binding(current) != self._configuration_binding(receipt):
                        raise DraftConflict("The owned background installation changed. Reload before retrying setup.")
                    if current.get("service"):
                        return self._installed_configuration(guide_id, current["deployment_id"])[1]
                    # A partial install can retry before a service is created,
                    # but missing service metadata is never cleanup evidence.
                    process = self.processes.get(current["deployment_id"])
                    if (current.get("status") not in {"stopped", "failed", "interrupted"}
                            or current["deployment_id"] in self.tasks
                            or process is not None and process.returncode is None
                            or current.get("process_live") is True or current.get("runtime_pid") is not None
                            or current.get("service") is not None or current.get("service_supervisor_pid") is not None
                            or current.get("service_instance_id") is not None
                            or (current.get("update") or {}).get("status") in {
                                "snapshotting", "applying", "verifying", "restoring", "recovering-candidate",
                                "recovering-current", "recovery-needed"}):
                        raise DraftConflict("Stop and verify this owned background installation before retrying setup.")
                    checked_package(previous, "package.zip", current["package_sha256"])
                    verify_destination(current, files, allow_missing=True)
                    return current

                background_receipt = background_snapshot()
                if background_receipt.get("service"):
                    await require_stopped_service(previous, self.service_manager)
                    background_receipt = background_snapshot()
                existing, private_snapshot = private_configuration_snapshot(target)
            # Validate in memory before publishing ownership or a queued deployment.
            # Private values remain within setup and never enter model input or journals.
            values = await asyncio.to_thread(prepare_private_settings, target, fields,
                settings if settings is not None else {}, bool(use_host_provider_credentials), port=definition["port"],
                console_authentication=console_authentication,
                **({"existing_values": existing} if private_snapshot is not None else {}))
            async def check_current_package():
                if source_kind == "native-team":
                    fresh_payload, fresh_source, _ = await self.native_package(guide_id, version)
                    if fresh_source != source or fresh_payload != payload:
                        raise DraftConflict("The accepted team changed before installation. No configuration was saved and no process started.")
                    return
                checked = await self.implementation.status(guide_id)
                latest = await self._guide(guide_id)
                require_accepted(checked)
                if (latest["version"] != version or latest.get("operation", {}).get("status") == "running"
                        or self.implementation.selected_build_id(guide_id) != build_id
                        or checked["build_id"] != build_id or not checked["ready_to_package"] or not checked.get("current")
                        or not package_matches(source, latest)
                        or proposal_hash(latest.get("proposal") or latest.get("blueprint")) != source["blueprint_hash"]
                        or checked.get("source_digest") != source["source_digest"]):
                    raise DraftConflict("The proposal changed before deployment admission. No configuration was saved and no process started.")
            await check_current_package()
            # Preparation awaited private reads and authority checks. Verify the
            # destination again before publishing anything into it.
            target = owned_destination(destination)
            stopped_snapshot = None
            if same:
                verify_destination(receipt, files, allow_missing=True)
                if execution_mode == "interactive":
                    stopped_snapshot = self._installed_configuration(guide_id, receipt["deployment_id"])
            elif target.exists() and any(target.iterdir()):
                raise DraftConflict("This folder is not empty. Choose a new empty folder; Forge will not overwrite it.")
            created_paths, created_directories = [], []
            if same:
                directory = previous
            else:
                identity = str(uuid.uuid4())
                directory = self._directory(guide_id, identity)
                receipt = {"deployment_id": identity, "guide_id": guide_id, "guide_version": source["guide_version"],
                    "brief_hash": source["brief_hash"], "admitted_guide_version": version,
                           "build_id": build_id, "blueprint_hash": source["blueprint_hash"], "package_sha256": digest, **native_fields(source),
                           "destination": str(target), "target": "local", "execution_mode": execution_mode,
                           "status": "queued", "phase": "install",
                           "detail": "Preparing your owned deployment folder.", "created_at": now(), "updated_at": now(),
                           "checks": [], "progress": [], "logs": [], "console_url": None, "bootstrap": None,
                           "runtime_pid": None, "unresolved": json.loads(files["implementation-report.json"][0]).get("unresolved", []) if source_kind == "application" else []}
            with project_lock(target) if stopped_snapshot or background_receipt else nullcontext():
                if stopped_snapshot:
                    fresh = self._installed_configuration(guide_id, receipt["deployment_id"])
                    if (self._configuration_binding(fresh[1]) != self._configuration_binding(stopped_snapshot[1])
                            or fresh[-1] != stopped_snapshot[-1]):
                        raise DraftConflict("The installed source changed before private setup. Reload before saving.")
                if background_receipt:
                    background_snapshot()
                    if background_receipt.get("service"):
                        await require_stopped_service(previous, self.service_manager)
                    await check_current_package()
                    background_snapshot()
                    if private_configuration_snapshot(target)[1] != private_snapshot:
                        raise DraftConflict("Private settings changed during setup. Reload; the newer values were preserved.")
                # There is no asynchronous gap between the final source fence and admission.
                require_available_console_port(int(values["MOBKIT_PORT"]))
                try:
                    if not same:
                        directory.mkdir(parents=True, mode=0o700)
                        created_directories.append(directory)
                        target.mkdir(parents=True, exist_ok=True, mode=0o700)
                        (target / ".mobkit").mkdir(mode=0o700)
                        created_directories.append(target / ".mobkit")
                        for path in (directory / "receipt.json", target / OWNER_FILE):
                            created_paths.extend([path, path.with_suffix(".pending")])
                            write_private(path, receipt if path.parent == directory else ownership(receipt))
                        created_paths.append(directory / "package.zip")
                        descriptor = os.open(directory / "package.zip", os.O_CREAT | os.O_WRONLY | os.O_EXCL, 0o600)
                        with os.fdopen(descriptor, "wb") as stream:
                            stream.write(payload)
                        created_paths.extend([target / ".env", target / ".env.launch-pending", directory / "journal.lock"])
                    if background_receipt:
                        if values != existing:
                            replace_private_configuration(target, values, private_snapshot)
                    else:
                        write_private_settings(target, values)
                    journal(directory, "Installation admitted for this checked package.", status="queued", phase="install",
                            console_url=None, runtime_pid=None, bootstrap=None, checks=[],
                            startup_attempt_id=None, startup_console_health=None, startup_port_observation=None,
                            health="unknown", health_checked_at=None, process_live=False)
                    if not same:
                        created_paths.append((directory.parent / "latest.json").with_suffix(".pending"))
                        write_private(directory.parent / "latest.json", {"deployment_id": identity})
                except OSError:
                    if same:
                        journal(directory, "Private configuration could not be saved. No process started; retry setup explicitly.",
                                status="stopped" if stopped_snapshot or background_receipt and background_receipt.get("service") else "failed", phase="configure", console_url=None, runtime_pid=None, bootstrap=None,
                                health="failed", health_checked_at=None, process_live=False)
                    else:
                        # Only this submission's newly created files are discarded.
                        # An earlier selected deployment and an existing empty folder survive.
                        for path in reversed(created_paths):
                            try:
                                path.unlink(missing_ok=True)
                            except OSError:
                                pass
                        for path in reversed(created_directories):
                            try:
                                path.rmdir()
                            except OSError:
                                pass
                    raise ValueError("Private setup could not be saved. No process started; retry setup or choose another empty folder.") from None
                self._launch(directory, "install")
            return await self.status(guide_id)

    def _launch(self, directory, mode):
        receipt = read_receipt(directory)
        if receipt.get("execution_mode", "interactive") == "interactive":
            # Every new worker owns fresh teardown evidence. Transaction modes
            # cannot inherit an install/start completion marker from old bytes.
            lifecycle = str(uuid.uuid4())
            update_receipt(directory, interactive_lifecycle_id=lifecycle,
                           interactive_cleanup_attempt_id=None, interactive_cleanup=None)
            self.worker_admissions.pop(directory.name, None)
            self.worker_admissions[directory.name] = {"lifecycle_id": lifecycle, "spawn_started": False}
        self.tasks[directory.name] = asyncio.create_task(self._run(directory, mode))

    async def prepare_supervisor_refresh(self, guide_id, deployment_id, *, expected_service_digest):
        """Prepare host support separately from application update or startup."""
        async with self.lock:
            directory = self._directory(guide_id)
            receipt = read_receipt(directory)
            if receipt["deployment_id"] != deployment_id:
                raise DraftConflict("A newer deployment is now selected.")
            if deployment_id in self.tasks:
                raise DraftConflict("Wait for this deployment's active operation before preparing its supervisor.")
            from .deployment_service import require_stopped_service
            await require_stopped_service(directory, self.service_manager)
            from .deployment_supervisor import prepare
            return prepare(directory, expected_service_digest)

    async def apply_supervisor_refresh(self, guide_id, deployment_id, revision, *, expected_digest):
        """Publish only the exact prepared stopped-service source revision."""
        async with self.lock:
            directory = self._directory(guide_id)
            receipt = read_receipt(directory)
            if receipt["deployment_id"] != deployment_id:
                raise DraftConflict("A newer deployment is now selected.")
            if deployment_id in self.tasks:
                raise DraftConflict("Wait for this deployment's active operation before updating its supervisor.")
            from .deployment_supervisor import apply
            return await apply(directory, revision, self.service_manager, expected_digest=expected_digest)

    async def stage_update(self, guide_id, deployment_id, version, build_id):
        async with self.lock:
            receipt = await self.status(guide_id)
            if receipt.get("source_kind") == "native-team":
                raise DraftConflict("Agent-team source updates are not supported here. Keep this installation or choose a new empty destination.")
            if receipt["deployment_id"] != deployment_id:
                raise DraftConflict("A newer deployment is selected.")
            if ((receipt["status"] in ACTIVE and receipt.get("phase") in {"update", "recovery"})
                    or (receipt.get("update") or {}).get("status") in {"snapshotting", "applying", "verifying", "restoring", "recovering-candidate", "recovering-current", "recovery-needed"}):
                raise DraftConflict("Finish or recover the current update before staging another package.")
            state = await self._guide(guide_id)
            if state["version"] != version or state.get("operation", {}).get("status") == "running":
                raise DraftConflict("Wait for the current guide revision before staging an update.")
            local_target(state.get("proposal") or state.get("blueprint") or {})
            checked = await self.implementation.status(guide_id)
            require_accepted(checked)
            if checked["build_id"] != build_id or not checked.get("ready_to_package") or not checked.get("current"):
                raise DraftConflict("Choose the exact current independently accepted application.")
            if receipt["build_id"] == build_id:
                raise DraftConflict("This accepted application is already installed.")
            payload, _ = await self.implementation.package(guide_id, build_id)
            files = package_files(payload)
            report = json.loads(files["implementation-report.json"][0])
            runtime_target = None
            if "runtimeCandidate" in json.loads(files["deployment.json"][0]):
                # Only the implementation owner's pinned, accepted framework
                # can supply a previously selected candidate. No HTTP field or
                # package marker selects a new runtime for this deployment.
                runtime_target = await asyncio.to_thread(self.implementation.selected_runtime_target,
                    guide_id, build_id=build_id, source_digest=report.get("verification", {}).get("digest"))
                if runtime_target is None:
                    raise DraftConflict("The candidate package has no exact accepted host runtime selection.")
            current = await self.implementation.status(guide_id)
            require_accepted(current)
            latest = await self._guide(guide_id)
            if (latest["version"] != version or latest.get("operation", {}).get("status") == "running"
                    or current["build_id"] != build_id or not current.get("ready_to_package") or not current.get("current")
                    or current.get("source_digest") != report.get("verification", {}).get("digest")
                    or not package_matches(report, latest) or report.get("build_id") != build_id
                    or report.get("blueprint_hash") != proposal_hash(latest.get("proposal") or latest.get("blueprint"))):
                raise DraftConflict("The accepted application changed while preparing its update.")
            # No await separates the final source/design fences and publication.
            from .deployment_updates import stage
            if runtime_target is None:
                stage(self._directory(guide_id), payload, report)
            else:
                stage(self._directory(guide_id), payload, report, runtime_target=runtime_target)
            return await self.status(guide_id)

    async def _run(self, directory, mode):
        process = None
        code = None
        background_update = False
        try:
            receipt = read_receipt(directory)
            if receipt.get("execution_mode") == "background" and mode in {"update", "rollback", "recover-current"}:
                background_update = True
                from .deployment_service import update_background
                admission = receipt.get("update_action") or {}
                if admission.get("action") != ("apply-update" if mode == "update" else mode) or not admission.get("update_id"):
                    raise DraftConflict("An exact admitted background update action is required.")
                await update_background(directory, self.service_manager, mode, update_id=admission["update_id"])
                return
            from .deployment_worker import clean_environment
            source = str(Path(__file__).resolve().parents[1])
            environment = clean_environment()
            environment["PYTHONPATH"] = source
            arguments = [sys.executable, "-m", "launchkit.deployment_worker", str(directory), mode]
            if receipt.get("execution_mode", "interactive") == "interactive":
                # A fixed host wrapper records successful teardown, independently
                # of the application's startup/health result. No authored code
                # can supply the worker's completion signal.
                arguments = [sys.executable, "-c",
                    "import asyncio,sys; from launchkit.deployment import interactive_worker; "
                    "sys.exit(asyncio.run(interactive_worker(*sys.argv[1:])) or 0)",
                    str(directory), mode, receipt.get("interactive_lifecycle_id", "")]
            admission = self.worker_admissions.get(directory.name)
            if admission:
                admission["spawn_started"] = True
            spawning = asyncio.create_task(asyncio.create_subprocess_exec(*arguments,
                cwd=source, env=environment, stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL, start_new_session=True))
            try:
                process = await asyncio.shield(spawning)
            except asyncio.CancelledError:
                # Recover the admitted child handle before shutting down its owned stdin.
                process = await spawning
                raise
            self.processes[directory.name] = process
            code = await process.wait()
            receipt = read_receipt(directory)
            if receipt["status"] in ACTIVE and not (receipt.get("execution_mode") == "background" and receipt.get("service")):
                journal(directory, f"The deployment supervisor stopped (exit {code}). Retry from the saved folder.",
                        status="interrupted", console_url=None, runtime_pid=None)
        except asyncio.CancelledError:
            if process and process.returncode is None:
                if process.stdin:
                    process.stdin.close()
                try:
                    await asyncio.wait_for(process.wait(), WORKER_STOP_TIMEOUT)
                except asyncio.TimeoutError:
                    os.killpg(process.pid, 9)
                    try:
                        await asyncio.wait_for(process.wait(), PROCESS_FORCE_REAP_TIMEOUT)
                    except asyncio.TimeoutError:
                        raise RuntimeError("The owned deployment worker did not confirm exit after bounded force cleanup.") from None
            receipt = read_receipt(directory)
            if not (receipt.get("execution_mode") == "background" and receipt.get("service")):
                journal(directory, "Forge stopped. Your installed files and native state are preserved. Start again to resume.",
                        status="interrupted", console_url=None, runtime_pid=None)
            raise
        except Exception as error:
            if not background_update or read_receipt(directory)["status"] != "failed":
                journal(directory, f"The deployment supervisor could not start ({type(error).__name__}). Retry from the saved folder.",
                        status="failed", console_url=None, runtime_pid=None)
        finally:
            try:
                if process is not None:
                    latest = read_receipt(directory)
                    cleanup = latest.get("interactive_cleanup")
                    if (latest.get("execution_mode", "interactive") == "interactive"
                            and (latest.get("status") == "stopped" or cleanup is not None)):
                        if (interactive_cleanup_matches(latest, require_worker_exit=False)
                                and cleanup.get("supervisor_pid") == process.pid
                                and type(process.returncode) is int and process.returncode == cleanup.get("return_code")
                                and (code is None or type(code) is int and code == process.returncode)):
                            # Child teardown is provisional until this actual
                            # wrapper handle confirms its intact final exit.
                            update_receipt(directory, interactive_cleanup={**cleanup,
                                "worker_exit_confirmed": True, "worker_completed_at": now()})
                        else:
                            # Persist negative process evidence before losing its
                            # handle, so later reads cannot reuse a stale marker.
                            journal(directory, "The owned supervisor did not confirm an intact cleanup completion. Preserve this folder; settings and a fresh start remain blocked.",
                                    status="interrupted", console_url=None, runtime_pid=None, process_live=False,
                                    interactive_cleanup=None, interactive_cleanup_attempt_id=None)
            finally:
                self.tasks.pop(directory.name, None)
                self.processes.pop(directory.name, None)

    async def status(self, guide_id, *, state=None):
        if state is not None and (not isinstance(state, dict) or state.get("id") != guide_id):
            raise ValueError("Deployment evidence requires the matching detached guide state.")
        directory = self._directory(guide_id)
        receipt = read_receipt(directory)
        if receipt.get("update"):
            from .deployment_updates import transaction
            receipt, _, _ = transaction(directory, receipt["update"]["update_id"])
        if (receipt.get("execution_mode") == "background" and receipt.get("service")
                and not (directory.name in self.tasks and (not receipt.get("service_supervisor_pid")
                    or receipt.get("phase") in {"update", "recovery"}))):
            from .deployment_service import background_status
            receipt = await background_status(directory, self.service_manager)
        elif receipt["status"] in ACTIVE and directory.name not in self.tasks:
            receipt = journal(directory, "Forge was interrupted. The owned folder and native state are preserved; resume explicitly.",
                              status="interrupted", console_url=None, runtime_pid=None, process_live=False, health="unknown")
        state = state if state is not None else await self._guide(guide_id)
        brief_hash = receipt.get("brief_hash")
        if not brief_hash:
            # Legacy installed packages may already contain the independently
            # accepted full brief digest. Preserve their original provenance.
            try:
                from .deployment_updates import checked_package
                _, files = checked_package(directory, "package.zip", receipt["package_sha256"])
                report = json.loads(files["implementation-report.json"][0])
                brief_hash = report_brief_hash(report)
            except (OSError, ValueError, KeyError, DraftConflict):
                pass
        receipt["current"] = (artifact_matches(receipt, state, brief_hash=brief_hash) if brief_hash else bool(
            receipt.get("guide_id") == state.get("id") and type(receipt.get("guide_version")) is int and
            state["version"] == receipt["guide_version"] and
            proposal_hash(state.get("proposal") or state.get("blueprint")) == receipt["blueprint_hash"]))
        receipt["brief_hash"] = brief_hash
        receipt["current_guide_version"] = state["version"] if receipt["current"] else None
        from .deployment_service import background_update_capabilities
        receipt["update_capabilities"] = background_update_capabilities(directory, receipt)
        if receipt.get("source_kind") == "native-team":
            receipt["update_capabilities"].update(background_activation_supported=False,
                reason="Agent-team source updates are not supported here. Its installed source and state are preserved.")
        receipt["cleanup_recovery"] = self._cleanup_recovery(guide_id, receipt)
        return receipt

    def _cleanup_recovery(self, guide_id, receipt):
        if (receipt.get("execution_mode", "interactive") != "interactive" or receipt.get("service")
                or receipt.get("status") not in {"failed", "interrupted"}):
            return None
        result = {"available": False, "deployment_id": receipt.get("deployment_id"),
            "build_id": receipt.get("build_id"), "package_sha256": receipt.get("package_sha256"),
            "guide_version": receipt.get("guide_version"),
            "scope": "owned-interactive-cleanup"}
        if not interactive_cleanup_matches(receipt):
            result["reason"] = ("The failed runtime's cleanup has not been confirmed. A failed status or a free "
                "project lock does not prove its native children stopped. Preserve this folder; private settings remain locked.")
            return result
        try:
            snapshot = self._installed_configuration(guide_id, receipt["deployment_id"], required_status=receipt["status"])
        except (OSError, ValueError, KeyError, TypeError, DraftConflict):
            result["reason"] = "The installed source or remaining worker could not be verified. Keep this folder and inspect its deployment activity before recovery."
            return result
        if not self._installed_cleanup_matches(snapshot):
            result["reason"] = "The cleanup confirmation belongs to different installed source or ownership. Private settings remain locked."
            return result
        try:
            self._require_cleanup_supervisor_absent(receipt)
        except DraftConflict:
            result["reason"] = "The original owned supervisor's absence could not be confirmed. Wait for cleanup; private settings and a fresh start remain blocked."
            return result
        result["available"] = True
        result["source_digest"] = snapshot[-1]
        return result

    def _confirm_worker_not_admitted(self, guide_id, directory, admission):
        """Only this host's original admission can prove a subprocess never began."""
        receipt = read_receipt(directory)
        if (not admission or admission is not self.worker_admissions.get(directory.name)
                or admission.get("spawn_started") is not False
                or admission.get("lifecycle_id") != receipt.get("interactive_lifecycle_id")
                or receipt.get("execution_mode", "interactive") != "interactive" or receipt.get("service")
                or receipt.get("startup_attempt_id") is not None or receipt.get("runtime_pid") is not None
                or directory.name in self.tasks or directory.name in self.processes
                or self._directory(guide_id) != directory):
            return False
        destination = owned_destination(receipt["destination"])
        with project_lock(destination):
            source_binding = interactive_source_binding(directory, receipt, allow_missing=True)
            latest = read_receipt(directory)
            if self._configuration_binding(latest) != self._configuration_binding(receipt):
                raise DraftConflict("This installation changed before worker cancellation could be verified.")
            binding = {key: latest.get(key) for key in ("deployment_id", "guide_id", "build_id", "guide_version",
                "blueprint_hash", "destination", "package_sha256", "startup_attempt_id")}
            binding.update(native_fields(latest))
            journal(directory, "The owned worker was cancelled before subprocess admission. No runtime was started; the checked package and folder are preserved.",
                status="stopped", phase="stop", runtime_pid=None, console_url=None, process_live=False,
                interactive_cleanup={**binding, **source_binding, "lifecycle_id": admission["lifecycle_id"],
                    "boundary": "worker-not-admitted", "confirmed": True, "supervisor_pid": os.getpid(),
                    "return_code": 0, "completed_at": now(), "worker_exit_confirmed": True}, interactive_cleanup_attempt_id=None)
        return True

    def _reconcile_absent_cleanup_supervisor(self, guide_id, deployment_id, directory, before):
        """Observe cold-host absence without claiming a captured wrapper exit code."""
        latest = read_receipt(directory)
        cleanup = latest.get("interactive_cleanup") or {}
        if (deployment_id in self.tasks or deployment_id in self.processes
                or deployment_id in self.worker_admissions
                or self._configuration_binding(latest) != self._configuration_binding(before)
                or latest.get("status") != before.get("status")
                or latest.get("status") not in {"failed", "interrupted"}
                or latest.get("execution_mode", "interactive") != "interactive" or latest.get("service")
                or latest.get("process_live") is not False or latest.get("runtime_pid") is not None
                or not interactive_cleanup_matches(latest, require_worker_exit=False)
                or cleanup.get("worker_exit_confirmed") is not False
                or cleanup.get("boundary") != "owned-process-groups-absent"):
            raise DraftConflict("The failed runtime's cleanup is unconfirmed. No cold-host reconciliation was admitted.")
        snapshot = self._installed_configuration(guide_id, deployment_id, required_status=latest["status"])
        try:
            with project_lock(snapshot[2]):
                # Hold the receipt journal across the final source, ownership and
                # absence checks. A free project lease supplies no teardown proof.
                with receipt_lock(directory):
                    fresh = self._installed_configuration(guide_id, deployment_id, required_status=latest["status"])
                    if (self._configuration_binding(fresh[1]) != self._configuration_binding(latest)
                            or fresh[-1] != snapshot[-1]
                            or deployment_id in self.tasks or deployment_id in self.processes
                            or deployment_id in self.worker_admissions
                            or cleanup.get("source_digest") != fresh[-1]
                            or cleanup.get("owner_sha256") != hashlib.sha256((fresh[2] / OWNER_FILE).read_bytes()).hexdigest()):
                        raise DraftConflict("The installed source or cleanup ownership changed before cold-host reconciliation.")
                    self._require_cleanup_supervisor_absent(fresh[1])
                    # Native teardown was positively recorded by this exact
                    # worker. Its actual OS return code is unavailable on a cold
                    # host; preserve both the saved result and the false flag.
                    observed = now()
                    value = fresh[1]
                    value.update(interactive_cleanup={**cleanup,
                        "supervisor_absence_confirmed": True,
                        "supervisor_absence_scope": "cold-host-owned-native-teardown",
                        "supervisor_absence_observed_at": observed}, updated_at=observed)
                    write_private(directory / "receipt.json", value)
                    return value
        except RuntimeError:
            raise DraftConflict("The installed project is still in use. No cold-host cleanup reconciliation was saved.") from None

    async def _stop_failed_interactive(self, guide_id, deployment_id):
        directory = self._directory(guide_id, deployment_id)
        before = read_receipt(directory)
        if (before.get("execution_mode", "interactive") != "interactive" or before.get("service")
                or before.get("status") not in {"failed", "interrupted"}):
            raise DraftConflict("This installation needs its normal lifecycle controls.")
        process, task = self.processes.get(deployment_id), self.tasks.get(deployment_id)
        if process is not None and process.returncode is None:
            if process.stdin is None:
                raise DraftConflict("The owned worker cannot confirm cleanup. No process was replaced.")
            process.stdin.write(b'{"action":"stop"}\n')
            try:
                await process.stdin.drain()
            except (BrokenPipeError, ConnectionResetError):
                pass  # Its actual return and the fixed cleanup record still gate recovery.
        try:
            if task is not None:
                await asyncio.wait_for(asyncio.shield(task), WORKER_STOP_TIMEOUT)
            elif process is not None:
                await asyncio.wait_for(process.wait(), WORKER_STOP_TIMEOUT)
        except asyncio.TimeoutError:
            raise DraftConflict("The owned worker has not finished cleanup. No private settings were changed.") from None
        latest = read_receipt(directory)
        if process is None and task is None and not interactive_cleanup_matches(latest):
            latest = self._reconcile_absent_cleanup_supervisor(guide_id, deployment_id, directory, before)
        if (latest.get("interactive_lifecycle_id") != before.get("interactive_lifecycle_id")
                or process is not None and ((latest.get("interactive_cleanup") or {}).get("supervisor_pid") != process.pid
                    or type(process.returncode) is not int
                    or process.returncode != (latest.get("interactive_cleanup") or {}).get("return_code"))
                or not interactive_cleanup_matches(latest)):
            raise DraftConflict("The failed runtime's cleanup is unconfirmed. No stopped state or private-settings access was granted.")
        # Full installed source and receipt authority, plus positive owned
        # teardown, precede the project lease. A lock alone cannot prove cleanup.
        snapshot = self._installed_configuration(guide_id, deployment_id, required_status=latest["status"])
        try:
            with project_lock(snapshot[2]):
                fresh = self._installed_configuration(guide_id, deployment_id, required_status=latest["status"])
                if (self._configuration_binding(fresh[1]) != self._configuration_binding(snapshot[1])
                        or fresh[-1] != snapshot[-1] or not self._installed_cleanup_matches(fresh)):
                    raise DraftConflict("This installation changed during cleanup verification. Reload before recovery.")
                self._require_cleanup_supervisor_absent(fresh[1])
                journal(directory, "The owned runtime finished cleanup and its installed source was verified. Change private settings if needed, then start this installed application explicitly.",
                    status="stopped", phase="stop", runtime_pid=None, console_url=None, process_live=False)
        except RuntimeError:
            raise DraftConflict("The installed project is still in use. Stop its other owned process before cleanup recovery.") from None
        return await self.status(guide_id)

    async def guide_status(self, guide_id, *, state):
        """Project exact installed source evidence without importing application code."""
        receipt = await self.status(guide_id, state=state)
        result = {**receipt, "source_verified": False, "source_digest": None}
        try:
            from .deployment_updates import checked_package
            _, files = checked_package(self._directory(guide_id), "package.zip", receipt["package_sha256"])
            source = read_package_source(files, receipt)
            digest = source["source_digest"]
            destination = verify_destination(receipt, files)
            for name in files:
                info = (destination / name).stat()
                if info.st_uid != os.getuid() or info.st_nlink != 1:
                    return result
            result.update(source_verified=True, source_digest=digest)
        except (OSError, ValueError, KeyError, TypeError, DraftConflict):
            # A failed source check is evidence of uncertainty, never a model
            # instruction to repair source or permission to use old acceptance.
            pass
        return result

    async def experiences(self, guide_id):
        from .deployment_experiences import installed_application_experiences
        return await installed_application_experiences(self, guide_id)

    async def use(self, guide_id):
        from .installed_feedback import installed_application_use
        return await installed_application_use(self, guide_id)

    async def record_success(self, guide_id, version, deployment_id, build_id, source_digest,
                             package_sha256, *, request_id, task):
        from .installed_feedback import record_installed_success
        return await record_installed_success(self, guide_id, version, deployment_id, build_id,
            source_digest, package_sha256, request_id=request_id, task=task)

    async def feedback(self, guide_id, version, deployment_id, build_id, source_digest, package_sha256,
                       continuation_build_id, continuation_source_digest, *, request, outcome, task="",
                       continue_current_candidate=False):
        from .installed_feedback import improve_installed_application
        return await improve_installed_application(self, guide_id, version, deployment_id, build_id, source_digest,
            package_sha256, continuation_build_id, continuation_source_digest, request=request, outcome=outcome,
            task=task, continue_current_candidate=continue_current_candidate)

    async def action(self, guide_id, deployment_id, action, update_id=None):
        async with self.lock:
            directory = self._directory(guide_id)
            receipt = await self.status(guide_id)
            if receipt["deployment_id"] != deployment_id:
                raise DraftConflict("A newer deployment is now selected.")
            if action not in {"stop", "restart", "retry", "apply-update", "rollback", "recover-current"}:
                raise ValueError("Choose a supported deployment action.")
            if receipt.get("source_kind") == "native-team" and action in {"apply-update", "rollback", "recover-current"}:
                raise DraftConflict("Agent-team source updates are not supported here. Its installed source and state are preserved.")
            if (action == "stop" and receipt.get("execution_mode", "interactive") == "interactive"
                    and not receipt.get("service") and receipt["status"] in {"failed", "interrupted"}):
                return await self._stop_failed_interactive(guide_id, deployment_id)
            if action in {"apply-update", "rollback", "recover-current"}:
                from .deployment_updates import CURRENT_RECOVERY_STATES, transaction
                _, _, update = transaction(directory, update_id)
                background = receipt.get("execution_mode") == "background"
                if background:
                    from .deployment_service import require_stopped_service, require_candidate_update_protocol
                    if not receipt.get("update_capabilities", {}).get("background_activation_supported"):
                        raise DraftConflict(receipt.get("update_capabilities", {}).get("reason") or "The owned background update adapter could not be verified.")
                    if receipt["status"] != "stopped":
                        raise DraftConflict("Stop and verify this exact owned background service before changing its installed source.")
                    stopped_service = await require_stopped_service(directory, self.service_manager)
                    if action != "rollback":
                        require_candidate_update_protocol(stopped_service, update)
                if receipt["status"] in ACTIVE or deployment_id in self.tasks:
                    raise DraftConflict("Stop and verify this owned runtime before changing installed source.")
                if action in {"apply-update", "recover-current"}:
                    eligible = {"staged", "snapshotting"} if action == "apply-update" else CURRENT_RECOVERY_STATES
                    if update["status"] not in eligible or update["blockers"]:
                        raise DraftConflict("This staged package has update requirements that must be resolved first.")
                    checked = await self.implementation.status(guide_id)
                    require_accepted(checked)
                    latest = await self._guide(guide_id)
                    if (not current_version(checked, latest) or latest.get("operation", {}).get("status") == "running"
                            or checked["build_id"] != update["to_build_id"] or not checked.get("ready_to_package")
                            or not checked.get("current") or checked.get("source_digest") != update["source_digest"]
                            or proposal_hash(latest.get("proposal") or latest.get("blueprint")) != update["blueprint_hash"]
                            or update.get("brief_hash") and update["brief_hash"] != fingerprint(latest.get("brief") or {})
                            or not update.get("brief_hash") and latest["version"] != update["guide_version"]):
                        raise DraftConflict("The staged application is no longer the current accepted build.")
                    # Reconcile the exact journal again after awaited authority
                    # checks; a replaced pointer cannot launch a stale action.
                    _, _, current_update = transaction(directory, update_id)
                    if current_update != update:
                        raise DraftConflict("The update changed while admitting this action. Review its current receipt.")
                elif update["status"] not in {"completed", "applying", "verifying", "restoring", "recovering-candidate", "recovering-current", "candidate-restored-stopped", "recovery-needed"} or not update["rollback_available"]:
                    raise DraftConflict("There is no previously activated package to restore for this update.")
                if background:
                    await require_stopped_service(directory, self.service_manager)
                    if action in {"apply-update", "recover-current"}:
                        checked = await self.implementation.status(guide_id)
                        require_accepted(checked)
                        latest = await self._guide(guide_id)
                        if (latest.get("operation", {}).get("status") == "running"
                                or self.implementation.selected_build_id(guide_id) != update["to_build_id"]
                                or checked.get("build_id") != update["to_build_id"]
                                or checked.get("source_digest") != update["source_digest"]
                                or not checked.get("current") or not checked.get("ready_to_package")
                                or not current_version(checked, latest)
                                or proposal_hash(latest.get("proposal") or latest.get("blueprint")) != update["blueprint_hash"]
                                or update.get("brief_hash") and update["brief_hash"] != fingerprint(latest.get("brief") or {})
                                or not update.get("brief_hash") and latest["version"] != update["guide_version"]):
                            raise DraftConflict("The accepted application changed before background update admission.")
                    final_service = await require_stopped_service(directory, self.service_manager)
                    _, _, final_update = transaction(directory, update_id)
                    if final_update != update:
                        raise DraftConflict("The exact background update changed before admission.")
                    if action != "rollback":
                        require_candidate_update_protocol(final_service, final_update)
                journal(directory, "Update action admitted. Waiting for the installed project's exclusive lease.",
                        status="queued", phase="update", runtime_pid=None, console_url=None, bootstrap=None,
                        startup_attempt_id=None, startup_console_health=None,
                        health="unknown", health_checked_at=None, process_live=False,
                        update_service_verification=None,
                        update_action={"action": action, "update_id": update_id})
                self._launch(directory, {"apply-update": "update", "rollback": "rollback", "recover-current": "recover-current"}[action])
                return await self.status(guide_id)
            if receipt.get("execution_mode") == "background" and receipt.get("service"):
                from .deployment_service import verify_service, stop_background
                if deployment_id in self.tasks:
                    # Finish/cancel the installer-to-manager handoff first. It
                    # must not start a unit after a concurrent user stop.
                    task = self.tasks[deployment_id]
                    task.cancel()
                    await asyncio.gather(task, return_exceptions=True)
                    self.tasks.pop(deployment_id, None)
                    receipt = read_receipt(directory)
                service = verify_service(directory, receipt)
                if action == "stop":
                    return await stop_background(directory, self.service_manager)
                if action == "restart":
                    payload = (directory / "package.zip").read_bytes()
                    if hashlib.sha256(payload).hexdigest() != receipt["package_sha256"]:
                        raise DraftConflict("The saved checked package changed. No process was started.")
                    files = package_files(payload)
                    destination = verify_destination(receipt, files)
                    validate_installed_console_settings(files, destination)
                    stopped = await stop_background(directory, self.service_manager)
                    if stopped["status"] != "stopped":
                        raise DraftConflict("The previous native runtime did not confirm shutdown. No replacement was started.")
                    require_available_console_port(installed_console_port(destination, json.loads(files["deployment.json"][0])["port"]))
                    journal(directory, "Restart admitted for this owned background service.", status="starting",
                            runtime_pid=None, console_url=None, bootstrap=None, service_cleanup_confirmed=False,
                            startup_attempt_id=None, startup_console_health=None, startup_port_observation=None,
                            health="unknown", health_checked_at=None, process_live=False)
                    await self.service_manager.start(service)
                    return await self.status(guide_id)
                stopped = await stop_background(directory, self.service_manager)
                if stopped["status"] != "stopped":
                    raise DraftConflict("Stop and verify the existing service before retrying installation.")
                receipt = stopped
            if action == "stop":
                process = self.processes.get(deployment_id)
                if receipt["status"] not in ACTIVE:
                    return receipt
                journal(directory, "Stopping your application and native runtime.", status="stopping")
                if process and process.stdin:
                    process.stdin.write(b'{"action":"stop"}\n')
                    await process.stdin.drain()
                elif deployment_id in self.tasks:
                    task = self.tasks[deployment_id]
                    admission = self.worker_admissions.get(deployment_id)
                    task.cancel()
                    await asyncio.gather(task, return_exceptions=True)
                    self.tasks.pop(deployment_id, None)
                    if not self._confirm_worker_not_admitted(guide_id, directory, admission):
                        journal(directory, "The worker ended; runtime cleanup still needs verification before settings or a fresh start.",
                                status="interrupted", console_url=None, runtime_pid=None, process_live=False)
                        await self._stop_failed_interactive(guide_id, deployment_id)
                return await self.status(guide_id)
            if receipt["status"] in ACTIVE:
                raise DraftConflict("Stop the application before restarting it.")
            if (receipt.get("update") or {}).get("status") in {"applying", "verifying", "restoring", "recovering-candidate", "recovering-current", "recovery-needed"}:
                raise DraftConflict("Recover the interrupted update before starting this installed source.")
            if (receipt.get("execution_mode", "interactive") == "interactive" and not receipt.get("service")
                    and receipt["status"] in {"failed", "interrupted"}
                    and (receipt.get("update") or {}).get("status") not in {"restored-stopped", "candidate-restored-stopped"}):
                # A failed parent may have left a native child behind. An
                # available lease or a retry click cannot replace teardown.
                await self._stop_failed_interactive(guide_id, deployment_id)
                if self._directory(guide_id) != directory:
                    raise DraftConflict("A different installation was selected during cleanup. Reload before starting.")
                receipt = read_receipt(directory)
            process = self.processes.get(deployment_id)
            if deployment_id in self.tasks or process is not None and process.returncode is None:
                raise DraftConflict("Wait for this installation's owned worker to finish cleanup before starting again.")
            interactive = receipt.get("execution_mode", "interactive") == "interactive" and not receipt.get("service")
            if interactive and receipt.get("interactive_lifecycle_id") is not None and not interactive_cleanup_matches(receipt):
                raise DraftConflict("The owned runtime's cleanup is unconfirmed. Stop and verify cleanup before a fresh start.")
            payload = (directory / "package.zip").read_bytes()
            if hashlib.sha256(payload).hexdigest() != receipt["package_sha256"]:
                raise DraftConflict("The saved checked package changed. No process was started.")
            files = package_files(payload)
            destination = verify_destination(receipt, files, allow_missing=action == "retry")
            with project_lock(destination) if interactive else nullcontext():
                validate_installed_console_settings(files, destination)
                if interactive and receipt.get("interactive_lifecycle_id") is not None:
                    checked_cleanup = interactive_source_binding(directory, receipt,
                        allow_missing=(receipt.get("interactive_cleanup") or {}).get("boundary") == "worker-not-admitted")
                    if any(receipt["interactive_cleanup"].get(key) != value for key, value in checked_cleanup.items()):
                        raise DraftConflict("The cleanup confirmation belongs to different installed source or ownership.")
                    self._require_cleanup_supervisor_absent(receipt)
                require_available_console_port(installed_console_port(destination, json.loads(files["deployment.json"][0])["port"]))
                journal(directory, "Restart admitted for the installed checked source.", status="queued",
                        phase="install" if action == "retry" else "start", console_url=None, runtime_pid=None, bootstrap=None,
                        startup_attempt_id=None, startup_console_health=None, startup_port_observation=None,
                        health="unknown", health_checked_at=None, process_live=False)
                self._launch(directory, "install" if action == "retry" else "start")
            return await self.status(guide_id)

    async def shutdown(self):
        identities = list(self.tasks)
        pending = list(self.tasks.values())
        for task in pending:
            task.cancel()
        await asyncio.gather(*pending, return_exceptions=True)
        for identity in identities:
            for directory in self.root.glob(f"*/{identity}"):
                receipt = read_receipt(directory)
                if receipt["status"] in ACTIVE and not (receipt.get("execution_mode") == "background" and receipt.get("service")):
                    journal(directory, "Forge stopped before deployment completed. Resume explicitly from the saved owned folder.",
                            status="interrupted", console_url=None, runtime_pid=None, process_live=False)
            self.tasks.pop(identity, None)
            self.processes.pop(identity, None)
