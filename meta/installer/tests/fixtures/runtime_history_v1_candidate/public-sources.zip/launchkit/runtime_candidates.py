"""Read external candidate bytes against an independently accepted host binding.

This is an integrity reader, not candidate admission or signature verification.
The caller must already have accepted the producer's cryptographic provenance
and the exact native/local-SDK tuple. A digest, a constructed CandidateBinding,
or a JSON ``verified=true`` flag cannot establish that authority. No artifact is
extracted, imported, executed, installed, downloaded, or changed here.
"""
from __future__ import annotations

import base64
from contextlib import contextmanager
import csv
from dataclasses import asdict, dataclass
from email.parser import BytesParser
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile
import zipfile

# Existing installer native and distribution bounds, applied to external bytes.
MAX_ARCHIVE_BYTES = 256 * 1024 * 1024
MAX_BINARY_BYTES = 512 * 1024 * 1024
MAX_TAR_OVERHEAD = 1024 * 1024
MAX_METADATA_BYTES = 1024 * 1024
MAX_WHEEL_BYTES = 32 * 1024 * 1024
MAX_WHEEL_TOTAL = 64 * 1024 * 1024
MAX_WHEEL_FILES = 4096
HEX = re.compile(r"[a-f0-9]{64}")
VERSION = re.compile(r"[0-9]+\.[0-9]+\.[0-9]+")
PLATFORMS = frozenset({"aarch64-apple-darwin", "x86_64-apple-darwin",
    "aarch64-unknown-linux-gnu", "x86_64-unknown-linux-gnu"})
BINARIES = {"mobkit_gateway": "mobkit-gateway", "mobkit_repair": "mobkit-repair",
    "rpc_gateway": "mobkit-rpc-gateway"}


class CandidateArtifactError(ValueError):
    """Candidate identity, ownership, bounds, or artifact integrity changed."""


@dataclass(frozen=True)
class CandidateBinding:
    """Exact caller-accepted identity. Constructing it does not confer admission."""

    tuple_sha256: str
    repository: str
    source_sha: str
    native_version: str
    core_version: str
    platform: str
    native_run_id: int
    native_run_attempt: int
    native_manifest_sha256: str
    sdk_wheel_sha256: str


@dataclass(frozen=True)
class ArtifactFile:
    path: Path
    size: int
    sha256: str


@dataclass(frozen=True)
class NativeArtifact:
    binary: str
    archive: ArtifactFile
    inner_name: str
    inner_size: int
    inner_sha256: str


@dataclass(frozen=True)
class SdkArtifact:
    wheel: ArtifactFile
    payload: tuple[tuple[str, str], ...]
    origin: str = "local-build-from-exact-frozen-source"
    signed: bool = False
    published: bool = False


@dataclass(frozen=True)
class CandidateArtifacts:
    identity: CandidateBinding
    tuple_file: ArtifactFile
    native: tuple[NativeArtifact, ...]
    sdk: SdkArtifact
    evidence: tuple[ArtifactFile, ...]
    native_origin: str = "signed-candidate"


def _require(condition, message):
    if not condition:
        raise CandidateArtifactError(message)


def _digest(value):
    return hashlib.sha256(value).hexdigest()


def _hex(value):
    return isinstance(value, str) and HEX.fullmatch(value) is not None


def _positive(value):
    return type(value) is int and value > 0


def _unique(pairs):
    result = {}
    for name, value in pairs:
        _require(name not in result, "Candidate JSON has duplicate keys.")
        result[name] = value
    return result


def _json(content):
    def invalid_constant(_):
        raise CandidateArtifactError("Candidate JSON contains a non-finite number.")
    try:
        result = json.loads(content, object_pairs_hook=_unique, parse_constant=invalid_constant)
        _require(isinstance(result, dict), "Candidate JSON must be an object.")
        return result
    except (UnicodeError, json.JSONDecodeError) as error:
        raise CandidateArtifactError("Candidate JSON is invalid.") from error


def _fingerprint(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_nlink,
        info.st_size, info.st_mtime_ns, info.st_ctime_ns)


class _Inputs:
    def __init__(self, root):
        self.root = Path(root)
        _require(self.root.is_absolute() and str(self.root) == str(root) and ".." not in self.root.parts,
            "The external artifact root must be an absolute canonical path.")
        _require(not any(path.is_symlink() for path in (self.root, *self.root.parents)),
            "The external artifact root contains a link.")
        info = self.root.lstat()
        _require(stat.S_ISDIR(info.st_mode) and info.st_uid == os.getuid(),
            "The external artifact root must be an owned ordinary directory.")
        self.files = {}

    def path(self, value):
        _require(isinstance(value, (str, Path)), "An artifact path is missing.")
        path = Path(value)
        _require(path.is_absolute() and str(path) == str(value)
            and ".." not in path.parts and path.is_relative_to(self.root),
            "Candidate artifacts must stay inside the external artifact root.")
        _require(not any(parent.is_symlink() for parent in (path, *path.parents)),
            "A candidate artifact path contains a link.")
        _require(path.parent.stat().st_uid == os.getuid(),
            "A candidate artifact directory is not owned by this user.")
        return path

    @contextmanager
    def open(self, path, limit):
        path = self.path(path)
        before = path.lstat()
        _require(stat.S_ISREG(before.st_mode), "A candidate artifact is not an ordinary file.")
        descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(descriptor, "rb") as handle:
            info = os.fstat(handle.fileno())
            _require(_fingerprint(before) == _fingerprint(info)
                and info.st_uid == os.getuid() and info.st_nlink == 1
                and 0 < info.st_size <= limit,
                "A candidate artifact is not an owned bounded ordinary file.")
            if path in self.files:
                _require(self.files[path][1] == _fingerprint(info),
                    "A candidate artifact changed during verification.")
            yield handle, info
            _require(_fingerprint(info) == _fingerprint(os.fstat(handle.fileno()))
                and _fingerprint(info) == _fingerprint(path.lstat()),
                "A candidate artifact changed during verification.")

    def read(self, path, expected, limit, *, keep=True, size=None):
        _require(_hex(expected), "An artifact SHA-256 binding is invalid.")
        path = self.path(path)
        hashed, total, chunks = hashlib.sha256(), 0, []
        with self.open(path, limit) as (handle, info):
            while chunk := handle.read(1024 * 1024):
                total += len(chunk)
                _require(total <= limit, "A candidate artifact exceeds its byte bound.")
                hashed.update(chunk)
                if keep:
                    chunks.append(chunk)
            _require(total == info.st_size and (size is None or total == size)
                and hashed.hexdigest() == expected, "Candidate artifact bytes do not match their binding.")
            artifact = ArtifactFile(path, total, expected)
            self.files[path] = artifact, _fingerprint(info)
        return artifact, b"".join(chunks) if keep else None

    def finish(self):
        for path, (_, fingerprint) in self.files.items():
            self.path(path)
            _require(_fingerprint(path.lstat()) == fingerprint,
                "A candidate artifact changed during verification.")


class _BoundedExpansion:
    def __init__(self, handle):
        self.handle, self.total = handle, 0

    def read(self, size=-1):
        remaining = MAX_BINARY_BYTES + MAX_TAR_OVERHEAD + 1 - self.total
        data = self.handle.read(remaining if size < 0 else min(size, remaining))
        self.total += len(data)
        _require(self.total <= MAX_BINARY_BYTES + MAX_TAR_OVERHEAD,
            "A native archive expands beyond the installer bound.")
        return data


def _native(inputs, directory, record, binding):
    _require(isinstance(record, dict) and set(record) == {"binary", "inner", "name", "sha256", "size", "target"},
        "A native archive record is invalid.")
    binary, inner = record["binary"], record["inner"]
    _require(binary in BINARIES and record["target"] == binding.platform
        and record["name"] == f"{BINARIES[binary]}-{binding.native_version}-{binding.platform}.tar.gz"
        and _positive(record["size"]) and record["size"] <= MAX_ARCHIVE_BYTES
        and isinstance(inner, dict) and set(inner) == {"name", "sha256", "size"}
        and inner["name"] == binary and _positive(inner["size"])
        and inner["size"] <= MAX_BINARY_BYTES and _hex(inner["sha256"]),
        "A native archive identity or size is invalid.")
    artifact, _ = inputs.read(directory / record["name"], record["sha256"],
        MAX_ARCHIVE_BYTES, keep=False, size=record["size"])
    with inputs.open(artifact.path, MAX_ARCHIVE_BYTES) as (handle, _):
        with gzip.GzipFile(fileobj=handle, mode="rb") as compressed:
            expanded = _BoundedExpansion(compressed)
            with tarfile.open(fileobj=expanded, mode="r|") as archive:
                member = archive.next()
                _require(member is not None and member.name == binary and member.isfile()
                    and member.sparse is None and member.size == inner["size"]
                    and member.mode & 0o111, "A native archive must contain one flat ordinary executable.")
                source = archive.extractfile(member)
                _require(source is not None, "The native archive payload is missing.")
                hashed, size = hashlib.sha256(), 0
                with source:
                    while chunk := source.read(1024 * 1024):
                        size += len(chunk)
                        _require(size <= MAX_BINARY_BYTES, "A native archive payload exceeds its bound.")
                        hashed.update(chunk)
                _require(size == inner["size"] and hashed.hexdigest() == inner["sha256"]
                    and archive.next() is None, "The native archive payload or flat inventory changed.")
            while expanded.read(1024 * 1024):
                pass
    return NativeArtifact(binary, artifact, inner["name"], inner["size"], inner["sha256"])


def _wheel(content, version, payload, sizes):
    _require(isinstance(payload, dict) and payload and len(payload) <= MAX_WHEEL_FILES
        and all(isinstance(name, str) and name.startswith("meerkat_mobkit/")
            and _hex(hashed) for name, hashed in payload.items()), "The SDK source inventory is invalid.")
    prefix = f"meerkat_mobkit-{version}.dist-info/"
    metadata_names = {prefix + name for name in ("METADATA", "WHEEL", "RECORD", "top_level.txt")}
    with zipfile.ZipFile(io.BytesIO(content)) as archive:
        entries = archive.infolist()
        names = [entry.filename for entry in entries]
        _require(len(names) == len(set(names)) == len({name.casefold() for name in names})
            and set(names) == set(payload) | metadata_names and len(names) <= MAX_WHEEL_FILES,
            "The SDK wheel has a duplicate or unexpected inventory.")
        _require(sum(entry.file_size for entry in entries) <= MAX_WHEEL_TOTAL,
            "The SDK wheel exceeds its total byte bound.")
        values = {}
        for entry in entries:
            name, path, mode = entry.filename, PurePosixPath(entry.filename), entry.external_attr >> 16
            _require(not path.is_absolute() and path.as_posix() == name
                and not any(part in ("", ".", "..") for part in path.parts)
                and not any(ord(char) < 32 or char in "\\:" for char in name)
                and not entry.is_dir() and stat.S_IFMT(mode) in (0, stat.S_IFREG)
                and not entry.flag_bits & 1 and 0 <= entry.file_size <= MAX_WHEEL_BYTES,
                "The SDK wheel contains an invalid path, link, or oversized member.")
            with archive.open(entry) as source:
                value = source.read(MAX_WHEEL_BYTES + 1)
            _require(len(value) == entry.file_size, "An SDK wheel member exceeds its byte bound.")
            values[name] = value
        metadata = BytesParser().parsebytes(values[prefix + "METADATA"])
        wheel = BytesParser().parsebytes(values[prefix + "WHEEL"])
        _require(metadata.get_all("Name") == ["meerkat-mobkit"]
            and metadata.get_all("Version") == [version]
            and wheel.get_all("Wheel-Version") == ["1.0"]
            and wheel.get_all("Root-Is-Purelib") == ["true"]
            and wheel.get_all("Tag") == ["py3-none-any"]
            and values[prefix + "top_level.txt"].strip() == b"meerkat_mobkit",
            "The SDK wheel has an unexpected package or platform identity.")
        rows = list(csv.reader(io.StringIO(values[prefix + "RECORD"].decode("utf-8"))))
        _require(all(len(row) == 3 for row in rows) and len(rows) == len(names)
            and len({row[0] for row in rows}) == len(rows) and {row[0] for row in rows} == set(names),
            "The SDK wheel RECORD has a duplicate or incomplete inventory.")
        for name, recorded_hash, recorded_size in rows:
            if name == prefix + "RECORD":
                _require(recorded_hash == recorded_size == "", "The SDK wheel RECORD self-entry is invalid.")
            else:
                hashed = base64.urlsafe_b64encode(hashlib.sha256(values[name]).digest()).decode().rstrip("=")
                _require(recorded_hash == "sha256=" + hashed and recorded_size == str(len(values[name])),
                    "An SDK wheel RECORD digest or size changed.")
        _require(all(_digest(values[name]) == hashed and type(sizes[name]) is int
            and len(values[name]) == sizes[name] for name, hashed in payload.items()),
            "The SDK wheel payload differs from its exact source inventory.")
    return tuple(sorted(payload.items()))


def read_candidate_artifacts(tuple_path, *, accepted: CandidateBinding, artifact_root: Path) -> CandidateArtifacts:
    """Recheck one already admitted external tuple without changing any state.

    ``accepted`` must come from the caller's protected host acceptance, never
    reconstructed as authority from this file. The external root keeps native
    payloads outside the bounded text application package. Returned paths are
    verified read-time metadata, not open handles or permission to install.
    """
    try:
        _require(type(accepted) is CandidateBinding, "An explicit caller-accepted candidate binding is required.")
        identity = asdict(accepted)
        tuple_digest = identity.pop("tuple_sha256")
        _require(_hex(tuple_digest) and accepted.repository == "lukacf/meerkat-mobkit"
            and isinstance(accepted.source_sha, str) and re.fullmatch(r"[a-f0-9]{40}", accepted.source_sha)
            and all(isinstance(value, str) and VERSION.fullmatch(value)
                for value in (accepted.native_version, accepted.core_version))
            and accepted.platform in PLATFORMS and _positive(accepted.native_run_id)
            and _positive(accepted.native_run_attempt) and _hex(accepted.native_manifest_sha256)
            and _hex(accepted.sdk_wheel_sha256), "The caller-accepted candidate identity is invalid.")
        inputs = _Inputs(artifact_root)
        tuple_file, content = inputs.read(tuple_path, tuple_digest, MAX_METADATA_BYTES)
        value = _json(content)
        _require(value.get("format") == "forge-private-consumer-tuple-preparation-v1"
            and value.get("identity") == identity and all(type(value["identity"][key]) is type(item)
                for key, item in identity.items()), "The candidate tuple differs from the caller-accepted identity.")
        native, sdk = value["native"], value["sdk"]
        _require(native["origin"] == "github-actions-signed-candidate"
            and sdk["origin"] == "local-build-from-exact-frozen-source"
            and sdk["signed"] is False and sdk["published"] is False,
            "The candidate native and local SDK origins must remain distinct.")
        metadata, target = native["metadata"], native["target"]
        def proof(container, path_key, hash_key):
            return inputs.read(container[path_key], container[hash_key], MAX_METADATA_BYTES)[1]
        intake = _json(proof(native, "intake", "intake_sha256"))
        selection = _json(proof(native, "selection", "selection_sha256"))
        manifest = _json(proof(metadata, "manifest_path", "manifest_sha256"))
        expected = {"repository": accepted.repository, "source_sha": accepted.source_sha,
            "version": accepted.native_version, "tag": "v" + accepted.native_version,
            "run_id": accepted.native_run_id, "run_attempt": accepted.native_run_attempt,
            "kind": "candidate-manifest", "schema_version": 1}
        _require(all(type(manifest.get(key)) is type(item) and manifest.get(key) == item for key, item in expected.items())
            and metadata["manifest_sha256"] == accepted.native_manifest_sha256
            and manifest["workflow"] == {"path": ".github/workflows/release.yml", "ref": "refs/heads/main", "sha": accepted.source_sha},
            "The native manifest source, version, workflow or run binding changed.")
        _require(all(type(intake.get(key)) is type(item) and intake.get(key) == item for key, item in {
            "repository": accepted.repository, "source_sha": accepted.source_sha,
            "native_version": accepted.native_version, "core_version": accepted.core_version,
            "run_id": accepted.native_run_id, "run_attempt": accepted.native_run_attempt,
            "target": accepted.platform}.items()) and intake["workflow"] == manifest["workflow"]
            and intake["metadata_artifact"] == metadata and intake["target_artifact"] == target
            and intake["selection_path"] == native["selection"], "The native intake binding changed.")
        _require(type(selection.get("schema_version")) is int
            and type(selection.get("run_id")) is int and type(selection.get("run_attempt")) is int
            and type(selection.get("manifest_artifact", {}).get("id")) is int
            and selection == {"kind": "accepted-candidate", "schema_version": 1,
            "repository": accepted.repository, "run_id": accepted.native_run_id,
            "run_attempt": accepted.native_run_attempt, "manifest_artifact": {
                "id": metadata["id"], "digest": metadata["outer_sha256"],
                "manifest_sha256": accepted.native_manifest_sha256}}, "The native selection binding changed.")
        artifacts = manifest["artifacts"]
        _require(isinstance(artifacts, list) and all(isinstance(item, dict) for item in artifacts)
            and len({item["target"] for item in artifacts}) == len(artifacts)
            and len({item["id"] for item in artifacts}) == len(artifacts), "The native manifest has duplicate target artifacts.")
        selected = [item for item in artifacts if item["target"] == accepted.platform]
        _require(len(selected) == 1 and _positive(target["id"]) and _positive(metadata["id"])
            and selected[0]["id"] == target["id"] and selected[0]["digest"] == target["outer_sha256"]
            and selected[0]["archives"] == target["archives"], "The native target artifact binding changed.")
        proof(metadata, "original_provenance_path", "original_provenance_sha256")
        proof(target, "original_provenance_path", "original_provenance_sha256")
        inputs.read(metadata["path"], metadata["outer_sha256"], MAX_ARCHIVE_BYTES, keep=False)
        _require(_positive(target["bytes"]), "The native target byte binding is invalid.")
        inputs.read(target["path"], target["outer_sha256"], MAX_ARCHIVE_BYTES, keep=False, size=target["bytes"])
        records = target["archives"]
        _require(isinstance(records, list) and len(records) == len(BINARIES)
            and all(isinstance(record, dict) for record in records)
            and {record["binary"] for record in records} == set(BINARIES), "The native archive inventory is incomplete or duplicated.")
        directory = inputs.path(target["original_provenance_path"]).parent
        natives = tuple(sorted((_native(inputs, directory, record, accepted) for record in records), key=lambda item: item.binary))
        provenance = _json(proof(sdk, "provenance", "provenance_sha256"))
        review = _json(proof(sdk, "independent_review", "independent_review_sha256"))
        _require(provenance["format"] == "forge-local-candidate-sdk-preparation-v1"
            and provenance["repository"] == accepted.repository and provenance["source_sha"] == accepted.source_sha
            and provenance["native_candidate_reference"]["run_id"] == accepted.native_run_id
            and provenance["native_candidate_reference"]["run_attempt"] == accepted.native_run_attempt
            and review["source_sha"] == accepted.source_sha and review["provenance_sha256"] == sdk["provenance_sha256"]
            and review["wheel_sha256"] == sdk["wheel_sha256"] == accepted.sdk_wheel_sha256,
            "The local SDK source or native reference binding changed.")
        declared = provenance["sdk"]
        _require(declared["name"] == "meerkat-mobkit" and declared["version"] == accepted.native_version
            and declared["sha256"] == sdk["wheel_sha256"] and declared["bytes"] == sdk["bytes"]
            and _positive(sdk["bytes"]) and declared["origin"] == sdk["origin"]
            and declared["signed"] is False and declared["published"] is False
            and declared["native_executable_included"] is False,
            "The local SDK identity or origin changed.")
        source_files = provenance["source_files"]
        _require(isinstance(source_files, list) and all(isinstance(item, dict) and isinstance(item["path"], str) for item in source_files)
            and len({item["path"] for item in source_files}) == len(source_files), "The SDK source file inventory is invalid.")
        source_payload = {item["path"].removeprefix("sdk/python/"): item["sha256"] for item in source_files
            if item["path"].startswith("sdk/python/meerkat_mobkit/")}
        _require(source_payload == sdk["source_payload"], "The SDK payload inventory differs from its exact source.")
        wheel_path = inputs.path(sdk["wheel"])
        _require(wheel_path.name == f"meerkat_mobkit-{accepted.native_version}-py3-none-any.whl",
            "The SDK wheel filename identity changed.")
        wheel_file, wheel_bytes = inputs.read(wheel_path, accepted.sdk_wheel_sha256, MAX_WHEEL_BYTES, size=sdk["bytes"])
        payload_sizes = {item["path"].removeprefix("sdk/python/"): item["bytes"] for item in source_files
            if item["path"].startswith("sdk/python/meerkat_mobkit/")}
        payload = _wheel(wheel_bytes, accepted.native_version, sdk["source_payload"], payload_sizes)
        inputs.finish()
        evidence = tuple(sorted((item[0] for item in inputs.files.values()
            if item[0] not in (tuple_file, wheel_file) and item[0] not in {native.archive for native in natives}),
            key=lambda item: str(item.path)))
        return CandidateArtifacts(accepted, tuple_file, natives, SdkArtifact(wheel_file, payload), evidence)
    except CandidateArtifactError:
        raise
    except (OSError, ValueError, KeyError, TypeError, AttributeError, NotImplementedError,
            tarfile.TarError, zipfile.BadZipFile, EOFError) as error:
        raise CandidateArtifactError("The candidate artifact tuple or archive is invalid.") from error
