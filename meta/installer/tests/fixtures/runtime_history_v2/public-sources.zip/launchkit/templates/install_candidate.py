#!/usr/bin/env python3
"""Install an explicitly host-selected candidate; never imply public release trust.

The copied integrity reader rechecks previously accepted artifacts. This adapter
does not verify signatures or confer admission on a tuple or local SDK wheel.
"""
from __future__ import annotations

import argparse
import base64
from dataclasses import asdict, dataclass
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import platform
import re
import stat
import subprocess
import tarfile
import tempfile
import zipfile

if __package__ == "launchkit.templates":
    from ..runtime_candidates import (
        CandidateArtifactError, CandidateBinding, read_candidate_artifacts,
        MAX_ARCHIVE_BYTES, MAX_BINARY_BYTES, MAX_TAR_OVERHEAD, MAX_METADATA_BYTES,
        MAX_WHEEL_BYTES,
    )
else:
    from runtime_candidates import (
        CandidateArtifactError, CandidateBinding, read_candidate_artifacts,
        MAX_ARCHIVE_BYTES, MAX_BINARY_BYTES, MAX_TAR_OVERHEAD, MAX_METADATA_BYTES,
        MAX_WHEEL_BYTES,
    )

ROOT = Path(__file__).resolve().parent
BINARIES = {"rpc_gateway": "mobkit-rpc-gateway", "mobkit_gateway": "mobkit-gateway"}
SELECTION_FIELDS = {"format", "tuple_path", "artifact_root", "accepted"}
BINDING_FIELDS = set(CandidateBinding.__dataclass_fields__)
OVERRIDES = ("MOBKIT_RPC_GATEWAY_BIN", "MOBKIT_GATEWAY_BIN", "META_FORGE_RPC_GATEWAY_BIN")


def require(condition, message):
    if not condition:
        raise CandidateArtifactError(message)


def digest(payload):
    return hashlib.sha256(payload).hexdigest()


def unique_json(payload):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "Candidate installation JSON has duplicate keys.")
            result[key] = value
        return result
    def nonfinite(value):
        raise CandidateArtifactError("Candidate installation JSON contains a non-finite value.")
    try:
        result = json.loads(payload, object_pairs_hook=unique, parse_constant=nonfinite)
    except (UnicodeError, json.JSONDecodeError) as error:
        raise CandidateArtifactError("Candidate installation JSON is invalid.") from error
    require(isinstance(result, dict), "Candidate installation JSON must be an object.")
    return result


def safe_path(value):
    require(isinstance(value, (str, Path)), "Candidate installation path is invalid.")
    path = Path(value)
    require(path.is_absolute() and str(path) == str(value) and ".." not in path.parts,
        "Candidate installation paths must be absolute canonical paths.")
    for parent in (path, *path.parents):
        require(not parent.is_symlink(), "Candidate installation paths must not contain links.")
    return path


def fingerprint(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_nlink,
        info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def read_owned(path, limit, *, private=False, empty=False):
    path = safe_path(path)
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_uid == os.getuid()
        and before.st_nlink == 1 and not before.st_mode & (0o077 if private else 0o022)
        and (0 if empty else 1) <= before.st_size <= limit,
        "Candidate installation requires bounded owned ordinary files.")
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), "rb") as handle:
        opened = os.fstat(handle.fileno())
        require(fingerprint(before) == fingerprint(opened), "Candidate installation input changed while opening.")
        data = handle.read(limit + 1)
        require(len(data) == opened.st_size and len(data) <= limit
            and fingerprint(opened) == fingerprint(os.fstat(handle.fileno()))
            and fingerprint(opened) == fingerprint(path.lstat()),
            "Candidate installation input changed while reading.")
    return data


def owned_directory(path, *, private=False):
    path = safe_path(path)
    info = path.lstat()
    require(stat.S_ISDIR(info.st_mode) and info.st_uid == os.getuid()
        and not info.st_mode & (0o077 if private else 0o022),
        "Candidate installation requires an owned ordinary directory.")
    return path


def platform_target():
    arch = {"arm64": "aarch64", "aarch64": "aarch64", "x86_64": "x86_64", "AMD64": "x86_64"}.get(platform.machine())
    system = platform.system()
    suffix = {"Darwin": "apple-darwin", "Linux": "unknown-linux-gnu"}.get(system)
    require(bool(arch and suffix), "Candidate native tools require macOS or glibc Linux on Intel or ARM64.")
    if system == "Linux":
        libc, version = platform.libc_ver()
        try:
            compatible = libc == "glibc" and tuple(int(part) for part in version.split(".")[:2]) >= (2, 31)
        except ValueError:
            compatible = False
        require(compatible, "Candidate native tools require glibc 2.31 or newer.")
    return f"{arch}-{suffix}"


@dataclass(frozen=True)
class CandidateSelection:
    path: Path
    root: Path
    tuple_path: Path
    artifact_root: Path
    accepted: CandidateBinding
    artifacts: object


def load_candidate_selection(selection_path=None, *, expected_native_version=None,
        expected_platform=None, gateway_override=None):
    require(not gateway_override and not any(os.environ.get(name) for name in OVERRIDES),
        "Candidate installation does not admit gateway overrides.")
    path = safe_path(Path(selection_path).absolute() if selection_path is not None else ROOT / "runtime-candidate.json")
    require(path.name == "runtime-candidate.json", "The compiler-owned candidate selection filename is required.")
    root = owned_directory(path.parent)
    value = unique_json(read_owned(path, MAX_METADATA_BYTES))
    require(set(value) == SELECTION_FIELDS and value["format"] == "forge-runtime-candidate-selection-v1"
        and isinstance(value["accepted"], dict) and set(value["accepted"]) == BINDING_FIELDS,
        "The compiler-owned candidate selection has an invalid shape.")
    binding = CandidateBinding(**value["accepted"])
    deployment = unique_json(read_owned(root / "deployment.json", MAX_METADATA_BYTES))
    require(deployment.get("runtimeCandidate") == {"source": "signed-candidate",
        "selection": "runtime-candidate.json", "tuple_sha256": binding.tuple_sha256},
        "The protected deployment does not select this candidate binding.")
    require(deployment.get("mobkitVersion") == binding.native_version
        and binding.native_version == (expected_native_version or deployment.get("mobkitVersion"))
        and binding.platform == (expected_platform or platform_target())
        and binding.core_version == "0.8.51",
        "The candidate SDK/native version, Core or local platform differs from the deployment.")
    tuple_path, artifact_root = safe_path(value["tuple_path"]), safe_path(value["artifact_root"])
    artifacts = read_candidate_artifacts(tuple_path, accepted=binding, artifact_root=artifact_root)
    return CandidateSelection(path, root, tuple_path, artifact_root, binding, artifacts)


def binding_fields(context):
    identity = context.accepted
    return {"candidate_binding": asdict(identity), "candidate_tuple_sha256": identity.tuple_sha256,
        "sdk_wheel_sha256": identity.sdk_wheel_sha256, "source_sha": identity.source_sha,
        "native_run_id": identity.native_run_id, "native_run_attempt": identity.native_run_attempt}


def checked_wheel(context):
    wheel = context.artifacts.sdk.wheel
    data = read_owned(wheel.path, MAX_WHEEL_BYTES)
    require(len(data) == wheel.size and digest(data) == wheel.sha256 == context.accepted.sdk_wheel_sha256,
        "The selected SDK wheel changed after candidate verification.")
    return data


def sdk_location(context, sdk_python=None, site_packages=None):
    python = Path(sdk_python) if sdk_python is not None else context.root / ".venv/bin/python"
    require(python == context.root / ".venv/bin/python", "Candidate SDK installation uses the deployment's selected virtual environment.")
    venv = owned_directory(context.root / ".venv")
    if site_packages is None:
        # Before Python 3.14, -S can leave sys.prefix at the base interpreter.
        # Explicit scheme variables preserve this owned venv without allowing
        # site startup, .pth files or sitecustomize to execute installed code.
        result = subprocess.run([str(python), "-I", "-S", "-c",
            "import json, sysconfig, sys; print(json.dumps(sysconfig.get_paths(scheme='posix_venv' if 'posix_venv' in sysconfig.get_scheme_names() else 'posix_prefix', vars={'base': sys.argv[1], 'platbase': sys.argv[1]})))",
            str(venv)],
            check=True, capture_output=True, text=True)
        paths = unique_json(result.stdout)
        require(paths.get("purelib") == paths.get("platlib"), "Candidate pure Python SDK installation paths differ.")
        site_packages = paths.get("purelib")
    site = owned_directory(safe_path(site_packages))
    require(site.is_relative_to(venv), "The installed candidate SDK must remain inside the selected virtual environment.")
    return python, site, venv / "forge-sdk.receipt.json"


def check_bytecode(path, source_path, source, python):
    data = read_owned(path, MAX_WHEEL_BYTES)
    optimize = 2 if ".opt-2." in path.name else 1 if ".opt-1." in path.name else 0
    # The installed Python, not the caller, owns bytecode format and compilation.
    # Pass the already owned/read bytes; the helper reads no SDK or provider files.
    script = """import base64, importlib.util, json, marshal, sys
v = json.load(sys.stdin)
data, source = base64.b64decode(v['cache']), base64.b64decode(v['source'])
valid = False
try:
    valid = len(data) > 16 and data[:4] == importlib.util.MAGIC_NUMBER and marshal.loads(data[16:]) == compile(source, v['filename'], 'exec', dont_inherit=True, optimize=v['optimize'])
except (ValueError, TypeError, EOFError, SyntaxError):
    pass
print(json.dumps({'valid': valid}))
"""
    result = subprocess.run([str(python), "-I", "-S", "-c", script], check=True,
        capture_output=True, text=True, input=json.dumps({"cache": base64.b64encode(data).decode(),
            "source": base64.b64encode(source).decode(), "filename": str(source_path), "optimize": optimize}))
    require(unique_json(result.stdout) == {"valid": True},
        "Installed SDK bytecode differs from its exact source payload or selected interpreter.")


def sdk_proof(context, site, python):
    wheel = checked_wheel(context)
    expected = dict(context.artifacts.sdk.payload)
    package = owned_directory(site / "meerkat_mobkit")
    actual, caches = set(), []
    for path in package.rglob("*"):
        require(not path.is_symlink(), "Installed SDK package contains a link.")
        if path.is_dir():
            owned_directory(path)
        else:
            name = path.relative_to(site).as_posix()
            if path.suffix == ".pyc" and path.parent.name == "__pycache__":
                caches.append(path)
            else:
                actual.add(name)
    require(actual == set(expected), "Installed SDK payload inventory differs from the exact wheel.")
    sources = {}
    for name, hashed in expected.items():
        data = read_owned(site / name, MAX_WHEEL_BYTES, empty=True)
        require(digest(data) == hashed, "Installed SDK payload differs from the exact source wheel.")
        sources[name] = data
    for path in caches:
        try:
            source_path = Path(importlib.util.source_from_cache(str(path)))
        except ValueError as error:
            raise CandidateArtifactError("Installed SDK has an unexpected bytecode path.") from error
        name = source_path.relative_to(site).as_posix()
        require(name in sources, "Installed SDK bytecode has no exact source owner.")
        check_bytecode(path, source_path, sources[name], python)
    prefix = f"meerkat_mobkit-{context.accepted.native_version}.dist-info"
    distributions = [path.name for path in site.iterdir()
        if re.fullmatch(r"(?i)meerkat[-_]mobkit-.*\.(dist-info|egg-info)", path.name)]
    require(distributions == [prefix], "Installed SDK has an unexpected or duplicate distribution identity.")
    metadata_dir = owned_directory(site / prefix)
    metadata = {}
    with zipfile.ZipFile(io.BytesIO(wheel)) as archive:
        for name in ("METADATA", "WHEEL", "top_level.txt"):
            value = archive.read(prefix + "/" + name)
            require(read_owned(metadata_dir / name, MAX_METADATA_BYTES) == value,
                "Installed SDK distribution metadata differs from its selected wheel.")
            metadata[name] = digest(value)
    allowed = {"METADATA", "WHEEL", "top_level.txt", "RECORD", "INSTALLER", "REQUESTED", "direct_url.json"}
    require({path.name for path in metadata_dir.iterdir()} <= allowed,
        "Installed SDK has unexpected distribution metadata.")
    for path in metadata_dir.iterdir():
        read_owned(path, MAX_METADATA_BYTES, empty=True)
    return {"format": "forge-installed-candidate-sdk-v1", "source": "local-build-from-exact-frozen-source",
        "signed": False, "published": False, "version": context.accepted.native_version,
        "site_packages": str(site), "payload_sha256": expected, "metadata_sha256": metadata,
        **binding_fields(context)}


def atomic_write(path, payload, mode):
    owned_directory(path.parent)
    require(not path.is_symlink(), "Candidate destination must not be a link.")
    if path.exists():
        read_owned(path, max(MAX_BINARY_BYTES, MAX_METADATA_BYTES), private=True, empty=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(prefix=f".{path.name}-", dir=path.parent, delete=False) as handle:
            temporary = Path(handle.name)
            os.fchmod(handle.fileno(), mode)
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        temporary.replace(path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def write_json(path, value):
    atomic_write(path, (json.dumps(value, sort_keys=True, indent=2) + "\n").encode(), 0o600)


def verify_installed_candidate_sdk(selection_path=None, *, expected_native_version=None,
        expected_platform=None, sdk_python=None, site_packages=None):
    context = load_candidate_selection(selection_path, expected_native_version=expected_native_version,
        expected_platform=expected_platform)
    python, site, receipt_path = sdk_location(context, sdk_python, site_packages)
    proof = sdk_proof(context, site, python)
    require(unique_json(read_owned(receipt_path, MAX_METADATA_BYTES, private=True)) == proof,
        "The installed candidate SDK receipt differs from its actual payload and binding.")
    return proof


def install_candidate_sdk(selection_path=None, *, expected_native_version=None,
        expected_platform=None, sdk_python=None, site_packages=None):
    context = load_candidate_selection(selection_path, expected_native_version=expected_native_version,
        expected_platform=expected_platform)
    python, site, receipt_path = sdk_location(context, sdk_python, site_packages)
    data = checked_wheel(context)
    with tempfile.TemporaryDirectory(prefix=".forge-candidate-sdk-", dir=context.root / ".venv") as temp:
        wheel = Path(temp) / context.artifacts.sdk.wheel.path.name
        atomic_write(wheel, data, 0o600)
        subprocess.run([str(python), "-m", "pip", "install", "--disable-pip-version-check",
            "--no-index", "--no-deps", "--no-compile", "--force-reinstall", str(wheel)], check=True)
    proof = sdk_proof(context, site, python)
    write_json(receipt_path, proof)
    return proof


def install_candidate_requirements(selection_path=None, *, expected_native_version=None,
        expected_platform=None, sdk_python=None, site_packages=None):
    context = load_candidate_selection(selection_path, expected_native_version=expected_native_version,
        expected_platform=expected_platform)
    python, _, _ = sdk_location(context, sdk_python, site_packages)
    verify_installed_candidate_sdk(context.path, expected_native_version=context.accepted.native_version,
        expected_platform=context.accepted.platform, sdk_python=python, site_packages=site_packages)
    text = read_owned(context.root / "requirements.txt", MAX_METADATA_BYTES).decode("utf-8")
    pins, sdk_pins = [], []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        require(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*(?:\[[A-Za-z0-9_,.-]+\])?==[A-Za-z0-9][A-Za-z0-9_.+!-]*", line),
            "Candidate requirements must retain ordinary exact package pins.")
        name = re.split(r"\[|==", line, 1)[0].lower().replace("_", "-").replace(".", "-")
        if name == "meerkat-mobkit":
            sdk_pins.append(line)
        else:
            pins.append(line)
    require(sdk_pins == ["meerkat-mobkit==" + context.accepted.native_version],
        "Requirements must contain exactly one selected candidate SDK pin.")
    with tempfile.TemporaryDirectory(prefix=".forge-candidate-requirements-", dir=context.root / ".venv") as temp:
        requirements = Path(temp) / "requirements.txt"
        atomic_write(requirements, ("\n".join(pins) + "\n").encode(), 0o600)
        if pins:
            subprocess.run([str(python), "-m", "pip", "install", "--disable-pip-version-check",
                "-r", str(requirements)], check=True)
    return verify_installed_candidate_sdk(context.path, expected_native_version=context.accepted.native_version,
        expected_platform=context.accepted.platform, sdk_python=python, site_packages=site_packages)


def native_payload(native):
    content = read_owned(native.archive.path, MAX_ARCHIVE_BYTES)
    require(len(content) == native.archive.size and digest(content) == native.archive.sha256,
        "The native candidate archive changed after verification.")
    try:
        with gzip.GzipFile(fileobj=io.BytesIO(content)) as compressed:
            expanded = compressed.read(MAX_BINARY_BYTES + MAX_TAR_OVERHEAD + 1)
        require(len(expanded) <= MAX_BINARY_BYTES + MAX_TAR_OVERHEAD,
            "The native candidate archive exceeded its decompressed bound.")
        with tarfile.open(fileobj=io.BytesIO(expanded), mode="r:") as archive:
            item = archive.next()
            require(item is not None and item.name == native.binary == native.inner_name
                and item.isfile() and item.sparse is None and item.mode & 0o111
                and 0 < item.size == native.inner_size <= MAX_BINARY_BYTES,
                "The native candidate archive must contain one flat ordinary executable.")
            handle = archive.extractfile(item)
            require(handle is not None, "The native candidate payload is missing.")
            with handle:
                payload = handle.read(MAX_BINARY_BYTES + 1)
            require(len(payload) == native.inner_size and digest(payload) == native.inner_sha256
                and archive.next() is None, "The native candidate payload or inventory changed.")
    except (tarfile.TarError, EOFError, OSError) as error:
        raise CandidateArtifactError("The native candidate archive is invalid.") from error
    return payload


def native_receipt(context, native):
    return {"source": "signed-candidate", "version": context.accepted.native_version,
        "platform": context.accepted.platform, "archive": native.archive.path.name,
        "archive_sha256": native.archive.sha256, "binary_sha256": native.inner_sha256,
        **binding_fields(context)}


def verify_installed_candidate_runtime(selection_path=None, *, expected_native_version=None,
        expected_platform=None, sdk_python=None, site_packages=None, tools_dir=None):
    context = load_candidate_selection(selection_path, expected_native_version=expected_native_version,
        expected_platform=expected_platform)
    sdk = verify_installed_candidate_sdk(context.path, expected_native_version=context.accepted.native_version,
        expected_platform=context.accepted.platform, sdk_python=sdk_python, site_packages=site_packages)
    directory = Path(tools_dir) if tools_dir is not None else context.root / ".bin"
    require(directory == context.root / ".bin", "Candidate native tools must use the deployment's canonical .bin directory.")
    owned_directory(directory, private=True)
    receipts = {}
    for native in context.artifacts.native:
        if native.binary not in BINARIES:
            continue
        payload = read_owned(directory / native.binary, MAX_BINARY_BYTES, private=True)
        require(len(payload) == native.inner_size and digest(payload) == native.inner_sha256
            and os.access(directory / native.binary, os.X_OK), "Installed candidate native executable changed.")
        receipt = unique_json(read_owned(directory / (native.binary + ".receipt.json"), MAX_METADATA_BYTES, private=True))
        require(receipt == native_receipt(context, native), "Installed candidate native receipt binding changed.")
        receipts[native.binary] = receipt
    require(set(receipts) == set(BINARIES), "The two installed candidate native tools are required.")
    return {"source": "signed-candidate", "version": context.accepted.native_version,
        "platform": context.accepted.platform, **binding_fields(context), "sdk": sdk, "native": receipts}


def install_candidate_native_tools(selection_path=None, *, expected_native_version=None,
        expected_platform=None, sdk_python=None, site_packages=None, tools_dir=None):
    context = load_candidate_selection(selection_path, expected_native_version=expected_native_version,
        expected_platform=expected_platform)
    verify_installed_candidate_sdk(context.path, expected_native_version=context.accepted.native_version,
        expected_platform=context.accepted.platform, sdk_python=sdk_python, site_packages=site_packages)
    directory = Path(tools_dir) if tools_dir is not None else context.root / ".bin"
    require(directory == context.root / ".bin", "Candidate native tools must use the deployment's canonical .bin directory.")
    require(not directory.is_symlink(), "Candidate native directory must not be a link.")
    if directory.exists():
        owned_directory(directory, private=True)
    selected = {native.binary: native for native in context.artifacts.native if native.binary in BINARIES}
    require(set(selected) == set(BINARIES), "Both candidate native tools must be present.")
    pending = {name: native_payload(native) for name, native in selected.items()}
    # Every archive, SDK source and installed destination is checked before writes.
    for name in selected:
        for path in (directory / name, directory / (name + ".receipt.json")):
            require(not path.is_symlink(), "Candidate native destination must not be a link.")
            if path.exists():
                read_owned(path, MAX_BINARY_BYTES, private=True, empty=True)
    directory.mkdir(mode=0o700, exist_ok=True)
    for name, native in selected.items():
        atomic_write(directory / name, pending[name], 0o700)
        write_json(directory / (name + ".receipt.json"), native_receipt(context, native))
    return verify_installed_candidate_runtime(context.path, expected_native_version=context.accepted.native_version,
        expected_platform=context.accepted.platform, sdk_python=sdk_python, site_packages=site_packages)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("sdk-install", "requirements-install", "sdk-verify", "native-install", "runtime-verify"))
    parser.add_argument("--selection", default=str(ROOT / "runtime-candidate.json"))
    parser.add_argument("--expected-native-version")
    parser.add_argument("--expected-platform")
    args = parser.parse_args(argv)
    owner = {"sdk-install": install_candidate_sdk, "requirements-install": install_candidate_requirements,
        "sdk-verify": verify_installed_candidate_sdk, "native-install": install_candidate_native_tools,
        "runtime-verify": verify_installed_candidate_runtime}[args.action]
    try:
        result = owner(args.selection, expected_native_version=args.expected_native_version,
            expected_platform=args.expected_platform)
    except (CandidateArtifactError, OSError, subprocess.SubprocessError, UnicodeError) as error:
        raise SystemExit(f"Candidate installation refused: {error}") from error
    print(json.dumps(result, sort_keys=True))
    return result


if __name__ == "__main__":
    main()
