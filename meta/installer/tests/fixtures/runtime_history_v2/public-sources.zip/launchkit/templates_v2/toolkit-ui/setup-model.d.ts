export interface SetupConversationMessage {
    readonly role: "user" | "assistant";
    readonly text: string;
}
export interface SetupConversationHistory {
    readonly messages: readonly SetupConversationMessage[];
    readonly offset: number;
    readonly total: number;
    readonly hasMore: boolean;
}
export type SetupConversationEvent = {
    readonly kind: "run_observed";
} | {
    readonly kind: "text_reset";
    readonly messageId?: string;
} | {
    readonly kind: "text_delta";
    readonly text: string;
    readonly messageId?: string;
} | {
    readonly kind: "text_complete";
    readonly text: string;
    readonly messageId?: string;
};
export type SetupConversationErrorCode = "unavailable" | "busy" | "invalid_message" | "history_unavailable" | "turn_uncertain" | "stop_unavailable" | "stop_uncertain";
/** Safe presentation errors intentionally omit raw native/provider details. */
export declare class SetupConversationError extends Error {
    readonly code: SetupConversationErrorCode;
    constructor(code: SetupConversationErrorCode);
}
/** Safe view-facing methods. An application's authenticated bridge may provide
 * this shape; it never transfers a native Session or invents native authority.
 */
export interface SetupConversationPort {
    readonly scope: string;
    /** Coherent owner state: while available, !canSend && !outcomeUncertain
     * means an existing send is active. It does not mean history is loading or
     * permission is missing; admission loss makes the port unavailable.
     */
    readonly available: boolean;
    readonly canSend: boolean;
    readonly canStop: boolean;
    readonly outcomeUncertain: boolean;
    onUnavailable(listener: () => void): () => void;
    /** Read-only presentation invalidation. Emits no data and opens no stream.
     * Hosts notify after these getters change, including an existing send's
     * settlement while its original view is unmounted.
     */
    onStateChange(listener: () => void): () => void;
    history(offset?: number): Promise<SetupConversationHistory>;
    send(message: string, observe: (event: SetupConversationEvent) => void): Promise<void>;
    stopObservedRun(reason: string): Promise<"stopped" | "not_current" | "not_stoppable">;
}
