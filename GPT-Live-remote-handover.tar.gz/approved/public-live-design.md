# Public GPT-Live integration design, revision 3.1

Status: DESIGN ONLY, resubmitted for retained independent reviewers.
Architecture and contract scopes passed V3. This revision changes only the
accepted-observation wire-sizing/paging contract for focused integration recheck.
No production, dependency, build, paid-provider, or implementation work authorized.
Owner session: ba07d78b-c14c-4473-95e3-8b1dfea35a6b.
Coordinator: 7f79d593-ecaa-4537-bca6-60ee2dbdfbe4.
Branch: luka-crnkovicfriis-abk-public-live-integration.
Verified baseline: clean `5bcf6a1a203422ac651dc44f753f48c9547d4fc5`,
equal to origin/main when design began.

This document supersedes revision 2 while preserving its accepted contracts.
Proposed symbols are NEW unless explicitly
identified as existing. Root's provisional adjudications are incorporated, not
treated as implementation approval. YAML spec/plan/checklist are companion
session artifacts. Revision-1 baseline B01-B21 remains in the superseded file
for audit; corrected authoritative anchors are listed below.

## 1. Required outcome and exact scope

Use registry `oai-rt-rs = "=0.5.0"` to integrate public `gpt-live-1` through
existing native-backed Live WS and controller-local WebRTC entrypoints, both
client-context and managed function-bridge modes. Keep three identities:
voice channel, managed Responses backend, and bound durable Meerkat executor.
Public voice requests execute ONE request per ordinary runtime run, preserving
normal factory, hooks, memory, tools, jobs, comms and mob substrate.

Durable sessions retain every accepted voice TEXT observation, including
ordinary conversation with no delegation. No raw-audio retention requirement.
Observations, task evidence, effect permission, input admission, work outcome,
result write, continuation, generated speech, playback and usage are distinct.

| Surface/product | Supported in this change | Deliberate boundary |
|---|---|---|
| Ordinary runtime session RPC/Rust + process-backed Python/TS | Both modes over WS and controller-local WebRTC | Explicit activated profile; no implicit voice model swap. |
| Live-equipped RPC/native host, local or placed member | Both modes over existing member WS chain | Member-host WebRTC rejects for local and placed members. Direct local session RPC WebRTC works. |
| One-shot CLI member live open | Placed member through running owning host only | Local/unplaced one-shot CLI is Unavailable (`main.rs:15138-15144`, `cross_host_live.rs:1134-1157`); no new local CLI listener product. |
| REST and PUBLIC MCP | Existing session/config/catalog/executor and authorized observation families | They EXCLUDE member-live controls (`rest_catalog.rs:553-560`, `public_mcp.rs:560-570`). New paged voice-history read is observation-only, never open/send/cancel authority. |
| Browser consuming native host | Provider WebRTC media and safe host event projection | API key/private provider config never in page. Browser is not a trusted executor or sideband. |
| Standalone Web SDK/WASM | Existing embedded text/mob substrate unchanged; shared types/build gates | No native trusted Live client, sideband or durable claims invented. |
| Legacy Realtime/private Codex Live | Existing external protocol behavior preserved separately | Public does not consume experimental proof/factory/final-turn semantics. |
| Provider storage/download/fork | Released library/provider extension available to trusted embedders | No new Meerkat recording product or generic provider-fork/resume RPC. Fork creates a new provider session, not application jobs. |
| SIP | Released library DTO/control seam remains external | No existing carrier ingress to extend; no public webhook/phone provisioning/outbound calls invented. No paid carrier tests. |

Private API-key/OAuth/backend distinctions, stock model metadata, explicit
unsupported controls and feature absence all receive negative tests. This
scope omits no currently supported public Live entrypoint.

## 2. Baseline facts forcing the revision

| Anchor | Actual constraint |
|---|---|
| `Cargo.toml:185` | Published dependency is currently exact 0.4.1; update both locks later. |
| `meerkat-openai/src/runtime/mod.rs:147-190,723-757` | Stable realtime bit currently selects old Realtime. Need typed protocol/applicability, not only a public model row. |
| `meerkat/src/factory.rs:2676-2728,2955-3031` | Existing per-open owner-realm resolution is reusable; carry generated auth lease, not env reads in leaves. |
| `meerkat/src/session_runtime/live_orchestration.rs:1939-2047` | Existing execution-identity path is private/RTC-only. |
| `meerkat-core/src/agent/runner.rs:1354-1410`; `meerkat-mob/src/runtime/live_bridge_operation.rs:1-237` | Private noncommitting bridge is restricted. Public ordinary executor must not use it. |
| `meerkat-runtime/src/runtime_loop.rs:5772,5965-6058`; `meerkat-session/src/persistent.rs:8761`; `ephemeral.rs:7178-7246` | Turn-finalization/mutable actor locks prevent an independent writer to the actor's Session realtime field during a run. |
| `persistent.rs:1444-1543,1778-1834,12522` | Actor provisional/final physical head is exact; persist_full_session is not a concurrent component append API. |
| `meerkat-core/src/realtime_transcript_sidecar.rs:43-73`; `session_component_sidecar.rs:30-44`; `session_store.rs:2029-2080` | Existing closed realtime event schemas and SessionHead prefix cannot be repurposed or weakly merged. |
| `meerkat-runtime/src/store/mod.rs:7836-7895,8137-8190`; `store/sqlite.rs:2511-2568,3995-4055` | RuntimeStore supports independent domain CAS precedent; runtime-store ledger is currently v3 and per-operation opens preflight its known schema. |
| `meerkat/src/persistence.rs:1207-1210,1287-1291` | Disk WholeBlob and HeadCanonical both use SqliteRuntimeStore. No JSONL-only independent canonical store is necessary. |
| `meerkat-runtime/src/driver/persistent.rs:625-672` | Existing idempotency lookup checks stored key/row, NOT incoming payload equality. |
| `meerkat-machine-schema/src/catalog/dsl/meerkat_machine.rs:32155-32195` | Non-prompt queue inputs can batch; a new enum variant alone does not isolate runs. |
| `meerkat-runtime/src/bounded_submit.rs:202-222,479-515`; `runtime_control.rs:10305-10457` | Runless terminal outcomes exist; admission task survives timeout; cancelling absent input does not cancel future admission. |
| `meerkat-machine-schema/src/catalog/dsl/meerkat_machine.rs:25776-25834` | Private retirement expects submission terminality public API cannot prove. Do not weaken private predicate. |
| `meerkat-live/src/host.rs:3540-3555` | Generic Error is channel-terminal; public post-R2 errors require a nonterminal diagnostic carrier. |
| `meerkat/src/session_runtime/live_orchestration.rs:219-257,1245-1278,1437-1805,2940-2982` | Refresh/config propagation currently assumes executor identity is voice identity. |
| `meerkat-contracts/src/wire/mob.rs:3588-3595`; `wire/supervisor_bridge.rs:812-821`; `meerkat-runtime/src/member_live.rs:186-200` | Profile selector is absent from full member open chain. |
| Root-reviewed `member_live_proxy.rs:53-74`; facade `live_host.rs:1169-1181,2119-2139`; CLI `mob_host.rs:814-843` | Member host uses config_runtime=None; CLI host startup MemoryConfigStore must not be mistaken for fresh owner config. |
| `scripts/generate-bazel-rust-builds.mjs:1276-1281,1311-1326,1362-1368` | TurboS cohorts/runfiles are explicitly generated; adding taxonomy entry alone is insufficient. |

Provider source: clean released tree at
`/Users/luka/src/copilot-worktrees/oai-rt-rs/luka-crnkovicfriis-abk-stunning-potato`,
HEAD `90118cebd3442a1caa1071dee1954f00b30f959f`.
Registry SHA256 `c04e6cdf6919f09de4be2af34f4d0be489dc78c32f0a6a0083c2299e7844c0ac`
was independently verified by coordinator.
`src/live/responses.rs:1799-1830` returns Owned for known lifecycle response ID
even with delegation None; `ready_calls:1981-1999` separately refuses that batch.
`docs/live.md:265-268` permits ACK without client_event_id.

Official sources checked: [overview](https://developers.openai.com/api/docs/guides/live),
[model](https://developers.openai.com/api/docs/models/gpt-live-1),
[delegation](https://developers.openai.com/api/docs/guides/live-delegation).
Released library pins OpenAPI `38170fdddbb6a1813eae6c6587ee17cf2987185b`.

## 3. Authority topology: independent canonical feature component

Revision 1's actor-owned realtime-field proposal is withdrawn. Choose an
INDEPENDENTLY COMMITTED canonical Live component in RuntimeStore. It is NOT a
SessionHead component append, best-effort EventStore, cloned Session writer,
metadata escape hatch or weak CAS merge.

| Fact | Sole owner | Storage/realizer |
|---|---|---|
| Model protocol/applicability | ModelProfile vocabulary + meerkat-models data/registry witness | Provider runtime chooses public/legacy factory. |
| Profile definition/defaults | Facade + provider declaration | Core carries neutral config; no policy in SDK. |
| Trusted activation/grant | Trusted host grant issuer, then generated LiveRequestMachine | Exact activated profile/realm/executor/grant epoch in live ledger. |
| Received TEXT sequence, durable coverage, gaps, snapshot source reservation | NEW catalog `LiveTranscriptMachine`, feature-owned in meerkat-runtime | NEW RuntimeStore live-ledger ops; no actor Session mutation. |
| Request permission, dedup/conflict, cancellation intents, result/continuation/context settlement | NEW catalog `LiveRequestMachine`, feature-owned in meerkat-runtime | Live-ledger ops plus atomic ordinary-input admission/staging handoff. |
| Channel base lifecycle / ordinary input/run | EXISTING MeerkatMachine | Existing runtime lifecycle/input store; new explicit isolation classification. |
| Executor document/messages/compaction/rewrite/archive | EXISTING SessionDocument and ordinary actor | Existing exact WholeBlob/HeadCanonical protocols unchanged. |
| Mob identity/placement/helpers, jobs | Existing MobMachine/job owners | Existing service/bridge/store paths. |
| Public protocol facts | meerkat-openai adapter using released codec/tracker | No provider identifier parsing in shared machines. |

The two new scoped machines are justified by independently committed live
content and request/attempt state, which cannot share the actor's persistence
lock or private final-turn machine. They do NOT mirror MeerkatMachine channel
status, run lifecycle, or private bridge maps. Channel activation/close and
input/run outcomes cross a declared generated `live_execution_bundle`
composition. Private bridge maps remain private protocol authority unchanged.
New machine catalog registration, production owner relations, generated kernels,
TLC, alphabet, effect/ownership/seam manifests are mandatory.

### 3.1 Concrete physical contract (R1)

NEW `RuntimeLiveLedgerOps` carrier exposed through RuntimeStore:
`load_live_head`, `read_live_events`, `lookup_live_source`,
`commit_live_ledger`, `commit_live_input_admission`,
`commit_live_input_stage`, `read_live_composite`, `archive_live_ingress`.
Built-in SqliteRuntimeStore implements it for BOTH WholeBlob and HeadCanonical;
InMemoryRuntimeStore implements equivalent process-local semantics.
Unknown/custom stores expose a typed unsupported capability; activating public
Live fails before provider I/O unless required atomic profile is declared.
Conformance chapter tests atomicity, exact CAS, recovery and capability discovery.

NEW canonical tables (names proposed):

- `runtime_live_heads`: session + generation, record schema, revision,
  event_count, domain-separated prefix_digest, byte/record accounting,
  generated transcript/request snapshots and ingress generation fence.
- `runtime_live_events`: immutable session/channel/sequence/kind/payload bytes/
  digest, including text observations and durable outcome/tombstone facts.
- `runtime_live_sources`: UNIQUE(session, channel incarnation, source kind,
  opaque source identity); immutable request/policy/snapshot identity,
  disposition, exact reserved observation interval, cancellation intent.
- `runtime_live_attempts`: exact result/context/continuation attempt key,
  immutable payload/batch digest, disposition and durable sequence.

All are ONE canonical component under a live head; indexes are mechanical.
No duplicate full payload in snapshots/maps. `commit_live_ledger` takes exact
expected head revision+digest and a generated prepared transition; it checks
that CAS, row uniqueness, counters, session ingress fence and exact byte
digests INSIDE one transaction. Return store-issued committed live head.
No API to append events without head/fence update. Idempotent replay validates
exact bytes, not only keys.

Text acceptance sequence: transport bounded ingress captures local receive
ordinal -> generated append input -> durable ledger transaction -> publish
`ObservationCommitted` and advance DURABLE watermark. Received-but-uncommitted
data is expressly provisional; no request snapshot may refer beyond the
durable watermark. Batched database writes may contain consecutive observations
but never drop/coalesce text records. Audio frames do not enter this ledger.
Crash before commit can lose unaccepted observations, but their number/range
is not reconstructible from the durable head. Recovery records
`UnknownExtentCrashDiscontinuity { last_accepted_head, old_incarnation }`,
not an invented receive high-water or exact loss count. A known in-process
queue overflow may instead record `KnownLocalGap { observed_bounds }`.
Both forms block snapshots crossing them. Zero and many uncommitted receives
with identical durable state MUST produce the same unknown-extent recovery fact.

Lock/transaction order:

1. One live component coordinator serializes its generated state; it holds no
   actor mutation or turn-finalization lock.
2. Database transactions are short, contain no provider/network waits, and do
   not acquire actor locks. Per-operation maintenance and writer epoch fences
   remain required.
3. Live append NEVER changes SessionHead, WholeBlob store_revision,
   actor provisional receipt, runtime ordinary boundary sequence, or existing
   realtime_event_prefix. An actor checkpoint/final promotion before OR after
   live append uses exactly its original authority; live append cannot make
   that CAS stale.
4. Cross-domain ordinary input admission/staging below is an explicit
   multi-row RuntimeStore transaction. It updates ordinary input/lifecycle
   only through the existing prepared machine transition, with BOTH exact
   ordinary expected versions and live fence/source expected versions.
5. `read_live_composite` reads the ordinary committed session authority and live
   head IN ONE backend snapshot transaction. Its store-issued
   `LiveCompositeReadAuthority` binds both exact tokens and requested immutable
   content/page bytes; the facade cannot pair separate reads or mint this
   witness. WholeBlob returns verified committed body/content selection;
   HeadCanonical materializes the selected head/rows through the same SQL
   transaction and verifies the existing prefixes. Provisional actor tail is
   excluded. This is a composite read contract, NOT a new SessionHead CAS.
   SessionService's live-capable read branch consumes the injected neutral
   read-provider trait and this exact store result, not its cached actor clone
   plus a later log read. No dependency from core/session to provider or runtime
   implementation is introduced.

If A=actor final commit and L=live append, both A->L and L->A preserve both
receipts; independent revisions commute. A request snapshot transaction checks
the selected store-issued composite's actor authority and live head in the
same commit transaction. Conflict retries READ/RESERVATION only before source
reservation commits, never a reserved payload or executor effect. External
backends must implement a genuinely atomic composite read/conditional reserve
profile; two-store best-effort pairing is Unsupported, not degraded success.

### 3.2 Format activation, reads and lifecycle (R1)

NEW `LiveLedgerFormatV1`, `LiveEventV1` closed enum, `LiveHeadV1` with explicit
required event schema/prefix version; unknown schema/kind rejects. Do not add
public events to `RealtimeTranscriptSidecarRecord::EventV1`, replace
SessionRealtimeTranscriptState, or depend on its permissive unknown-field
behavior. Historical private/Realtime Session components coexist with new
public channel log partitions; all remain readable in one durable session.

Migration: runtime-store known ledger v3 -> v4 creates live tables plus
atomic admission/fence capability. On shared SQLite files, also advance the
known session-store schema domain v4 -> v5 with an explicit
co-tenant compatibility requirement, so OLD session-only writers cannot bypass
runtime preflight (`meerkat-store/src/sqlite_store.rs:1285-1308` is the current
v4 descriptor). Facade storage composition installs the co-tenant migration
under one maintenance transaction before publishing either store; runtime
does not gain a dependency on the downstream store implementation. On
WholeBlob disk mode runtime.sqlite3 is the authority; old
runtime-backed activation refuses runtime-store v4 before ordinary resume.
Both migrations run under existing maintenance fence and fail-closed
schema-preflight; assert old supported-domain readers reject as FutureSchema.
Neither Session v3 semantics nor frozen 0.8.10 importer is repurposed.

The independent component is not silently smuggled into Session v3 exports.
`SessionView` adds typed `live_history` summary (capability/absence, committed
head, coverage, counts); `live/transcript` reads paged records through the same
authorized service. Portable bare Session serialization still describes only
executor document; full session export/import adds an explicitly versioned
bundle manifest containing both authorities/components and required capability.
No import that discards the live member succeeds as a complete-session import.
Standalone direct reads cannot claim complete Live history.

Compaction/rewrite: alter executor document only; live log unchanged. A
historical request retains immutable source/context reference. New context
projection records the new executor revision; immutable provider seed changes
require explicit replacement. Rewriting a Message cannot rewrite voice records.
Fork: ordinary Session/mob fork does not alias live channel/source/attempt IDs.
NEW fork projection carries authorized voice observations as nonfinal source
context with source-session provenance; destination gets fresh ledger/channel
identity and no execution/resend permission. Reopen builds permitted seed from
retained executor history AND retained voice-only observations, with explicit
omission metadata, so ordinary non-tool conversation is usable, not just readable.

Archive first commits `CloseLiveIngress` (durable revocation barrier), then
ordinary session archive proceeds. Live coordinator drains committed in-flight
text writes ordered before that barrier; later text is rejected/unaccepted.
Cancellation/compaction/rewrite do not erase text. Archive retains component
head and source tombstones. Deletion of the whole session is the ONLY normal
way to delete its replay-protection history and requires existing authorization.
EventStore remains optional derived audit, not source of these reads.

## 4. Activation, source reservation and isolated ordinary execution

### 4.1 Permission is not profile selection (R2/root D2)

NEW trusted `LiveExecutionGrantSource` is injected at native host composition
(`AgentFactory` override first). Its default is Disabled. Public RPC profile
selection and ordinary ToolAccessPolicy cannot mint or widen a grant.
Stock profiles are available definitions only, NOT globally activated permission.

Trusted activation declaration names: issuer/owning realm, profile and revision,
requesting realm allow-set, bound executor selector (exact session or exact
MobId+AgentIdentity), allowed evidence kinds, bounded work permission
(allowed mutation classes/tool restriction, request/concurrency/budget bounds),
expiry if configured, activation generation. At open the issuer resolves the
selector to the exact current session/runtime/member binding and emits sealed
`LiveExecutionGrant` to `LiveRequestMachine::ActivateGrant`.
Only the trusted host API/config source has this entrypoint.

Declarative activations live in feature-owned trusted host configuration, NOT
the writable ordinary `Config.live.profiles` section. Loader uses existing
StorageLayout/realm-chain source; no ambient paths. In-process overrides
replace that source. Default/inherit/disable/set:
absent resolves Inherit; chain root absent is Disabled; Disable blocks inherited
activation; Set replaces complete activation entries, never unions permissions.
Inherited activation applies only to explicitly listed descendant realms and
matching executor selector. The defining realm remains issuer; auth binding
owner is independently resolved. Generic RPC/REST/MCP config mutation cannot
edit this trusted source. Selecting one activated profile consumes its grant,
not an extra caller checkbox.

Concrete native declaration source is `live-activations.toml` beside the
owning realm's already-resolved config document (global: the existing `.rkat`
user-config root; named realm: its resolved config-document directory).
NEW `LiveActivationDocumentLocator` is supplied by bootstrap from StorageLayout,
not derived from HOME by the loader. File entries are keyed activation IDs and
contain `mode=inherit|disable|set`; Set contains the exact declaration fields
above, never API keys or a serialized sealed grant. `FileLiveExecutionGrantSource`
re-reads these documents per open/admission revision check. A trusted native
host reload API publishes revocation; public config APIs cannot target this
document. Full runnable docs show creating a session, activating its exact
session/realm/profile with bounded permission, then selecting that profile.
No implicit all-sessions or all-descendants activation is shipped.

Per admission and effect-start: validate current grant generation, expiry,
profile revision, executor binding and permission intersection with ordinary
ToolAccessPolicy. Dynamic tool grants can narrow, never expand activation.
Host disable/revoke commits a new grant fence: unadmitted reservations refuse,
queued starts are gated, already running work follows explicit revoke policy
`CancelPendingAndRequestRunningCancellation`. Returned outcomes preserve actual
effects; revocation cannot retroactively claim rollback.

### 4.2 Atomic lookup -> reserve -> freeze (R2)

`LiveSourceKey` is stable identity ONLY: (session, channel incarnation,
source kind, provider opaque delegation ID OR exact response+call identity).
Request digest is immutable comparison material, NEVER part of this key.
Provider session IDs remain private equality material. Known lifecycle
identity without outer scope is retained, not an executable source key.

The coordinator first performs durable source lookup. Existing key returns
the exact stored disposition/snapshot/input/outcome BEFORE reading newer text.
For function replay compare incoming exact name/arguments digest; mismatch
is `SourcePayloadConflict`, not a new task. For client metadata replay compare
immutable provider metadata/offset; later text cannot change the source.

For a new client source, ONE generated transaction reserves key, freezes
observation interval `(previous_reserved_frontier, durable_watermark]`,
context revision, payload and policy identity, and advances the reservation
frontier. Reservation commit, NOT delayed input acknowledgment, spends the
frontier. D2 therefore starts after D1's reserved watermark while D1 admission
is busy/unknown. Local received frontier is carried separately; any received
uncommitted records cause `AwaitingObservationDurability` (no frozen snapshot
yet). Ordered coordinator appends them before reservation, or records only
the gap bounds it actually knows and refuses. After process loss, use
UnknownExtentCrashDiscontinuity, never an invented receive range.
No timer/silence/provider offset segmentation.

| New/replayed source | Durable disposition / range | Future behavior |
|---|---|---|
| Valid new prefix | Reserved + immutable snapshot and new frontier | One admission attempt/reconciliation under same source. |
| Empty prefix | RefusedEmpty, zero-width reserved range | Key spent; duplicate returns refusal. |
| Known gap in prefix | RefusedGap, exact interval/gap refs; frontier advances | Key spent; explicit NEW application request may choose later unbroken range. |
| Oversize prefix/request | RefusedBudget, range/digest metadata retained; frontier advances | Never truncate and execute without declared policy; new explicit request required. |
| Missing/revoked grant | RefusedPermission with current available range reservation | No auto grant-later replay; source spent. |
| Source present, admission reply unknown | Original reservation + Unknown admission observation | Reconcile durable row; never freeze again. |
| Source cancelled before admission | CancelIntent + CancelledWithoutRun when resolved | No rewind; future admission must observe cancellation. |
| Store unavailable/unreadable before reservation | ReservationUnconfirmed, no claim of spending or work | Retry exact source lookup only; no next source may cross uncertain frontier until reconciled. |
| Replay refused/cancelled/settled | Same original disposition/range | No new work; explicit NEW application source identity is required for resubmission. |
| No admission/completion capacity | UnacceptedAtCapacity, no new persisted source key | Do not claim key spent or snapshot reserved. Existing obligations settle using reserved credits; exact replay may later retry lookup if still same live incarnation. |

Explicit resubmission is trusted application input with a newly minted
application request ID and explicit selected observation range, subject to
current grant; it is not a fake new provider delegation or auto rewind.
The snapshot stays Provisional forever; effect permission has separate fields.

A crash discontinuity fences the old provider incarnation. Its last accepted
prefix remains readable and may be projected as historical context with
UnknownExtent continuity metadata. New actionable client ranges require an
explicit replacement channel and a new clean interval beginning AFTER that
channel's durable activation marker. No range includes the unknown old tail.
Old provider source keys cannot be invented/replayed on the replacement.

### 4.3 Ordinary input/run handoff and cancellation (R3)

NEW `Input::LiveRequest` and `InputOrigin::LiveRequest` carry sealed request
identity, content/evidence refs, grant/fence and normal turn metadata.
No `PromptInput::new`, no Operator source, no `input_is_prompt=true` trick.
NEW generated `InputRunIsolation::{Ordinary, ExclusiveLiveRequest}` is recorded
at admission. `select_queue_batch` stops before an exclusive input and returns
only that input when first. Stage guard independently requires exactly one
selected input. Runtime pending comms/background input cannot co-batch or
steer-admit into that run; it remains queued for its own later run. Tool
results belonging to this run still execute normally. Observational progress
does not inject another runtime input into the run.

`commit_live_input_admission` atomically checks reserved source digest,
grant/channel ingress fence and cancel intent, then persists ordinary input
and generated admission plus source->InputId association. Extend dedup at
this seam to validate immutable payload before existing key collapse.
Admission emits a sealed persisted `AdmittedLiveExecutionAuthority` binding
source/input, executor and grant/permission identity to the admission commit.
This is distinct from the channel's ingress permit. `commit_live_input_stage`
checks that admission witness plus CURRENT cancellation/revocation and
executor-binding fences in the exact ordinary staging transaction; it does NOT
require an open channel or the old ingress generation. Same-channel ordinary
non-live work never carries these constraints accidentally.

If admission commits before CloseLiveIngress, already-admitted work is allowed
to continue under root D5 unless exact cancellation/revocation is requested.
If close wins, unresolved reservation cannot later admit or start. No check
outside transaction suffices. Admission callback can arrive late but reports
the already ordered durable outcome.

`CancelLiveRequest` persists cancellation intent keyed by SOURCE even when
InputId is unknown/absent. Admission/stage consult it before execution; late
mapping resolves to runless cancellation or exact current input/run cancel.
Cancel delivery is fenced by InputId+RunId+request, never `interrupt_current`
without comparison; a delayed cancel cannot hit an unrelated next run.

Consume canonical `input_terminal_completion` including delivered terminal,
TerminalWithoutDelivery (cancelled/abandoned/coalesced/superseded),
repair-blocked/unclassified and admission refusal. One live request cannot
coalesce/supersede through generic batching; such a result is explicit protocol
fault unless exact live-request supersession was authorized. No RunId is
fabricated for refusal or pre-start cancellation.

Executor transcript role `DelegatedRequest` is slot-derived at ordinary turn
materialization, preserving model/application source and provisional grade.
Memory indexing treats it as application input by an explicit typed rule,
not as new human-speech evidence. Normal hooks and ToolAccessPolicy remain
enforced in addition to grant permission.

### 4.4 Owner lock order and admission-won-close receipt (V3-3)

New joint paths have explicit order: existing runtime-driver owner lock ->
live feature state lock -> short RuntimeStore transaction. Ordinary actor/
turn-finalization locks are NEVER acquired while holding a live feature lock.
Live observation append, effect-start claims and composite reads need only
live state/store access, not a driver or actor lock.

Admission/staging callers hold no live lock when entering the driver. The
driver acquires live state only to prepare the two generated transitions and
commit both exact expected versions; storage does not call back into either
owner. Feedback is applied under those locks, then released before waking an
actor or publishing a cross-owner command. A live coordinator may enqueue an
ordinary-driver request only AFTER releasing its state lock. This forbids
live->driver inversion, including close/cancel/callback paths.

Voice close spends ingress admission only. A persisted admission-won-close
receipt is sufficient to stage after close and after cold recovery, provided
CURRENT request cancel, grant revocation/expiry and executor-binding checks
pass. Explicit cancel/revoke/archive can block that execution authority;
ordinary voice close cannot. Channel delivery remains abandoned independently.
Required schedule: busy executor -> live admission commit -> voice close ->
process restart -> exact queued live input stages successfully once. The
inverse close commit -> delayed admission must refuse without any run.

### 4.5 Neutral run-scoped effect authorization (V3-1)

`RunPrimitive` gains mandatory neutral
`RunExecutionAuthority::{SessionPolicy, Scoped(ScopedRunAuthority)}`.
`ScopedRunAuthority` is sealed in memory, reconstructed only from a generated,
persisted `RunEffectScopeRecord` that binds live request/run-chain, actual
input/run, executor binding, admitted-execution receipt, grant generation,
permission intersection and remaining effect budgets. It contains no provider
final-turn proof. `RunPrimitive` -> runtime executor -> serialized session actor
-> every tool dispatch and provider request carries this exact scope.
Deserialize of a record alone never mints a permit.

The ordinary factory's existing outer execution-policy dispatcher becomes
scope-aware for EVERY build, including unrestricted agents constructed before
Live activation. Tools/catalog remain list-preserving; no temporary build-wide
policy mutation or clone of an already-built agent. A `SessionPolicy` run
uses ordinary policy; a Scoped run cannot fall back to SessionPolicy if
scope restoration or authority lookup fails.

Effect start order:

1. Resolve the actual effect target/tool mutation declaration and await all
   ordinary policy/hook checks. These checks produce candidate permission,
   NOT effect-start authority.
2. Immediately before invocation, call generated
   `claim_scoped_effect_start(request, run, effect_id, target, candidate_policy_revision)`.
   In one live-ledger transaction revalidate CURRENT grant/permission,
   cancellation/revocation/expiry and executor binding, intersect ordinary
   policy, reserve completion capacity, and persist one `EffectStartClaimed`.
3. Only the resulting one-use `ScopedEffectStartPermit` can reach the actual
   dispatcher invocation. Fast, async, deferred and callback dispatch entries
   must use the same seam. An awaited check cannot bypass the final claim.
4. Physical success/failure/cancellation/unknown returns by exact claim ID.
   A crash/lost feedback after claim is Unknown, never retried as a fresh effect.

Linearization is the DURABLE effect-start claim, not the first async policy
check. Revoke-before-claim refuses; claim-before-revoke is an admitted physical
effect that may already execute. Revocation requests exact cancellation and
records actual/unknown outcome; it cannot promise rollback or retract bytes
already sent. The revocation API reports outstanding claimed effects.
An unconsumed permit abandoned before invocation can settle NotStarted only
with local owner proof; restart cannot infer that proof from missing feedback.

Provider-native tools bypass tool dispatch, so Scoped Live runs disable ALL
provider-native tools at PER-REQUEST construction, including extraction,
fallback, retry and callback continuation requests. Provider-native search,
image and hosted/MCP/computer tools are absent from that run's request; a
provider adapter receiving contradictory enabled native-tool params rejects
typed. It cannot silently restore a model default. Ordinary dispatcher-owned
tools remain usable under the scope. No globally disabled native-tool state
leaks into the subsequent unrelated ordinary run.
The LLM request itself receives a model-computation claim; provider adapters
consume the neutral native-effects policy, not Live/OpenAI names.
All executor providers, including Anthropic/Gemini and fallback/extraction
wrappers, must preserve/enforce that per-request policy. An injected client
without a declared conforming scoped-native-effects capability fails public
execution activation; override-first injection is not a policy bypass.

Helpers/jobs/descendants inherit a sealed `DescendantExecutionScope` through
ToolDispatchContext -> actual mob spawn/work or job admission seam. It
intersects the current request grant, parent's scoped policy and child's
ordinary launch policy; reading only parent session launch policy is
insufficient. Model/tool arguments cannot supply, remove or widen this carrier.
Child/job creation and execution claims retain parent request lineage and
revocation reference. A helper continuation and a durable job resumed after
restart revalidate that scope; voice close does not revoke it. Explicit grant
revocation/cancel routes to the actual child/job owner. Long-lived descendants
created under this scope cannot escape it through a later ordinary turn;
changing that restriction requires explicit trusted owner reauthorization.

Scope is per run/chain, never a mutable session-wide override. After terminal
or callback suspension, the actor clears the active run handle while persisting
the chain record. A subsequent unrelated ordinary run installs SessionPolicy
and its original native-tool/dispatcher policy. Failure to restore scoped
authority is a typed hold, not unrestricted execution.

### 4.6 Callback suspension and owned run chains (V3-2)

One live REQUEST per ordinary run does not mean one RUN per request.
`LiveRequestRunChain` is keyed by the existing live request ID and retains
actual input/run links; no synthetic RunId or redundant provider call identity.
Ordinary `CallbackPending`/`CallbackBatchPending` is a committed run terminal
but a NONTERMINAL live request.

| Request chain state/input | Generated action / obligation |
|---|---|
| Running -> committed callback suspension | Record exact session suspension/batch ID, expected callback call IDs, originating actual input/run, scope and reserved continuation capacity; become SuspendedCallbacks. |
| Matching callback results arrive | Existing callback-result owner validates and persists results; chain records exact accepted batch completion witness, not a user prompt. |
| Wrong batch/session/request or conflicting duplicate | Typed refusal; no ordinary input or new run. Identical duplicate returns existing acceptance/continuation. |
| All required results present, current scope valid | Authorize one ExclusiveLiveRequest callback-continuation input keyed by request+suspension identity; payload digest checked separately. Link its actual run to same request/permission chain. |
| Partial callback results | Remain SuspendedCallbacks; no provider final output or fabricated tool result. |
| Voice close while suspended | Preserve chain and callback continuation eligibility under admission-won-close; provider output obligation is separately abandoned. |
| Explicit cancel/revoke/archive | Persist chain cancellation; accept late results only as retained callback evidence if existing owner permits, never authorize continuation. Resolve request with actual cancelled/held/unknown state. |
| Restart while suspended/continuation admission unknown | Restore exact ordinary callback suspension and request scope; reconcile same continuation key, never generate a new request or unrelated run. |
| Final non-callback ordinary terminal | Settle REQUEST outcome once; only then may its one final provider-result obligation be produced. |

Callback results continue through the existing SessionService callback seam,
not a parallel Live callback service. `RunPrimitive` continuation carries the
ordinary exact callback resume target AND ScopedRunAuthority; normal session
continuation admission cannot strip the chain restriction. The same singleton
selection/stage and exact cancellation fences apply to every continuation.
Completion capacity is reserved before callback-capable effect dispatch.
Additional continuation obligations must acquire credits before admission;
failure settles the chain through already reserved capacity (section 9.1).

## 5. Provider facts, result settlement and retirement

### 5.1 Three distinct facts (R6)

`KnownResponseIdentity(response_id)` can exist with outer scope
Absent or ExplicitNull. Retain all such lifecycle/terminal facts, including R2.
`ResponseAttribution` separately means Owned key, Unowned granular event, or
Ambiguous candidates, exactly as released helper returns. `ReadyFunctionBatch`
is a THIRD fact requiring the helper's ready barrier, known required scope,
created/successful terminal/all items done/no uncertainty.
Never rewrite Owned(None-scope) lifecycle to Unowned or ready.
Legal omitted item ID/status remains legal; supplied contradictory status
invalidates readiness while preserving known lifecycle identity.

Feed full ordered nested stream to published tracker; malformed/lost events
mark relevant collection uncertain. Tracker is bounded externally before
insertion. Late duplicates consult durable settled bindings/tombstones first;
new facts against a retired terminal cannot create a fresh batch.

Collection settlement is total: completed+safe becomes ready batch; completed
with zero calls becomes SettledNoCalls; failed/incomplete becomes
AbandonedProviderTerminal with retained items; missing created/unsafe scope/
contradiction/collection deadline becomes AbandonedUncertain after send
generation fencing. Those terminal records preserve known response identity
and release collection slots. A known running backend response with a
nonterminal post-R2 diagnostic remains pending until actual terminal or
explicit observation deadline/fence; the diagnostic itself never retires it.
Neither abandonment nor a terminal response invents missing call outputs.

### 5.2 Total work/output state table (R4)

| Work fact | RunId | Provider-required output disposition |
|---|---|---|
| Invalid/oversized/unsupported function or missing permission | None | Machine-authorized bounded typed error result for exact safely scoped call; if scope unsafe, explicitly AbandonBatchUnsafeScope. |
| Pre-start cancellation/refusal/TerminalWithoutDelivery | None | Typed cancelled/refused error output; no invented run success. |
| Repair-blocked/unclassified/unknown admission | None until proven | Pending/Unknown work; no final success output; operator-visible recovery hold. |
| CallbackPending/CallbackBatchPending | Actual suspended run | Nonterminal request; exact callback chain retained, no final provider output. |
| Final ordinary run completed/failed/cancelled | Actual exact run | Request-terminal result/error after chain classification, with certified artifact refs. |
| Running during voice close | Actual input/run if known | Work continues; output obligation AbandonedByChannelClose, result later retained for reads. |

Public delivery states are NEW public-specific states, not weakening private
`RetireSettledLiveBridgeOperation`:

| Attempt state/event | Durable settlement | Slot release |
|---|---|---|
| Authorized, not claimed | No bytes sent | Can abandon on close/cancel or claim once. |
| Claimed, explicitly NotEnqueued | Proven no write | Machine may reauthorize same attempt payload if still current, or settle NotSent. |
| Successful physical write feedback | WrittenConsumptionUnconfirmed (TERMINAL delivery) | Persist immutable attempt/result history; release active output slot. No ACK needed. |
| Ambiguous write or lost feedback after claim | AmbiguousUnfenced | Fence channel send generation; persist SendGenerationFenced -> AmbiguousFenced (TERMINAL delivery). Release slot after fence commit; no resend. |
| Provider correlated rejection | RejectedAfterWrite or RejectedBeforeWrite as proven | Retain actual work; terminal delivery, no fresh executor task. |
| Closed/replaced before write | AbandonedByClose/Replacement | Terminal delivery; release after durable record. |

Physical writer receives a generation-bound send permit; fenced generation
cannot begin/dequeue more application writes. Already in-flight writes remain
ambiguous. An exact privileged close permit allows bounded observation drain,
then driver-stop acknowledgment (or bounded abort) completes fence retirement,
with unconfirmed provider-close outcome if needed. Thus ambiguous debt retires
without pretending bytes were processed or stopping observation merely because
a nonterminal diagnostic arrived.
Replacement creates a new channel and fresh projection, never replays old
function output/continuation. Original work may settle after replacement.

### 5.3 Session-wide continuation (R4)

Public ResponseCreate has no target argument. `LiveRequestMachine` maintains
at most one active continuation attempt for the exact provider channel.
Each batch has generated continuation eligibility:
PendingOutputs -> EligibleUnclaimed -> ClaimedByAttempt -> Spent, or
Abandoned. Selection MUST be nonempty and contain only EligibleUnclaimed
batches, disjoint from every previously claimed set. In ONE transaction,
claim/spend EACH member's eligibility and the exact covered set/attempt,
with completion credits reserved. A set digest alone is not dedup authority:
after claiming {A}, neither {A,B} nor another {A} may claim A again.
Empty/subset/superset/overlap requests fail exact membership validation.
All known required outputs in that set must be WrittenConsumptionUnconfirmed
and no known incomplete/conflicting collection may cross the selected event
frontier. Written does not prove remote acceptance; that is explicit contract.

After durable WrittenConsumptionUnconfirmed feedback, release continuation
slot immediately; no unprovable R2 consumption receipt required. Same spent
batch set cannot cause another ResponseCreate, even after restart. A new batch
requires a different actual source set, never a new nonce for the same work.
Unattributed provider responses do not themselves trigger another continuation.
Unexpected new call facts for a spent set become conflict/uncertain, not a
reissued continuation. Ambiguous write follows send-generation fencing and
then slot retirement above.

Record R2 lifecycle under its actual ID/scope independently. A correlated
error AFTER R2Created is a bounded nonterminal `ProviderDiagnostic` observation,
not existing channel-terminal `LiveAdapterObservation::Error`; keep receiving.
Only separate transport continuity-loss/explicit provider close ends channel.
No mapping of model speech/R2 completion to individual result consumption.

If any required output is terminal NotSent/Rejected/Abandoned instead of
WrittenConsumptionUnconfirmed, the aggregate becomes
ContinuationNotAttempted { missing_required_outputs }. Its batches become
Abandoned, never eligible. Because the provider may still require those
outputs and ResponseCreate is untargeted, fence application sends for that
provider session BEFORE allowing any other continuation; explicit close and
replacement are required. Existing work and observation drain remain separate.
A proven NotEnqueued retry, if policy allows it, reuses the SAME claimed
attempt and member set with new bounded credits; members never revert to
EligibleUnclaimed.

Late exact output rejection after local settlement appends a bounded
supplementary ProviderRejected fact, retaining the true physical Written fact.
It never reopens output/member eligibility. Before continuation claim it
causes aggregate abandonment/fence; after a claimed/written continuation it
records uncertainty without another send. A generic correlated handoff error
after R2 creation remains nonterminal diagnostic, not proof of missing outputs
or permission to rerun. Send fencing blocks new application claims/dequeues;
already in-flight writes remain explicitly ambiguous. The reader may drain
until exact close or bounded timeout; physical driver stop acknowledges that
no further old-generation write can begin before final fence retirement.

### 5.4 Context attempts, ACKs and retirement (R4)

Projection creates immutable bounded plan ID/source range/chunk digests/intent.
Track three frontiers: source considered (includes explicit omissions),
source attempted/written (cannot be automatically resent), and correlated
injection observed. They are not one cursor.

Each chunk claim is durable before send. Written settles
WrittenInjectionUnconfirmed; optional exact client_event_id ACK adds observed
estimated range only. ACK without ID is retained as UncorrelatedInjection;
no positional/FIFO guess, no cursor reassignment. Timeout without correlated
ACK settles WrittenInjectionUnconfirmed and retires active wait slot; it does
not reset attempted frontier. Late exact ACK can enrich immutable history
without reactivating/send permission. Equal start/end ACK interval is legal.

For partial plan: written prefix is spent; not-enqueued suffix may be explicitly
continued only if still authorized and digest-identical. Ambiguous chunk fences
generation and abandons unsent suffix. Feedback-loss after claim is ambiguous,
not unsent. Refresh/reopen never resends claimed chunks under same plan; a NEW
channel may project current retained facts with a new disclosure plan and
explicit continuity loss, not claim delivery repair. Instructions are host
steering; thinking quiet facts; commentary speakable result. ACK never speech.

### 5.5 Exact retirement rules (R4/R9)

Unsettled machine/tracker slots release only after durable terminal disposition
and immutable identity/digest/outcome history is committed. Work and delivery
slots are independent: completed written delivery can retire while work is
still awaiting an independently owned job; cancelled/closed delivery cannot
erase unknown admission/cancel intent. Unknown admission slot persists until
atomic admission index reconciliation or explicit unrecoverable terminal
classification with original source spent. No invented success needed.

Settled response item bindings, source keys, output/continuation set IDs and
request payload digests remain durable indexed tombstones until whole session
deletion. They do NOT occupy bounded unsettled in-memory slots. Late events
perform bounded keyed reads from canonical history; missing/unreadable history
is explicit uncertainty, never assumed absent. Compaction cannot delete these.

### 5.6 Exact function request contract (restored V1 normative)

The sole managed tool is `invoke_meerkat`. Its JSON argument schema is:
object, required `request`, `properties.request` string with minLength 1,
`additionalProperties=false`. Provider-owned decode into
`InvokeMeerkatRequest` additionally rejects whitespace-only request and more
than 16 KiB UTF-8 bytes. Preserve exact accepted bytes/digest; no trim-and-retry.
There are no authority, policy, model, executor, path, tool-list or grant
fields. A path mentioned IN request prose is task content, not authority.
No consumer tool definitions are exported to the managed voice backend.

Only exact complete safely scoped call evidence can own error-output delivery.
Malformed JSON, extra fields, unknown function, blank/oversize input or missing
permission produces bounded typed failure output for that call with no run.
Unsafe ownership instead abandons collection and fences continuation; never
invent a call ID or choose the latest scope. If no completion credits can be
reserved, the event is unaccepted and channel control reserve closes/fences
without claiming the source was spent.

### 5.7 Authorized disclosure and projection policy (restored V1 normative)

Canonical executor history remains complete and separate from voice context.
Default voice disclosure excludes executor System instructions, tool
definitions/results, MCP configuration, skill bodies, memory authority/injected
memory and private bridge instructions. Explicit authorized task result or
application context may be disclosed only through its typed projection policy;
it is never promoted into voice InstructionsAppend because it contains text.
Short voice style/delegation instructions come from trusted voice profile only.

`LiveContextProjectionPolicy` has explicit Reject and RecentAuthorizedSuffix.
Stock profile definition selects RecentAuthorizedSuffix; trusted activation
still defaults disabled. Reject refuses before provider I/O if the required
authorized selection cannot fit. RecentAuthorizedSuffix selects whole
authorized records/messages in source order, reports omitted ranges/reasons
and degraded continuity, and never silently slices a tool exchange or labels
continuous observations as final turns. Reopened voice-only observations enter
the new provider seed with nonfinal/source provenance and disclosed omission.
`seed_max_chars` on the old API retains its legacy guarantees; public profile
rejects that option as specified in section6 rather than changing its meaning.

Provider hard limits remain 128 startup messages / 8192 rendered history
tokens, 16384 instruction tokens, 500 tokens per append. Local byte limits in
section9 are conservative product policy, not proof of tokenization. Provider
limit error is visible; no hidden summarizer, prompt rewrite or automatic
smaller retry. Thinking carries quiet factual progress; commentary carries a
validated speakable result; instructions carries trusted steering. Nullable
delegation is null or exact CLIENT delegation only, never Responses/call ID.

### 5.8 Accounting identities and advisory fault scope (restored V1 normative)

Three independent accounts:

- Voice: cumulative finite seconds keyed by exact provider session/channel,
  replace snapshots rather than sum; final only from valid session.closed,
  even if snapshot.status remains active.
- Managed backend: actual response-token observations keyed by actual provider
  session + response ID, with outer scope presence and actual model evidence
  retained separately. A call batch or delegation ID is not a token account.
- Executor: existing ordinary run token accounting keyed by actual session/run;
  callback chain may contain several runs. Never merge it with voice or
  managed-backend counters.

Published `ResponseSnapshot` (`src/live/responses.rs:1381-1396`) has no typed
model/usage fields. NEW provider-owned bounded `BackendAccountingObservation`
decoder extracts ONLY known model/usage fields from the original nested
`ServerFrame.raw` response object after normal event decoding. It does not
pretend the FunctionCallTracker exposes counters. Validate finite/ranged
integer counters, response identity and supplied model; retain missing fields
as Absent/ModelUnconfirmed. Unknown fields stay raw provider evidence. Missing
actual model is not filled in from configured bridge model; unattributed
counters are visible but not silently charged to a guessed account.

Dedup/monotonic accounting uses response ID and validated counter snapshot,
not number of nested events or outer scopes. Conflicting supplied model,
counter regression, malformed extra accounting or missing final usage emits
typed nonterminal AccountingUnmeasured/AccountingDisputed evidence. These
advisories cannot fail a correct executor request, mark a call batch failed,
trigger a retry or use generic terminal LiveAdapterObservation::Error.
An independently malformed control/protocol frame remains its actual protocol
fault; it is not laundered into accounting success or used to rewrite an
already committed executor outcome.

## 6. Full open/input/refresh contract (R7)

NEW neutral `LiveAdapterFactory/OpenConfig/ResolvedLiveTarget` carries typed
ModelInteractionKind; legacy factory wraps mechanically with no semantic mirror.
Public stable model supports continuous Live only, not text Responses/Chat
Completions or old realtime. A custom `[models.gpt-live-1]` collides with the
new built-in: preserve existing duplicate-model rejection, now with explicit
migration diagnostic instructing operator to remove/rename obsolete custom row.
No auto overwrite, custom precedence or silent capability adoption.

| Input/control | Activated public profile | Existing legacy/private behavior |
|---|---|---|
| profile_id absent | Ordinary legacy path unchanged; non-realtime executor does not auto-select public profile | Existing resolution. |
| profile_id explicit null | InvalidProfileSelector before provider I/O | New field only; no null-as-inherit. |
| profile_id present | Resolve exact profile + trusted activation bound to session/realm | Private execution_identity remains its separate path. |
| profile_id + execution_identity | MutuallyExclusiveSelection before any provider I/O | No alias or fallback. |
| turning_mode omitted | Continuous (new truthful capability/enum) | Existing default unchanged without public profile. |
| turning_mode Continuous | Supported public mode | Legacy rejects new unsupported mode. |
| turning_mode ExplicitCommit or ProviderManaged explicitly | UnsupportedTurningMode for continuous profile | Existing supported modes unchanged. |
| seed_max_chars omitted | Public bounded disclosure policy with omission/continuity metadata | Existing full seed promise unchanged. |
| seed_max_chars present, including zero | UnsupportedSeedWindowForContinuous (zero remains invalid) | Existing positive whole-turn seed contract unchanged. |
| live/send_input Text | UnsupportedInputKind before queue/provider write | No user text -> thinking/instructions translation; ordinary session text turn is separate. |
| Audio | PCM24 stock WS; validated negotiated formats on supported host path | Sideband cannot send primary audio; RTC uses media tracks. |
| Image/Video | UnsupportedFrontendModality before I/O | Existing legacy image semantics remain. |
| commit/interrupt/truncate/playback_complete | UnsupportedCapability, never success | Existing supported legacy/private behavior unchanged. |
| local playback mute/stop | Browser/local media action, untrusted diagnostic | Does not cancel work or rewrite provider transcript. |

All commands use this same provider-neutral capability validation for RPC,
SDK and direct WS. Validate before local queue acceptance that would return a
success-shaped receipt; ordered driver rechecks generation/capability at dequeue.

### 6.1 Profile-aware reconfiguration

NEW shared `LiveProfileBinding` stores voice identity/profile revision,
executor binding, activation and credential owner separately. Replace existing
executor-realtime assumptions in precheck/refresh/identity-cleanup/config
propagation for this binding class only. One facade classification helper
returns Preserve, QuiescentBackendUpdate, ReplaceRequired, or Revoke.

| Change | Rule |
|---|---|
| Ordinary text turn / executor history append | Preserve voice identity; project newly authorized committed context at boundary; live log unchanged. |
| Executor model/auth changes | Existing ordinary hot-swap owner executes. Revalidate activation allowed executor scope and tool policy before next work. Preserve voice when permission remains; otherwise revoke request admission, require reactivation. Never send executor key to voice. |
| Executor generation/member respawn | Fence old request admission/delivery; retain outcomes; new exact grant binding/open required. |
| Voice model/auth binding/voice/audio/mode/permissions/instructions seed change | ReplaceRequired, no in-place switch or silent reopen. Revoke new admission under old declaration where permission changed. |
| Bridge Responses mutable config | Stage typed sparse update; apply only with no unsettled collection, output or continuation claims. Exact update ACK needed before admitting work under new revision; timeout is ConfigUpdateUnconfirmed, not old/new guess. |
| Profile disable/activation revoke | Durable ingress/grant fence immediately; queued/unknown admission cancellation protocol applies. |
| Context policy/limit edit | New projection plans use new revision only after owner validation; old claims retain their original immutable plan. |
| Invalid/unknown config | Typed rejection, no fallback/default reset. |

Config propagation triggers on live profile definitions, activation revision,
auth-binding/backend changes and executor changes, not only agent.model.
Explicit `live/refresh` reads current OWNING host config and binding; does not
rebuild voice identity from executor model/messages/tools. No provider history
replay on refresh. Immutable changes are surfaced with exact replacement reason.

## 7. WS, RTC readiness, privacy and diagnostics (R5)

WS uses library secure HTTP upgrade, no query model, sole first session.start;
SessionStarted binds exact provider ID. RTC uses 201 minimal id+answer, early
trusted sideband attach, created==attached identity. SessionStarted, answer
delivered and peer-reported media readiness are independent typed facts.
Existing answer custody/rollback is reused; no seed ACK hack.

DIRECT BROWSER DATA CHANNEL POLICY:
`allowed_client_events=[]`.
Production `allowed_server_events` contains ONLY
`session.input_transcript.delta` and `session.output_transcript.delta`.
No `response.event`, session.started/updated/closed, error, info, delegation,
usage snapshot or wildcard. Media is RTP tracks, not these JSON selectors.
Transcript content is explicitly disclosable conversation output, not private
backend configuration. Privacy here prevents deterministic config/argument
event leakage; it does not claim the model can never speak sensitive content.

Session lifecycle/readiness/usage/errors come through trusted server sideband
and REDACTED Meerkat projections over the native host event stream. Provider
session snapshots/raw error/info never enter browser transport. Error/info can
echo instructions/arguments, so no blanket claim that their raw bytes are safe.
Sentinel tests inject private voice seed, backend instructions, tool schema,
function arguments, request IDs/secrets into snapshots AND error/info bodies;
browser capture must contain none. Redaction happens before bytes leave server.

Primary-only rejection creates an unavoidable observability distinction:
production direct browser cannot safely receive arbitrary provider error/info
AND guarantee private bytes absent. The SDK local send facade rejects all
provider commands as `FrontendCommandDisabled` before wire send; this is LOCAL
policy evidence, not claimed provider denial. Malicious direct page sends may
be denied remotely with filtered error; native host reports no fabricated
sideband rejection/acceptance. Peer-provided diagnostics (RTC/network/local
policy errors) remain typed UntrustedPeerObservation, never machine authority.

Qualification separates two tests instead of weakening production privacy:
(a) production browser allowlist with malicious command -> no backend effect
and no private-bearing event leakage; (b) trusted native primary test peer,
owned by test host and containing only synthetic disclosable config, enables
error reception and verifies actual provider denial is primary-only while
trusted sideband progress continues. This diagnostic mode is fixture-only,
not an RPC-selected production profile or claim that browser received the
provider error. Root approved this explicit product tradeoff; implementation
still must pass privacy and no-effect tests.

Post-admission sideband diagnostic is typed nonterminal with safe code/class,
known optional response identity and attempt correlation. Raw body retained
only in explicitly private bounded evidence access, never public Debug/log.
Do not use generic terminal Error for incomplete-handoff diagnostic.

## 8. Full member-profile chain and config freshness (R8)

Add selector carriage, never grants/credentials, through:

1. CLI `rkat mob live open --profile <id>` and SDK/RPC
   `WireMobMemberLiveOpenParams.profile_id`.
2. MobHandle/actor member-live request and `member_live_proxy`.
3. Versioned `BridgeLiveOpenPayload` plus generated supervisor bridge schema.
4. Member drain command -> `MemberLiveHost::open(..., profile_id)`.
5. Owner `ServiceMemberLiveHost` -> shared per-open profile/factory/activation
   resolver -> ordinary LiveOrchestrator.

The same explicitly versioned native member contract adds exact
`CancelExecution { live_request_id }` control and bounded execution-state
projection for its newly admitted public requests. The
owner resolves request->input/run under its grant/fences; the controller never
supplies a RunId or generic interrupt-current command. Capability absence
rejects, not downgrade. REST/PUBLIC MCP exclusions still apply. Retained
observation reads use the owning session history/live-read service; remote
member history replies must expose the independent history summary/owner
locator rather than misreporting voice-only history as empty.

New bridge protocol capability/version explicitly declares selector support;
old remote host fails typed UnsupportedProfileSelection before open, never
drops field or uses its default. Do not reinterpret deprecated bridge versions.
Rust carrier/domain types, wire schema, generated SDK/wrapper/catalog fixtures
and bridge negative tests change together.

Owner determines profile contents. Same profile name on controller and placed
host may mean different definitions; request carries name only, response
projects actual owner profile revision/model/capabilities. Controller cannot
push its resolved credentials/grant into remote host. Existing operator grants
authorize member control; separate owner activation authorizes live execution.

`ServiceMemberLiveHost` receives shared `LiveCurrentConfigSource` explicitly;
config_runtime=None does not select a stale memory fallback. For CLI mob host,
replace startup-only MemoryConfigStore usage ON THIS path with the same
owning-realm source/reader that can re-read current config and activation before
each open/refresh. In-process injected immutable test config is an explicit
source, not silently assumed live. Read failures are typed, not cached success.
Preserve inherited credential owning realm and independent requested realm.

Mandatory chain tests: two activated profiles local and placed, profile edit
between opens, owner inherited auth, controller/owner same-name divergence,
missing remote capability, missing owner activation, and unchanged existing
member WS behavior. REST/PUBLIC MCP exclusion tests forbid accidental CONTROL
addition; the bounded retained-history read below is explicitly observation-only.

### 8.1 Callable remote retained observation history (V3-8)

A locator or summary is insufficient. Add a bounded read-only
`mob/member_live_observations` operation with actual routing:
wire/mob request -> MobHandle/actor observation request ->
`member_history_proxy` -> versioned supervisor
`BridgeMemberLiveObservationPageRequest` -> owner `host_observation` handler ->
injected independent live-ledger reader. It parallels existing
`wire/mob.rs:3382-3391`, `host_observation.rs:1924-1977`,
`member_history_proxy.rs:49-81`; it does NOT route through a nonexistent
ordinary-session RPC endpoint on the CLI owner daemon.

Request: mob/member identity, optional exact channel filter, optional opaque
`LiveObservationCursor`, positive limit (default64, max256). Response:
canonical session/member/channel provenance, store-issued live snapshot
revision/prefix, typed observation records (NOT Message), coverage/gap class,
next cursor and has_more; at most128 KiB of exact compact serialized
`BridgeReply::MemberLiveObservationPage` bytes per page, including its variant
wrapper and all cursor/provenance/coverage fields. Every request
passes existing authenticated member-history observation authorization before
owner storage access. Active voice channel/activation grant is NOT required
to read authorized retained history.

**One authoritative encoding contract, used at admission AND read.**
NEW `LiveObservationWireCodecV1` in `meerkat-contracts/src/wire/` owns the
canonical record encoder, complete reply encoder and versioned bounded
page-envelope profile. It uses bounded serialization into the actual byte
representation, not decoded text length, escaping multipliers, or a second
pager-side estimate. The profile bounds every variable wrapper, cursor,
provenance and coverage field; its maximal legal metadata variants and numeric
widths are encoded through that SAME reply encoder. Optional cursor and
has_more alternatives are included in the maximum, not assumed absent.
Supported transport envelopes have separately bounded framing ceilings; the
profile verifies this 128 KiB reply plus their maximal encoded framing fits
the actual transport limit before advertising the page contract.

Before observation acceptance, encode its exact immutable record inside a
ONE-RECORD reply using that worst-case legal page metadata profile. Accept
only if the complete encoded reply fits 128 KiB. Keep the decoded 64 KiB text
and 4 KiB metadata ceilings as ADDITIONAL limits, never as proof of wire fit.
Persist the codec/profile version and exact record digest with the admission.
An escape-heavy raw delta that cannot fit is explicitly unaccepted with the
existing gap/close policy and reserved control capacity; never truncate or
record it as accepted. This includes 65536 newlines/backslashes (already
131074 encoded string bytes) and NULs (393218), before enclosing fields.

Paging uses the same codec to encode actual complete candidate replies and
choose the maximal fitting nonempty prefix, including the resulting next
cursor. If records remain and the request limit is positive, at least the first
accepted record MUST fit by its persisted admission contract, so the next
cursor advances. It may not return empty success, skip/truncate an accepted
record, or permanently surface RowTooLarge for valid accepted data. Corruption/
unsupported schema is a distinct typed integrity fault, not normal paging.
Codec/envelope evolution requires an explicit version and preservation of the
admitted version's read-fit guarantee; no silent increase in reply overhead.
Prior art is `meerkat-runtime/src/comms_drain.rs:5995-6088`, which measures
serialized BridgeReply and tests the first row before prefix selection.

Quota and completion-credit proofs use the same canonical encoded-byte unit:
the codec reports exact record/complete-reply charges, and ledger envelopes/
reserved terminal envelopes are sized through the shared bounded encoder.
Decoded text bytes are never substituted for their serialized charge.
All maximum metadata/escaping fixtures used for admission fit also participate
in quota/control-credit tests; no parallel sizing formula can drift.

Cursor v1 binds source session, channel filter, immutable snapshot end prefix
and after-sequence. It is a bounded validated query token, not access
authority: authorization is repeated on every page. Owner checks the captured
prefix and filter, never trusts a forged cursor to select another session.
Append-only later observations do not invalidate a captured prefix. Deletion/
missing retained snapshot is typed CursorExpired; wrong owner/filter is
CursorMismatch, never automatic rebasing or empty success.

The read works after voice close and owner process restart via the SAME
authenticated member bridge; controller has no direct owner-store access.
Re-resolve current owner route normally, then validate cursor's original
session/history lineage. Older peer without declared observation-page
capability rejects Unsupported; never fall back to ordinary Message history.

Expose CLI `rkat mob member-live-observations`, typed RPC/Python/TS wrappers,
and the existing read-only REST/PUBLIC MCP observation families through their
generated feature declarations. These are history reads with normal
observation grants, not member-live open/send/refresh/cancel controls.
Explicit catalog tests keep all mutation/control exclusions intact. Local
one-shot CLI history reads may use its existing authorized observation path;
that does not make local one-shot CLI live OPEN supported.

## 9. Boundedness without a hidden session lifetime (R9)

The numerical limits below are conditionally approved D4 policy defaults, not
provider tokenizer guarantees. Count AND accounted bytes (payload + IDs +
serialized metadata + container overhead reservation) are checked pre-insert.
Actual sizes are measured on bounded serialization; no unbounded diagnostic
or raw-event clone before checks.

| Resource | Active-memory bound | Release / durable retention |
|---|---|---|
| Backend response collections | 32 UNSETTLED responses, 128 items each, 1 MiB aggregate accounted | Terminal collection -> durable bindings/tombstone then evict memory. Not 32 lifetime responses. |
| Live work | 128 unresolved reservations/admissions/work states, 4 MiB accounted | Canonical input terminal or explicit unrecoverable classification; settled history indexed on disk. |
| Result/continuation attempts | 128 unsettled outputs, 1 continuation, 4 MiB payload/metadata | Written-unconfirmed or fenced ambiguity is terminal; durable spent IDs remain. |
| Incoming text commit queue | 256 records / 1 MiB accounted | Successful durable append releases; failed/overflow marks gap and stops admission. |
| Individual accepted observation | Decoded <=64 KiB text / <=4 KiB metadata PLUS exact one-record reply fit under LiveObservationWireCodecV1 maximal metadata profile | Accept only when full compact serialized reply <=128 KiB; unaccepted oversize becomes explicit gap/fault, never truncation. |
| Persistent live text/history | 1,000,000 records / 256 MiB accounted per session, configurable trusted storage quota | No silent trim. Explicit quota fault closes ingress and retains prefix. Quota is disclosed, not an accidental request limit. |
| Tombstones/settled request index | Included in persistent record+byte quota, not active tracker cap | Until authorized entire-session deletion. Keyed reads on late duplicates. |
| Provider event queue | 256 events / 4 MiB accounted | Ordered consumer releases; continuity fault on overflow, no drop-to-success. |
| Media buffers | 2 MiB total per direction and <=2 seconds at negotiated rate, whichever smaller | PCM/codec-aware pacing and backpressure; latency overflow closes/degrades with loss fact, no unbounded buffer. |
| Diagnostics | 64 active / 64 KiB; each safe public <=1 KiB, private raw prefix <=4 KiB | Durable bounded category/count summary plus explicitly redacted history within quota. No backend raw bytes to browser. |
| Context plans | 8 active / 64 chunks total / 64 KiB accounted | Written/uncorrelated/timeout/fenced states retire as section 5; immutable digests/history persist. |
| Startup/history | <=32 selected messages / <=4096 UTF-8 text bytes | Projection only; explicit omission ranges/continuity, retained canonical source unchanged. |
| Instructions/appends/request/result | 8192/400/16384/16384 UTF-8 bytes respectively | Explicit local constraints; provider 16384/500/8192-token limits still checked by provider and errors surfaced. |

High-volume metadata-only/empty observations count and consume accounted bytes.
Trace fixture must exceed 100 sequential successful request/response cycles
without active-slot leak; no ~16-request lifetime cap. Exhausting disclosed
persistent quota is a distinct typed StorageQuotaReached with durable retained
history, not eviction. Rollover requires explicit new session/channel operation,
not silent tombstone loss.

### 9.1 Reserved completion/control capacity (V3-4)

Quota admission checks BOTH `used + reserved <= configured limit` for records
and accounted bytes. Reservations are generated LiveTranscript/LiveRequest
state, persisted in the same head CAS as the accepted obligation. Observation
ingestion may spend only UNRESERVED capacity, never capacity owed to work.
No unlimited emergency quota or history eviction exists.

The versioned schema defines `CompletionEnvelopeBudget` for each obligation,
derived from its bounded variant/ID/text encodings plus accounted metadata.
Before provider open/channel activation reserve 64 control records / 128 KiB
for close, gap/discontinuity, send fencing, final/unconfirmed usage, revoke and
recovery outcomes. This is part of the configured quota, not extra space.
Fixed-size terminal diagnostic summaries and duplicate observations reuse
their declared bounded slot; they cannot demand unbounded append records.

Per-obligation proposed reservation ceilings:

| New obligation | Reserved records / accounted bytes before acceptance |
|---|---|
| Source reservation and request/run-chain admission | 32 / 160 KiB, including runless refuse/cancel, final bounded result, late input fate and tombstone |
| Effect-start claim (including potential deferred/callback suspension) | 32 / 96 KiB, including physical unknown/cancel and callback suspension/reference outcome |
| Each function-output attempt | 16 / 48 KiB, including bounded output, write result, late exact rejection and fence settlement |
| Each continuation attempt/member-set closure | 16 / 32 KiB plus bounded member-list serialization |
| Each context chunk claim | 12 / 8 KiB, including 400-byte text, write/ACK/no-ID ACK/timeout and prefix disposition |
| Each additional callback continuation | 16 / 48 KiB plus ordinary input reservation; acquire BEFORE admitting new continuation |

These ceilings are not guesses to bypass serialization: representation tests
construct every maximum-length terminal shape and prove it fits its declared
budget. Accepted variable result/body values must fit the reserved envelope;
oversize raw diagnostics are bounded/redacted, and ordinary large tool results
use existing blob storage with exact references rather than copying unbounded
bytes into the Live ledger. Invalid budget schema fails Gate0.

Commit converts reserved credits to actual used records/bytes atomically.
Unused credits release only when the generated owner proves the obligation
has no remaining accepted completion/control writes. Late-outcome credits
remain reserved until exact outcome or channel/attempt observation closure;
they are NOT unsettled execution slots. Duplicate late feedback returns the
existing receipt without another record. After final observation closure,
new late diagnostics are explicitly unaccepted, not silently recorded as
canonical contradictory outcomes.

Before new output/context/effect claims or callback continuation, acquire any
additional credits. If acquisition fails, DO NOT begin that obligation:
settle the enclosing accepted request/plan from its EXISTING reserved
ResourceCapacityRefused/ContinuationNotAttempted/fence capacity. Ordinary run
failure/cancellation feedback remains possible. Callback-capable effects
already reserved a suspended/failed-chain exit before external dispatch.
Unlimited retries cannot consume another reservation without fresh capacity.

At full unreserved quota, new provider text/source traffic is
UnacceptedAtCapacity: no fabricated source key spent, no accepted observation.
Use existing channel control credits to commit the known gap or unknown-extent
discontinuity and close/fence. Continue accepting ONLY already-owed bounded
outcomes against their reservations until truthful settlement. This covers
active work, runless late admission, output/continuation ambiguity and each
partial context chunk. A true storage I/O failure remains StorageUnavailable
with retained uncertainty; reserved logical quota is not a guarantee against
disk failure, and no success is fabricated.

## 10. Finite fault and behavioral verification matrix (R11)

For each listed window inject crash/cancel BEFORE and AFTER the named durable
commit and lose its reply. Symbols: O=observations, S=source reservation,
I=input, R=run, W=output write, C=continuation, K=context chunk.
Every test asserts exact source/payload/operation/input/run/generation identity,
durable record counts and allowed future effects, not only process exit.

| Window | Durable expectation | Permitted next action / exact cardinality |
|---|---|---|
| F01 observation append | Before: no accepted O; after: exact O once | Known replay bytes commit once; crash recovery reports unknown extent, not invented lost count. |
| F02 actor checkpoint/final versus O, both orders, both physical modes | Actor receipt unchanged by O; O prefix unchanged by actor | No weak CAS, duplicate message, lost text or replayed tool. |
| F03 source lookup/reserve/freeze | Before: lookup same stable source; after: same immutable S/frontier | Replay never reads newer text; D2 uses reserved frontier even if D1 reply delayed. |
| F04 refusal/empty/gap reservation | Exact spent source and disposition/range | Zero I/R/tool effects; explicit new source only. |
| F05 input admission before/after close/revoke | Atomic I+source link or durable refusal | At most one I; close-winning source cannot start later. |
| F06 cancellation while admission unknown | Persistent source cancel intent | Zero run if intent wins stage; otherwise only exact original R cancel. |
| F07 input selection/staging with other queued input | Exclusive singleton input batch | Exactly one live request per R; ordinary background input runs separately. |
| F08 tool effect before/after ordinary checkpoint/terminal | Existing run/job evidence and held/unknown tail rules | No promise of exactly-once arbitrary external I/O; no automatic second request. |
| F09 executor terminal/result projection persistence | Exact input terminal (or runless fate) and result digest | Same result projection replay; no synthetic RunId. |
| F10 each output claim/write/feedback | Unclaimed=no send; claimed unknown=ambiguity; written=terminal unconfirmed | Max one write attempt unless proven NotEnqueued; fence before ambiguity retirement. |
| F11 continuation claim/write/feedback | Exact spent covered-set survives restart | Max one physical attempt per spent set; no R2 receipt needed for release. |
| F12 R2 created then correlated error/terminal | Known response ID preserved even scope absent/null | Observe, no rerun/no automatic close; wrong scope never ready. |
| F13 each K claim/write | Immutable plan/chunk attempted frontier | Written prefix never resent; explicit unchanged unsent suffix only. |
| F14 each ACK correlated/uncorrelated/late/missing | Separate attempted/injection frontiers | No positional attribution; no retry because ACK absent. |
| F15 context cursor/history retirement | Immutable settled plan and tombstone remain | Next projection uses considered/attempted refs, not ACK-only replay. |
| F16 open/create/attach/token/answer/publication | Exact pending resource/custody states | Close exact created ID, no published orphan token; unconfirmed close honest. |
| F17 close/archive barrier and in-flight O/S/I | Durable ingress order, retained prefix and intents | Earlier admitted I may continue on voice close; archive uses work owner. |
| F18 old generation result/cancel/write | Original work can settle, generation send fence remains | Zero new-channel old-result writes; delayed cancel never next unrelated R. |
| F19 quota/byte/count overflow | Retain existing accepted records and explicit gap/fault | Zero eviction-enabled duplicate admission; zero unbounded memory. |
| F20 old-reader/new-format, migration crash | Old binary refuses; new schema activation all-or-nothing | Original v3 private/Realtime bytes unchanged; no frozen importer rewrite. |
| F21 unrestricted prebuilt executor; revoke during async policy wait | Scoped run/claim or exact refusal under current grant | Revoke-before-claim gives zero effect; claim-before-revoke retains actual/unknown effect. Native-tool and child/job escapes fail; later ordinary run policy restored. |
| F22 callback pause/results/continuation/restart | Actual callback suspension and same request/run chain | One final provider output only after chain terminal; wrong/conflicting batch gives zero continuation, duplicate gives at most one; pause-close may resume, pause-cancel/revoke cannot. |
| F23 admitted queued work -> voice close -> cold recover -> stage | Admission-won-close and current execution scope | Exactly one run succeeds despite closed ingress; close-before-admission zero runs; delayed cancel never next unrelated run. |
| F24 quota full with active work/output/context/callback obligations | Used and reserved capacity remain within BOTH limits | No new obligation without credits; every owed close/fence/unknown/runless/late outcome settles without eviction or emergency quota. New unaccepted source not marked spent. |
| F25 continuation empty/subset/superset/overlap and replay | Every batch has at most one claimed eligibility and persisted covered set | Empty/reused members yield zero new send; failed required output yields ContinuationNotAttempted and fences further untargeted continuations. |
| F26 zero versus many volatile lost text deltas | Identical durable head/control state | Identical unknown-extent recovery, no fabricated receive high-water; no snapshot crosses old gap; explicit clean replacement interval can admit. |
| F27 function schema/disclosure/accounting negatives | Safe scoped refusal or advisory accounting with correct work retained | Extra authority fields never dispatch; excluded private context never seeded; missing/disputed counters cannot fail correct work or charge guessed model. |
| F28 remote observation paging after owner restart | Stable authorized prefix/cursor/provenance and admitted codec/profile/digest | Escape-heavy maximum-metadata ACCEPTED records survive read/restart unchanged; every byte-limited page with remaining data is nonempty and advances; repeated paging reconstructs the captured prefix exactly with no skipped/truncated/RowTooLarge accepted row. |
| F29 isolated public and shipping binary features | Actual selected dependency-feature closure and nonzero executed inventory | Public-only WS/RTC positives run real factory and ordinary effect; default RPC/placed CLI host run; one-shot local CLI stays unavailable. |

Explicit full-executor scenarios: async non-Fast MCP completion, async callback
tool, hook denial with zero denied effect, memory retrieval, inbound comms while
busy queued to separate run, inherited child tool policy, actual mob helper,
durable job progress and terminal AFTER voice close and process restart.
Assert physical result/state, not tool catalog presence.

Four successful actual-provider quadrants are mandatory: WS/client,
WS/function, RTC/client, RTC/function. Each uses a tool-generated unpredictable
challenge created ONLY after executor side effect, unavailable to startup
prompts/audio. Verify returned challenge-derived semantic spoken answer under
that request's identity and deadline, exact tool side effect + ordinary
input/run terminal, and post-result sustained media. RMS normalization uses
20ms windows: >=500ms aggregate active and >=200ms contiguous above calibrated
silence floor. Semantic answer, not exact punctuation/quoted string, matters.
Silence, click, greeting-only, unrelated speech, echoed request, pre-seeded/
fabricated challenge, wrong channel and dropped-error all fail oracle.
No model-output match can prove remote consumption in the product state machine.

No-delegation voice test: speak without backend task, close, cold reopen, read
authorized old channel, capture NEW provider startup projection and verify
authorized nonfinal voice history plus explicit omission metadata. Both storage
profiles and active ordinary actor commit order are mandatory.

## 11. Executable phase and gate requirements (R10/R11)

Phase 0 first creates minimal manifest FEATURES and named type/fixture/test
targets so verification commands actually resolve. Types/contracts compile
before behavior; explicit integration test targets run (not --lib only).
Black-box tests must be LAUNCHED and fail at named missing-behavior assertions;
--no-run is a compilation precheck, never Gate1 proof. Inspect nonzero inventory.
No implementation-gap ignore/XFAIL; `--ignored` only explicitly executes the
declared paid-provider lane.

Feature matrix has RUNNABLE positives, not only checks. Add separate
`tests/feature-fixtures/public-live-ws/Cargo.toml` and
`public-live-rtc/Cargo.toml`, each its own `[workspace]` so integration/facade
dev-dependencies cannot unify forbidden features. Depend on the candidate
Meerkat path with default-features=false and explicit
openai-live,live,session-store,sqlite-store; RTC adds live-webrtc only.
WS must resolve no facade mob/RTC/private feature; RTC no mob/private.
Inspect the resolved feature closure with the repository Cargo wrapper and
assert those negatives before running each fixture.

Each isolated fixture runs a real public profile open plus ordinary executor
effect through AgentFactory and SessionService, both modes across the two
fixtures. No live factory, provider runtime or LLM-client constructor override
may substitute for real wiring. A fixture-owned declared tool is normal host
tool injection and still passes the outer scoped gate. Selected test/run
inventory must be nonzero; source identity, effect and voice evidence use the
same actual-provider oracles as the four quadrants.

Shipping changes explicitly add `openai-live` to default features of BOTH
`meerkat-rpc/Cargo.toml` and `meerkat-cli/Cargo.toml` (package rkat), preserving
legacy features. Public provider feature in the library remains opt-in.
Build/run normal default-feature RPC binary with --live-ws and normal
`rkat mob host` with its existing listener, not a tests-only composition.
The placed CLI open uses that actual owning host; local one-shot CLI open is a
negative unavailable test. Assert runtime capability and binary identity,
not just Cargo closure. These actual binaries run ordinary executor work.
No new local CLI listener is added.

Legacy+private regression and complete `make wasm-check` remain separate rows;
WASM uses getrandom_backend=wasm_js and all-target checks with native public
transport absent. Compile-only checks supplement, never replace runnable rows.

Update canonical e2e taxonomy AND generator:
`scripts/generate-bazel-rust-builds.mjs` public test cohort, feature closure,
Rust test targets, native peer/browser helper runfiles and TurboS suite
membership. Generated `//:e2e_smoke_turbo_s` must contain all four public
quadrants. Prove via generated target query/dry-run/run inventory and execution,
not file existence. Preserve configured flaky_test_attempts=2 and every attempt.
Private S96 remains OAuth/private; missing credential is root blocker, not skip.

Gate commands and exact target names are in plan.yaml. Codegen, both locks,
all schema/SDK/wrapper/event/surface parity, formal/TLC/ownership/closure,
native feature/minimal/modularity, WASM/browser, docs and full candidate TurboS
remain mandatory. Main-only release workflow is not candidate evidence.

## 12. Review decisions and final acceptance

Root D1-D3 and D5/D6/D7 are incorporated with their conditions. D8 privacy and
LOCAL diagnostic/trusted-primary-fixture tradeoff is approved subject to
privacy/no-effect tests. D4 numerical limits are conditionally approved as
disclosed configurable LOCAL policy, now subject to completion-credit proof.
Independent canonical ledger/composite-read topology is accepted in principle;
the concrete scoped-effect, callback, quota, lock and lifecycle handoffs in V3
still require retained-reviewer PASS.

Review repair index: R1 sections3.1-3.2/F01-F02/F20; R2 section4.1-4.2/F03-F06;
R3 section4.3/F07-F09; R4 section5/F10-F15; R5 section7; R6 section5.1/F12;
R7 section6; R8 section8; R9 section9/F19; R10 section11/plan; R11 section10-11.
V3 consolidated groups: 1 section4.5/F21; 2 section4.6/F22; 3 section4.4/F23;
4 section9.1/F24; 5 section5.3/F25; 6 sections3.1/4.2/F26;
7 sections5.6-5.8/F27; 8 section8.1/F28; 9 sections1/11/F29.
No owner label is permission for shell interpretation; each proposed store
transaction, queue isolation, fence and retirement rule must exist in generated
production authority and its conformance tests.

Final requires all core paths and successful four real quadrants, honest
attempt evidence, independent final adversarial PASS, normal authored commits/
hooks, actual PR, exact-head successful CI and mergeability. Root alone
adjudicates documented external limitations; no waiver of missing behavior,
false oracle or failed mandatory successful-quadrant evidence. No Meerkat merge,
version bump or release authorized.
