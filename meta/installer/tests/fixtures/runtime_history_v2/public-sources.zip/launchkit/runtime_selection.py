"""An explicit host-selected candidate target, separate from a user's design.

The caller must already accept the producer's cryptographic provenance and the
exact locally built SDK tuple. This module checks those selected artifact bytes;
it neither performs that acceptance nor turns a digest into release authority.
The ordinary public release remains the compiler's default.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
import re

from .runtime_candidates import CandidateBinding, read_candidate_artifacts, recheck_candidate_artifacts


SELECTION_FORMAT = "forge-runtime-candidate-selection-v1"


@dataclass(frozen=True)
class RuntimeCandidateTarget:
    tuple_path: Path
    artifact_root: Path
    accepted: CandidateBinding


def parse_candidate_selection(value):
    """Parse a previously protected selection without admitting its artifacts.

    This is a pure historical identity check. A caller must obtain the document
    from its host-owned framework or checked update journal. Parsing a browser
    value, package claim or receipt alone does not establish that authority.
    Current admission additionally calls candidate_selection to recheck bytes.
    """
    if (type(value) is not dict or set(value) != {"format", "tuple_path", "artifact_root", "accepted"}
            or value.get("format") != SELECTION_FORMAT or type(value.get("accepted")) is not dict
            or set(value["accepted"]) != set(CandidateBinding.__dataclass_fields__)):
        raise ValueError("The protected candidate selection has an invalid shape.")
    binding = value["accepted"]
    if (binding["repository"] != "lukacf/meerkat-mobkit"
            or binding["native_version"] != "0.8.48" or binding["core_version"] != "0.8.51"
            or binding["platform"] not in {"aarch64-apple-darwin", "x86_64-apple-darwin",
                "aarch64-unknown-linux-gnu", "x86_64-unknown-linux-gnu"}
            or any(type(binding[key]) is not int or binding[key] < 1
                for key in ("native_run_id", "native_run_attempt"))
            or any(not isinstance(binding[key], str) or not re.fullmatch(pattern, binding[key])
                for key, pattern in (("source_sha", "[0-9a-f]{40}"),
                    ("tuple_sha256", "[0-9a-f]{64}"),
                    ("native_manifest_sha256", "[0-9a-f]{64}"),
                    ("sdk_wheel_sha256", "[0-9a-f]{64}")))):
        raise ValueError("The protected candidate identity is invalid.")
    paths = []
    for name in ("tuple_path", "artifact_root"):
        item = value[name]
        if not isinstance(item, str) or not item or len(item) > 4096 or "\x00" in item:
            raise ValueError("The protected candidate locator is invalid.")
        path = Path(item)
        if not path.is_absolute() or str(path) != item or ".." in path.parts:
            raise ValueError("The protected candidate locator must be canonical and absolute.")
        paths.append(path)
    return RuntimeCandidateTarget(paths[0], paths[1], CandidateBinding(**binding))


def candidate_selection(target, *, deployment_target=None, verified_artifacts=None):
    """Render a small protected binding after checking the selected bytes.

    Application source never contains the native archives or SDK wheel. The
    external bundle must remain available on this candidate deployment host.
    Returning this document is compilation, not update or runtime admission.
    """
    if not isinstance(target, RuntimeCandidateTarget):
        raise ValueError("A candidate target needs an explicit host-owned selection.")
    binding = target.accepted
    if (not isinstance(binding, CandidateBinding) or binding.native_version != "0.8.48"
            or binding.core_version != "0.8.51"):
        raise ValueError("The selected candidate must be the qualified .48/Core .51 tuple.")
    if deployment_target is not None:
        supported = {"mac": "apple-darwin", "linux": "unknown-linux-gnu"}
        if (deployment_target not in supported
                or not binding.platform.endswith("-" + supported[deployment_target])):
            raise ValueError("The selected candidate does not match this local deployment platform.")
    value = {"format": SELECTION_FORMAT, "tuple_path": str(target.tuple_path),
        "artifact_root": str(target.artifact_root), "accepted": asdict(binding)}
    parse_candidate_selection(value)
    if verified_artifacts is None:
        read_candidate_artifacts(target.tuple_path, accepted=binding, artifact_root=target.artifact_root)
    else:
        recheck_candidate_artifacts(verified_artifacts, tuple_path=target.tuple_path,
            accepted=binding, artifact_root=target.artifact_root)
    return value
