"""Bounded local installer and owned native runtime supervisor, with private logs."""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import sys
import uuid
from urllib.parse import urlparse

from .deployment import (journal, materialize, now, package_files, read_receipt,
                         parse_setting, update_receipt, verify_destination)
from .projects import DraftConflict
from .templates.storage_setup import project_lock
from .deployment_deadlines import APPLICATION_STOP_TIMEOUT, PROCESS_FORCE_REAP_TIMEOUT
from .deployment_ports import require_available_console_port, LocalConsolePortUnavailable
from .native_definition_continuity import valid_continuity_projection

INSTALL_TIMEOUT = 1200
CHECK_TIMEOUT = 180
START_TIMEOUT = 240
CONSOLE_START_TIMEOUT = 30
CONSOLE_START_RETRY_INTERVAL = 1
STOP_TIMEOUT = APPLICATION_STOP_TIMEOUT
MAX_LOG_BYTES = 64 * 1024
MAX_READY_BYTES = 2 * 1024 * 1024
NATIVE_DEFINITION_READ = (Path(__file__).with_name("native_definition_continuity.py").read_text() + "\n" + '''import json, sys
import app
original_connect = app.connect_application_runtime
async def observe_connect(config, application):
    runtime = await original_connect(config, application)
    # Pinned 0.8.42's typed capabilities projection drops newer fields. Read
    # the exact native result through its existing transport, as the host turn
    # carrier does; retain only the two typed booleans required here.
    capabilities = await runtime._rpc("mobkit/capabilities", {})
    support = capabilities.get("host_system_prompt", {}) if isinstance(capabilities, dict) else {}
    print(json.dumps({"mob_id": application.deployment["slug"],
        "source": "native runtime capabilities", "host_system_prompt": {
            "send": support.get("send") is True, "dispatch": support.get("dispatch") is True}}), flush=True)
    if application.deployment.get("mobkitVersion") in SUPPORTED_NATIVE_VERSIONS and not all(
            support.get(method) is True for method in ("send", "dispatch")):
        page = await runtime._rpc("mobkit/mob_events/query",
            continuity_query(application.deployment["slug"]))
        try:
            continuity = registry_role_continuity(page, application.deployment["slug"],
                native_version=application.deployment["mobkitVersion"])
        except ValueError:
            continuity = None
        if continuity is not None:
            verify_continuity_runtime(application.context.root, config.gateway_bin,
                native_version=application.deployment["mobkitVersion"])
        print(json.dumps({"mob_id": application.deployment["slug"],
            "source": "native role continuity observation", "continuity": continuity}), flush=True)
    return runtime
app.connect_application_runtime = observe_connect
sys.argv = ["app.py", "--definition-revision"]
app.main()
''')


def clean_environment():
    # Never inherit Forge provider credentials, Python module paths or proxies.
    allowed = {"PATH", "HOME", "USER", "LOGNAME", "LANG", "LC_ALL", "TMPDIR", "SHELL",
               "SSL_CERT_FILE", "SSL_CERT_DIR"}
    values = {key: value for key, value in os.environ.items() if key in allowed}
    values.update(PYTHONUNBUFFERED="1", PYTHONNOUSERSITE="1")
    return values


def read_settings(destination):
    values = {}
    path = destination / ".env"
    if path.is_symlink() or path.stat().st_size > 256 * 1024:
        raise ValueError("The private configuration path is unsafe or too large.")
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line or line.startswith("#"):
            continue
        key, separator, value = line.partition("=")
        if not separator or not re.fullmatch(r"[A-Z][A-Z0-9_]*", key):
            raise ValueError("Private configuration contains an invalid name.")
        value = parse_setting(value)
        if not isinstance(value, str) or len(value) > 32768 or "\x00" in value:
            raise ValueError("Private configuration values must be bounded UTF-8 strings.")
        values[key] = value
    return values


class Redactor:
    def __init__(self, values):
        variants = set()
        for value in values:
            if isinstance(value, str) and value:
                variants.add(value)
                variants.add(json.dumps(value, ensure_ascii=True)[1:-1])
                variants.update(value.splitlines())
        self.values = sorted(variants, key=len, reverse=True)

    def __call__(self, text):
        for value in self.values:
            text = text.replace(value, "[private]")
        text = re.sub(r"(?i)(bearer\s+)[^\s\"']+", r"\1[private]", text)
        text = re.sub(r"(?i)((?:token|secret|password|api[_-]?key)[\"']?\s*[:=]\s*[\"']?)[^\s\"',}]+", r"\1[private]", text)
        text = re.sub(r"\b(?:sk-|AIza)[A-Za-z0-9_-]{8,}", "[private]", text)
        return text


def readiness(payload, definition, expected_pid, port):
    if not isinstance(payload, dict) or payload.get("pid") != expected_pid:
        raise ValueError("The application did not provide owned startup evidence.")
    bootstrap = payload.get("bootstrap")
    expected = {item["identity"] for item in definition["agents"]}
    if (not isinstance(bootstrap, dict) or bootstrap.get("complete") is not True
            or bootstrap.get("ready") is not True or bootstrap.get("counts", {}).get("broken") != 0
            or not expected.issubset(bootstrap.get("identities", {}))):
        raise ValueError("The native agents did not finish bootstrap.")
    url = payload.get("console_url", "")
    parsed = urlparse(url)
    if parsed.scheme != "http" or parsed.hostname != "127.0.0.1" or parsed.port != port or parsed.path != "/console":
        raise ValueError("The native console does not match this deployment.")
    return bootstrap, url


def knowledge_container_owned(labels, destination):
    if not isinstance(labels, dict):
        return False
    root = destination / "knowledge"
    return (labels.get("com.docker.compose.project.working_dir") == str(root)
            and labels.get("com.docker.compose.project.config_files") == str(root / "compose.json"))


def console_health_headers(destination):
    """Use only the trusted host helper, never imported application code."""
    if not (Path(destination) / "application/console.json").exists():
        return {}
    try:
        from .templates_v2.console_auth import health_headers
        return health_headers(Path(destination))
    except (OSError, ValueError, ImportError):
        raise ValueError("The private Console health authorization could not be verified.") from None


class Supervisor:
    def __init__(self, directory):
        self.directory = Path(directory)
        self.receipt = read_receipt(directory)
        self.destination = Path(self.receipt["destination"])
        self.stop = asyncio.Event()
        self.child = None
        self.logs = []
        values = read_settings(self.destination)
        # Unknown existing settings are treated as private too.
        self.redact = Redactor(values.values())
        self.port = int(values["MOBKIT_PORT"])
        self.environment = clean_environment()
        # Runtime code reads its own .env. The environment contains no secrets.
        home = self.destination / ".mobkit/home"
        home.mkdir(mode=0o700, exist_ok=True)
        if home.is_symlink():
            raise ValueError("The deployment's private runtime home cannot be a link.")
        self.environment["HOME"] = str(home)

    def record_log(self, phase, line):
        text = self.redact(line)[:4000]
        if not text.strip():
            return
        self.logs.append({"at": now(), "phase": phase, "text": text})
        while self.logs and sum(len(item["text"].encode()) for item in self.logs) > MAX_LOG_BYTES:
            self.logs.pop(0)
        update_receipt(self.directory, logs=self.logs[-120:])

    async def output(self, pipe, phase, captured=None):
        buffer = b""
        discard = False
        while chunk := await pipe.read(4096):
            buffer += chunk
            while b"\n" in buffer:
                line, buffer = buffer.split(b"\n", 1)
                if not discard:
                    text = line.decode("utf-8", errors="replace")
                    self.record_log(phase, text)
                    if captured is not None:
                        captured.append(text)
                        if sum(len(item.encode()) for item in captured) > MAX_LOG_BYTES:
                            raise ValueError("The native definition observation exceeded its bounded host output.")
                discard = False
            if len(buffer) > MAX_LOG_BYTES:
                # Do not persist fragments that could split a secret value.
                buffer = b""
                discard = True
        if buffer and not discard:
            text = buffer.decode("utf-8", errors="replace")
            self.record_log(phase, text)
            if captured is not None:
                captured.append(text)

    async def terminate(self, timeout=None):
        timeout = STOP_TIMEOUT if timeout is None else timeout
        process = self.child
        if not process:
            return
        if process.returncode is None:
            # Let the application close adapters and native state first. Installer
            # commands can terminate their whole owned group immediately.
            try:
                if timeout <= 10:
                    os.killpg(process.pid, signal.SIGTERM)
                else:
                    process.terminate()
                await asyncio.wait_for(self.parent_exit(process), timeout)
            except ProcessLookupError:
                pass
            except asyncio.TimeoutError:
                pass
        # Parent exit does not prove its installers/native children have exited.
        # This process group was created by us, never reconstructed from a PID.
        try:
            os.killpg(process.pid, signal.SIGTERM)
            await asyncio.sleep(0.2)
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        try:
            await asyncio.wait_for(process.wait(), PROCESS_FORCE_REAP_TIMEOUT)
        except asyncio.TimeoutError:
            raise RuntimeError("The owned application process did not confirm exit after bounded force cleanup.") from None

    async def parent_exit(self, process):
        # asyncio Process.wait() can wait for inherited stdout held by a
        # grandchild after its parent exited. Observe the owned parent's result
        # first, then terminate descendants and drain pipes in cleanup.
        while process.returncode is None:
            await asyncio.sleep(0.05)
        return process.returncode

    async def command(self, args, phase, timeout, *, installer=False, capture_output=False):
        if self.stop.is_set():
            raise asyncio.CancelledError
        environment = self.environment
        if installer:
            # install.sh already supports this explicit, quoted interpreter path.
            # Select the running host interpreter, never an ambient or private setting.
            environment = {**environment, "PYTHON_BIN": str(Path(sys.executable).resolve(strict=True))}
        process = await asyncio.create_subprocess_exec(*args, cwd=self.destination, env=environment,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT, start_new_session=True)
        self.child = process
        captured = [] if capture_output else None
        output = asyncio.create_task(self.output(process.stdout, phase, captured))
        exited = asyncio.create_task(self.parent_exit(process))
        stopped = asyncio.create_task(self.stop.wait())
        try:
            done, _ = await asyncio.wait({exited, stopped}, timeout=timeout, return_when=asyncio.FIRST_COMPLETED)
            if stopped in done:
                raise asyncio.CancelledError
            if exited not in done:
                raise TimeoutError("The deployment step exceeded its time limit.")
            if process.returncode:
                raise RuntimeError(f"The {phase} step failed (exit {process.returncode}). Inspect the private, redacted logs.")
        finally:
            stopped.cancel()
            await self.terminate(timeout=10)
            await asyncio.gather(output, exited, stopped, return_exceptions=True)
            self.child = None
        if captured is not None:
            await output
            return "\n".join(captured)

    async def native_definition_revision(self, files, *, require_carrier=True, expected_revision=None):
        """Read one actual native epoch from this exact owned cold host."""
        if expected_revision is not None and (type(expected_revision) is not int or expected_revision < 1):
            raise RuntimeError("Native definition observation needs an exact positive revision.")
        definition = json.loads(files["deployment.json"][0])
        verify_destination(read_receipt(self.directory), files)
        binary = self.native_binary_provenance(files)
        text = await self.command([str(self.destination / ".venv/bin/python"), "-c", NATIVE_DEFINITION_READ],
                                  "Native definition revision", START_TIMEOUT, capture_output=True)
        verify_destination(read_receipt(self.directory), files)
        if self.native_binary_provenance(files) != binary:
            raise RuntimeError("The verified native binary changed during definition observation.")
        observations, capabilities, continuity = [], [], []
        for line in text.splitlines():
            try:
                value = json.loads(line)
            except ValueError:
                continue
            if (isinstance(value, dict) and value.get("mob_id") == definition["slug"]
                    and value.get("source") == "native structural event ledger"
                    and type(value.get("definition_revision")) is int
                    and value["definition_revision"] >= 1):
                observations.append(value["definition_revision"])
            if (isinstance(value, dict) and value.get("mob_id") == definition["slug"]
                    and value.get("source") == "native runtime capabilities"
                    and isinstance(value.get("host_system_prompt"), dict)):
                capabilities.append(value["host_system_prompt"])
            if (isinstance(value, dict) and value.get("mob_id") == definition["slug"]
                    and value.get("source") == "native role continuity observation"):
                continuity.append(value.get("continuity"))
        if len(observations) != 1 or len(capabilities) != 1:
            raise RuntimeError("The exact native host did not provide one unambiguous definition revision and capability observation. No revision was guessed.")
        if expected_revision is not None and observations[0] != expected_revision:
            raise RuntimeError("The observed native definition does not match the exact expected revision. Preserve the update and its original activation pin.")
        supported = {method: capabilities[0].get(method) is True for method in ("send", "dispatch")}
        unchanged_roles = (len(continuity) == 1
            and valid_continuity_projection(continuity[0], definition["slug"], observations[0])
            and binary.get("native_binary_version") == continuity[0].get("native_version")
            and (binary.get("native_binary_source") == "official-release" or
                 binary.get("native_binary_source") == "signed-candidate"
                 and isinstance(binary.get("candidate_binding"), dict)
                 and binary["candidate_binding"].get("native_version") == continuity[0].get("native_version")
                 and binary["candidate_binding"].get("core_version") == continuity[0].get("core_version")))
        if not all(supported.values()) and (require_carrier or expected_revision is None
                and observations[0] != 1 and not unchanged_roles):
            raise RuntimeError("The installed verified native gateway cannot author current role instructions on host send and keyed dispatch. Preserve the observed definition and transaction state.")
        return {"mob_id": definition["slug"], "definition_revision": observations[0],
                **({"native_role_continuity": continuity[0]} if unchanged_roles else {}),
                "host_system_prompt": supported, **binary,
                "package_sha256": read_receipt(self.directory)["package_sha256"], "observed_at": now()}

    def _candidate_runtime_target(self, files):
        """Read an already admitted target from owned source and its journal.

        An authored marker or native receipt cannot select a runtime. The
        private deployment owner must have published this full identity from
        the checked update, and the accepted framework must agree with it.
        """
        from .runtime_selection import parse_candidate_selection
        from .deployment_updates import _same_toml
        current = read_receipt(self.directory)
        definition = json.loads(files["deployment.json"][0])
        selected = current.get("runtime_candidate")
        if "runtimeCandidate" not in definition:
            if "runtime_candidate" in current:
                raise RuntimeError("The admitted candidate target differs from this owned deployment source.")
            return None
        if selected is None:
            raise RuntimeError("This candidate source has no previously admitted host runtime selection.")
        target = parse_candidate_selection(selected)
        selection = json.loads(files["runtime-candidate.json"][0])
        report = json.loads(files["implementation-report.json"][0])
        if (not _same_toml(selection, selected)
                or not _same_toml(report.get("framework", {}).get("runtime_candidate"), selected)
                or definition.get("mobkitVersion") != target.accepted.native_version
                or definition["runtimeCandidate"] != {"source": "signed-candidate",
                    "selection": "runtime-candidate.json", "tuple_sha256": target.accepted.tuple_sha256}):
            raise RuntimeError("The admitted candidate identity differs from its exact accepted package.")
        if any(read_settings(self.destination).get(name) for name in
                ("MOBKIT_RPC_GATEWAY_BIN", "MOBKIT_GATEWAY_BIN", "META_FORGE_RPC_GATEWAY_BIN")):
            raise RuntimeError("The selected candidate cannot use native gateway overrides.")
        return target

    def _verify_candidate_runtime(self, files):
        target = self._candidate_runtime_target(files)
        if target is None:
            return None
        from .runtime_dependencies import verify_runtime
        verify_destination(read_receipt(self.directory), files)
        proof = verify_runtime(self.destination, target.accepted.native_version, runtime_target=target)
        verify_destination(read_receipt(self.directory), files)
        if self._candidate_runtime_target(files) != target:
            raise RuntimeError("The admitted candidate selection changed during runtime verification.")
        return proof

    def native_binary_provenance(self, files):
        """Retain the existing installer's owned artifact receipt, not a version guess."""
        if self._candidate_runtime_target(files) is not None:
            proof = self._verify_candidate_runtime(files)
            return {"native_binary_sha256": proof["binaries"]["rpc_gateway"]["binary_sha256"],
                "native_binary_version": proof["version"], "native_binary_source": proof["source"],
                "candidate_binding": proof["candidate_binding"],
                "candidate_tuple_sha256": proof["candidate_tuple_sha256"]}
        binary, receipt = self.destination / ".bin/rpc_gateway", self.destination / ".bin/rpc_gateway.receipt.json"
        override = read_settings(self.destination).get("MOBKIT_RPC_GATEWAY_BIN")
        if override and Path(override).resolve() != binary.resolve():
            raise RuntimeError("Native definition observation cannot use a gateway outside this installation's verified artifact receipt.")
        for path, limit in ((binary, 512 * 1024 * 1024), (receipt, 1024 * 1024)):
            info = path.lstat()
            if (path.is_symlink() or any(parent.is_symlink() for parent in path.parents)
                    or not path.is_file() or info.st_uid != os.getuid() or info.st_nlink != 1
                    or info.st_mode & 0o077 or not 0 < info.st_size <= limit):
                raise RuntimeError("The native binary or its existing private artifact receipt is not owned and bounded.")
        record = json.loads(receipt.read_text())
        definition = json.loads(files["deployment.json"][0])
        if (not isinstance(record, dict) or record.get("version") != definition["mobkitVersion"]
                or record.get("source") not in {None, "explicit_override"}
                or not re.fullmatch("[0-9a-f]{64}", str(record.get("binary_sha256", "")))
                or not os.access(binary, os.X_OK)):
            raise RuntimeError("The native artifact receipt does not match this pinned deployment.")
        hashed = hashlib.sha256()
        with binary.open("rb") as stream:
            while chunk := stream.read(1024 * 1024):
                hashed.update(chunk)
        if hashed.hexdigest() != record["binary_sha256"]:
            raise RuntimeError("The native binary changed outside its existing artifact receipt.")
        return {"native_binary_sha256": record["binary_sha256"], "native_binary_version": record["version"],
                "native_binary_source": "explicit_override" if record.get("source") else "official-release"}

    async def install(self, definition):
        if "runtimeCandidate" in definition:
            raise RuntimeError("A private runtime candidate requires its checked stopped-installation update; a fresh installation is not admitted.")
        journal(self.directory, "Installing the pinned runtime and application dependencies.", status="installing", phase="install")
        from .deployment_cache import seed_release_cache
        cached = await asyncio.to_thread(seed_release_cache, self.destination, definition)
        if cached:
            self.record_log("install", "Copied the pinned official runtime from Forge's verified local release cache. The package installer verifies these bytes again before reuse.")
        await self.command(["/bin/bash", "install.sh", "--non-interactive"], "install", INSTALL_TIMEOUT, installer=True)
        checks = []
        if definition["knowledge"]["mode"] == "local":
            await self.knowledge_preflight()
            journal(self.directory, "Preparing the proposed local Elephant service and its private project credentials.",
                    status="installing", phase="knowledge")
            await self.command([str(self.destination / ".venv/bin/python"), "knowledge/manage.py", "setup"],
                               "Knowledge setup", CHECK_TIMEOUT)
            private = read_settings(self.destination)
            knowledge_env = self.destination / "knowledge/.env"
            for line in knowledge_env.read_text().splitlines():
                key, separator, value = line.partition("=")
                if separator:
                    private[key] = parse_setting(value)
            self.redact = Redactor(private.values())
            journal(self.directory, "Starting the local knowledge service and verifying authenticated access.",
                    status="checking", phase="knowledge")
            await self.command([str(self.destination / ".venv/bin/python"), "knowledge/manage.py", "up"],
                               "Knowledge service", INSTALL_TIMEOUT)
            checks.append({"name": "Local knowledge service", "status": "pass",
                           "detail": "The generated Elephant manager started the service and completed its authenticated MCP verification."})
            update_receipt(self.directory, checks=checks, knowledge_managed=True)
        for name, flag in [("Local prerequisites", "--doctor"), ("Application contract", "--application-check")]:
            journal(self.directory, f"Checking {name.lower()}.", status="checking", phase="check")
            try:
                await self.command([str(self.destination / ".venv/bin/python"), "app.py", flag], name, CHECK_TIMEOUT)
            except Exception:
                checks.append({"name": name, "status": "fail", "detail": "The installed host-owned check failed. Inspect its redacted output below."})
                update_receipt(self.directory, checks=checks)
                raise
            checks.append({"name": name, "status": "pass", "detail": "The installed host-owned check completed successfully."})
            update_receipt(self.directory, checks=checks)
        used = {grant["connection_id"] for item in definition["classes"] for grant in item["tools"]["mcp"]}
        if used or any(item["tools"].get("knowledge") for item in definition["classes"]):
            journal(self.directory, "Connecting selected MCPs and checking their actual tool grants.", status="checking", phase="connections")
            try:
                await self.command([str(self.destination / ".venv/bin/python"), "app.py", "--connections-check"], "MCP connections", CHECK_TIMEOUT)
            except Exception:
                checks.append({"name": "MCP connections", "status": "fail", "detail": "The actual MCP connection or advertised tool grant check failed."})
                update_receipt(self.directory, checks=checks)
                raise
            checks.append({"name": "MCP connections", "status": "pass", "detail": "The installed native host completed the configured MCP handshake and grant checks."})
            update_receipt(self.directory, checks=checks)

    async def query(self, args):
        """Bounded read-only host inspection; never publicize raw Docker metadata."""
        process = await asyncio.create_subprocess_exec(*args, cwd=self.destination, env=self.environment,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL, start_new_session=True)
        self.child = process
        try:
            async def capture():
                output = bytearray()
                while chunk := await process.stdout.read(4096):
                    output.extend(chunk)
                    if len(output) > MAX_LOG_BYTES:
                        raise ValueError("Local service inspection exceeded its result limit.")
                await self.parent_exit(process)
                if process.returncode:
                    raise ValueError("Could not inspect the local knowledge service. Check Docker access before retrying.")
                return output.decode("utf-8")
            return await asyncio.wait_for(capture(), 20)
        finally:
            await self.terminate(timeout=10)
            self.child = None

    async def knowledge_preflight(self):
        compose = json.loads((self.destination / "knowledge/compose.json").read_text())
        name = compose["name"]
        if not re.fullmatch(r"[a-z][a-z0-9-]{1,60}", name):
            raise ValueError("The local knowledge service has an invalid project name.")
        output = await self.query(["docker", "ps", "-a", "--filter", f"label=com.docker.compose.project={name}", "--format", "{{.ID}}"])
        identities = output.splitlines()
        for identity in identities:
            if not re.fullmatch(r"[a-f0-9]{12,64}", identity):
                raise ValueError("Docker returned an invalid local service identity.")
            labels = json.loads(await self.query(["docker", "inspect", "--format", "{{json .Config.Labels}}", identity]))
            if not knowledge_container_owned(labels, self.destination):
                raise ValueError("A local knowledge service with this name belongs to another folder. No container was changed. Choose a different project name or use its existing endpoint.")
        update_receipt(self.directory, knowledge_ownership={"project": name, "working_directory": str(self.destination / "knowledge"),
                                                           "existing_owned_containers": identities})

    async def startup_console(self, client, url, definition, process, exited, stopped):
        """Wait for actual authenticated identities without publishing readiness."""
        import httpx
        expected = {item["identity"] for item in definition["agents"]}
        deadline = asyncio.get_running_loop().time() + CONSOLE_START_TIMEOUT
        attempts = 0
        last_failure = {"category": "unavailable"}
        attempt_id = read_receipt(self.directory).get("startup_attempt_id")

        def diagnostic(status, failure=None):
            value = {"status": status, "attempts": attempts, "checked_at": now(), "attempt_id": attempt_id}
            if failure:
                value.update(failure)
            update_receipt(self.directory, startup_console_health=value)

        def fail():
            diagnostic("fail", last_failure)
            suffix = last_failure["category"]
            if "http_status" in last_failure:
                suffix += ", HTTP " + str(last_failure["http_status"])
            raise RuntimeError("Native startup reported readiness, but the actual Console identities health check failed ("
                               + suffix + ").")

        async def probe():
            try:
                headers = console_health_headers(self.destination)
            except ValueError:
                return {"category": "authorization_configuration"}
            try:
                response = await client.get(url.rsplit("/console", 1)[0] + "/console/identities", headers=headers)
                status = response.status_code
                if status != 200:
                    return {"category": "authentication" if status in (401, 403) else "http_status",
                            "http_status": status}
                payload = response.json()
                rows = payload["identities"]
                if not isinstance(rows, list) or any(not isinstance(item, dict) or not isinstance(item.get("identity"), str) for item in rows):
                    return {"category": "invalid_response"}
                identities = {item["identity"] for item in rows}
                return None if expected.issubset(identities) else {"category": "missing_identities"}
            except httpx.TimeoutException:
                return {"category": "timeout"}
            except httpx.TransportError:
                return {"category": "unavailable"}
            except (KeyError, TypeError, ValueError, UnicodeError):
                return {"category": "invalid_response"}
            except Exception:
                # Never retain exception text, response bodies or private headers.
                return {"category": "probe_error"}

        while True:
            if self.stop.is_set():
                diagnostic("interrupted")
                raise asyncio.CancelledError
            if process.returncode is not None:
                last_failure = {"category": "child_exited"}
                fail()
            remaining = deadline - asyncio.get_running_loop().time()
            if remaining <= 0:
                fail()
            attempts += 1
            request = asyncio.create_task(probe())
            try:
                done, _ = await asyncio.wait({request, exited, stopped}, timeout=remaining,
                                            return_when=asyncio.FIRST_COMPLETED)
                if stopped in done or self.stop.is_set():
                    diagnostic("interrupted")
                    raise asyncio.CancelledError
                if exited in done or process.returncode is not None:
                    last_failure = {"category": "child_exited"}
                    fail()
                if request not in done:
                    last_failure = {"category": "timeout"}
                    fail()
                failure = request.result()
            finally:
                if not request.done():
                    request.cancel()
                await asyncio.gather(request, return_exceptions=True)
            if failure is None:
                if asyncio.get_running_loop().time() >= deadline:
                    last_failure = {"category": "timeout"}
                    fail()
                diagnostic("pass")
                return
            last_failure = failure
            diagnostic("checking", failure)
            if failure["category"] in {"authentication", "authorization_configuration"}:
                fail()
            remaining = deadline - asyncio.get_running_loop().time()
            if remaining <= 0:
                fail()
            await asyncio.wait({exited, stopped}, timeout=min(CONSOLE_START_RETRY_INTERVAL, remaining),
                               return_when=asyncio.FIRST_COMPLETED)

    async def start(self, definition, *, on_ready=None):
        candidate_proof = None
        current = read_receipt(self.directory)
        if "runtimeCandidate" in definition or "runtime_candidate" in current:
            from .deployment_updates import checked_package
            current = read_receipt(self.directory)
            _, files = checked_package(self.directory, "package.zip", current["package_sha256"])
            if json.loads(files["deployment.json"][0]) != definition:
                raise RuntimeError("The candidate startup definition differs from its checked package.")
            candidate_proof = await asyncio.to_thread(self._verify_candidate_runtime, files)
        failure = None
        try:
            observation = require_available_console_port(self.port)
        except LocalConsolePortUnavailable as error:
            observation, failure = error.observation, error
        # An owned update can change package identity after construction.
        # Bind this actual prelaunch observation to the current source receipt.
        current = read_receipt(self.directory)
        attempt_id = str(uuid.uuid4())
        journal(self.directory, "Starting your application and bootstrapping its native agents.",
                status="starting", phase="start", startup_attempt_id=attempt_id, startup_console_health=None,
                startup_port_observation={**observation, "attempt_id": attempt_id,
                    "deployment_id": current["deployment_id"], "package_sha256": current["package_sha256"]},
                **({"startup_candidate_runtime_proof": candidate_proof} if candidate_proof is not None else {}),
                health="unknown", health_checked_at=None)
        if failure is not None:
            raise failure
        read_fd, write_fd = os.pipe()
        environment = {**self.environment, "MOBKIT_LAUNCH_READY_FD": str(write_fd)}
        process = None
        reader = asyncio.StreamReader(limit=MAX_READY_BYTES)
        protocol = asyncio.StreamReaderProtocol(reader)
        transport = None
        pipe = os.fdopen(read_fd, "rb", buffering=0)
        try:
            transport, _ = await asyncio.get_running_loop().connect_read_pipe(lambda: protocol, pipe)
            process = await asyncio.create_subprocess_exec(str(self.destination / ".venv/bin/python"), "app.py",
                cwd=self.destination, env=environment, stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT, pass_fds=(write_fd,), start_new_session=True)
            self.child = process
        except BaseException:
            if transport:
                transport.close()
            else:
                pipe.close()
            raise
        finally:
            os.close(write_fd)
        if process is None:
            if transport:
                transport.close()
            else:
                pipe.close()
            return
        output = asyncio.create_task(self.output(process.stdout, "runtime"))
        started = asyncio.create_task(reader.readline())
        exited = asyncio.create_task(self.parent_exit(process))
        stopped = asyncio.create_task(self.stop.wait())
        try:
            done, _ = await asyncio.wait({started, exited, stopped}, timeout=START_TIMEOUT, return_when=asyncio.FIRST_COMPLETED)
            if stopped in done:
                raise asyncio.CancelledError
            if exited in done:
                raise RuntimeError(f"The application stopped before startup verification (exit {process.returncode}).")
            if started not in done:
                raise TimeoutError("The application did not finish native startup verification in time. Rebuild a package with the current host if it lacks Forge readiness reporting.")
            startup = started.result()
            if not startup:
                raise RuntimeError("The application closed its startup verification channel before reporting readiness. Inspect the runtime logs for the native startup failure.")
            try:
                payload = json.loads(startup)
            except (ValueError, UnicodeError):
                raise ValueError("The application returned invalid startup evidence. Inspect the runtime logs and rebuild the checked package.") from None
            bootstrap, url = readiness(payload, definition, process.pid, self.port)
            journal(self.directory, "Native agents finished bootstrap. Checking the actual Console before publishing readiness.",
                    status="starting", phase="start", bootstrap=bootstrap, console_url=None, runtime_pid=process.pid,
                    process_live=True, health="unknown", health_checked_at=now())
            import httpx
            async with httpx.AsyncClient(timeout=3, trust_env=False) as client:
                await self.startup_console(client, url, definition, process, exited, stopped)
                if self.stop.is_set() or process.returncode is not None:
                    raise asyncio.CancelledError
                if on_ready:
                    on_ready()
                journal(self.directory, "Your application passed native bootstrap and actual Console health.",
                        status="running", phase="run", bootstrap=bootstrap, console_url=url,
                        runtime_pid=process.pid, process_live=True, health="ready", health_checked_at=now())
                while not self.stop.is_set() and process.returncode is None:
                    done, _ = await asyncio.wait({exited, stopped}, timeout=3, return_when=asyncio.FIRST_COMPLETED)
                    if done:
                        break
                    try:
                        response = await client.get(url.rsplit("/console", 1)[0] + "/console/identities",
                                                    headers=console_health_headers(self.destination))
                        response.raise_for_status()
                        identities = {item["identity"] for item in response.json()["identities"]}
                        expected = {item["identity"] for item in definition["agents"]}
                        healthy = expected.issubset(identities)
                    except Exception:
                        healthy = False
                    update_receipt(self.directory, process_live=process.returncode is None,
                        health="ready" if healthy else "unavailable", health_checked_at=now(),
                        console_url=url if healthy else None)
            if not self.stop.is_set():
                raise RuntimeError(f"The application exited (exit {process.returncode}). Files and native state are preserved.")
        finally:
            started.cancel()
            stopped.cancel()
            if transport:
                transport.close()
            await self.terminate()
            await asyncio.gather(output, started, exited, stopped, return_exceptions=True)
            self.child = None


async def update_runtime(supervisor, mode, *, update_id=None):
    """One source transaction, one verified startup, and at most one safe fallback."""
    from . import deployment_updates as updates
    directory = supervisor.directory
    receipt, root, update = updates.transaction(directory, update_id or read_receipt(directory)["update"]["update_id"])
    identity = update["update_id"]
    activated = False
    ready = False
    rollback = mode == "rollback"
    recover_current = mode == "recover-current"
    native_update = update.get("native_definition_update") is True
    host_instruction_update = update.get("host_instruction_update") is True
    dependency_update = update.get("runtime_dependency_update")
    verification_kwargs = {}
    if dependency_update and dependency_update.get("runtime_candidate") is not None:
        from .runtime_selection import parse_candidate_selection
        verification_kwargs["runtime_target"] = parse_candidate_selection(dependency_update["runtime_candidate"])
    registry_update = bool(dependency_update and dependency_update.get("native_registry_update") is True)
    # A source-copy interruption before native startup can restore its snapshot.
    # Once admission is possible, canonical native/domain receipts never rewind.
    restore_data = rollback and update.get("runtime_admission_possible") is False and (
        update.get("rollback_kind") == "failed-update" or update["status"] in {"applying", "verifying", "recovery-needed"})

    def publish(restored):
        nonlocal ready
        current = read_receipt(directory)
        _, _, bound = updates.transaction(directory, identity)
        expected_hash = bound["previous_package_sha256"] if restored else bound["package_sha256"]
        expected_build = bound["from_build_id"] if restored else bound["to_build_id"]
        if current["package_sha256"] != expected_hash or current["build_id"] != expected_build:
            raise DraftConflict("The started source no longer matches the admitted update transaction.")
        _, source = updates.checked_package(directory, "package.zip", current["package_sha256"])
        verify_destination(current, source)
        updates.committed(directory, identity, restored=restored)
        ready = True

    async def observe_native_revision():
        current_receipt = read_receipt(directory)
        _, current_files = updates.checked_package(directory, "package.zip", current_receipt["package_sha256"])
        _, current_root, current = updates.transaction(directory, identity)
        updates._require_runtime_framework_configuration(current_receipt, current)
        # A cold native connection can restore due work. Do not rewind native
        # or application receipts after even this read becomes possible.
        updates.checkpoint(directory, current_root, current, runtime_admission_possible=True,
            detail="Observing this exact owned native definition and runtime capability before any configuration replacement.")
        # Ordinary instruction updates retain the strict carrier contract.
        # A host-only refresh or model-only crossing may observe the legacy
        # initial epoch without that capability, enforced by the reader.
        observation = (await supervisor.native_definition_revision(current_files)
            if native_update and not registry_update else
            await supervisor.native_definition_revision(current_files, require_carrier=False))
        _, current_root, current = updates.transaction(directory, identity)
        updates.checkpoint(directory, current_root, current, native_definition_observation=observation)
        return observation

    async def checked_start(files, restored, observation=None):
        definition = json.loads(files["deployment.json"][0])
        journal(directory, "Checking the installed application's current private configuration and source contract.",
                status="checking", phase="recovery" if recover_current else "update",
                startup_attempt_id=None, startup_console_health=None, health="unknown", health_checked_at=None)
        verify_destination(read_receipt(directory), files)
        _, root, current = updates.transaction(directory, identity)
        # Application-check loads ordinary authored callbacks. Native startup
        # then restores schedules before readiness. Neither domain nor native
        # receipts may rewind once application execution is possible.
        updates.checkpoint(directory, root, current, runtime_admission_possible=True,
                           detail="Loading verified application source. Any native or application activity recorded from this point will be retained during source recovery.")
        # Authored contract checking can write local state. Exclude another
        # native host while checking; the runtime acquires the same lease itself.
        with project_lock(supervisor.destination):
            if dependency_update and not restored:
                updates._require_runtime_framework_configuration(read_receipt(directory), current)
                from .runtime_dependencies import retain_runtime, verify_runtime
                from .templates.storage_setup import upgrade_storage
                if any(read_settings(supervisor.destination).get(key) for key in (
                        "MOBKIT_RPC_GATEWAY_BIN", "MOBKIT_GATEWAY_BIN")):
                    raise RuntimeError("This qualified dependency update cannot use an external native gateway override. Preserve current settings and runtime files.")
                # install.sh ends with an authored application check. Retain
                # old runtime bytes first, then execute only the accepted new
                # pair. No old-runtime fallback is qualified after this point.
                retained = (await asyncio.to_thread(retain_runtime, supervisor.destination, root,
                    expected_version=dependency_update["from_version"]) if dependency_update["from_version"] != "0.8.42"
                    else await asyncio.to_thread(retain_runtime, supervisor.destination, root))
                _, root, current = updates.transaction(directory, identity)
                updates.checkpoint(directory, root, current, runtime_files_retained=retained,
                    rollback_available=False,
                    detail="Previous runtime files are retained. Installing the accepted runtime while preserving private settings and all current work.")
                await supervisor.command(["/bin/bash", "install.sh", "--non-interactive"],
                    "Runtime dependency installation", INSTALL_TIMEOUT, installer=True)
                verify_destination(read_receipt(directory), files)
                proof = await asyncio.to_thread(verify_runtime, supervisor.destination,
                    dependency_update["to_version"], **verification_kwargs)
                if verification_kwargs:
                    sdk = proof["sdk"]
                else:
                    text = await supervisor.command([str(supervisor.destination / ".venv/bin/python"), "-c",
                        "import importlib.metadata,json; print(json.dumps({'package':'meerkat-mobkit','version':importlib.metadata.version('meerkat-mobkit')}))"],
                        "Installed SDK version", CHECK_TIMEOUT, capture_output=True)
                    try:
                        sdk = json.loads(text)
                    except (ValueError, TypeError):
                        raise RuntimeError("The installed SDK did not provide one unambiguous package version.") from None
                    if sdk != {"package": "meerkat-mobkit", "version": dependency_update["to_version"]}:
                        raise RuntimeError("The installed SDK does not match the accepted native runtime. No storage upgrade or startup was attempted.")
                _, root, current = updates.transaction(directory, identity)
                updates.checkpoint(directory, root, current, runtime_artifacts={"sdk": sdk, "native": proof},
                    detail=("Installed exact SDK payload, metadata and both candidate native receipts match the accepted host selection. Native storage confirmation remains required."
                        if verification_kwargs else "Installed SDK version and both official native artifact receipts match the accepted tuple. Native storage confirmation remains required."))
                marker = json.loads((supervisor.destination / ".mobkit/launch-storage.json").read_text())
                if isinstance(marker, dict) and marker.get("version") == dependency_update["from_version"]:
                    storage = await asyncio.to_thread(upgrade_storage, supervisor.destination,
                        dependency_update["from_version"], dependency_update["to_version"])
                    _, root, current = updates.transaction(directory, identity)
                    updates.checkpoint(directory, root, current, runtime_storage_upgrade=storage)
                elif not updates._same_toml(marker, {"format": 1, "project": definition["slug"],
                                "version": dependency_update["to_version"], "phase": "ready"}):
                    raise RuntimeError("The retained storage marker does not match this exact runtime transition. Preserve its native reports and recover the accepted runtime.")
                # A ready new marker can survive an interruption before the
                # checkpoint above. Ordinary startup re-inspects native truth;
                # it does not repeat an already completed native apply.
            for name, flag in [("Update prerequisites", "--doctor"), ("Updated application contract", "--application-check")]:
                verify_destination(read_receipt(directory), files)
                await supervisor.command([str(supervisor.destination / ".venv/bin/python"), "app.py", flag], name, CHECK_TIMEOUT)
        if supervisor.stop.is_set():
            raise asyncio.CancelledError
        verify_destination(read_receipt(directory), files)
        if dependency_update and not restored:
            if any(read_settings(supervisor.destination).get(key) for key in (
                    "MOBKIT_RPC_GATEWAY_BIN", "MOBKIT_GATEWAY_BIN")):
                raise RuntimeError("The selected native gateway changed during the qualified dependency update. Preserve state and recover the accepted runtime.")
            if await asyncio.to_thread(verify_runtime, supervisor.destination,
                    dependency_update["to_version"], **verification_kwargs) != proof:
                raise RuntimeError("The verified native runtime changed before startup. No runtime was started.")
        if native_update:
            expected_revision = observation.get("definition_revision") if isinstance(observation, dict) else None
            if type(expected_revision) is not int:
                raise RuntimeError("Native definition activation needs the actual revision observed for this exact attempt.")
            _, root, current = updates.transaction(directory, identity)
            source_hash = read_receipt(directory)["package_sha256"]
            if observation.get("package_sha256") == source_hash and not observation.get("activation_replay"):
                # Ordinary connection verified this exact declared config
                # against native truth. Redeclaring it at its current epoch
                # would correctly fail native AlreadyMatching semantics.
                updates.checkpoint(directory, root, current, native_definition_recovery_observation=observation,
                    detail="The exact installed configuration already matches the observed canonical native definition. No duplicate activation was requested.")
            else:
                updates.checkpoint(directory, root, current, native_activation_expected_revision=expected_revision,
                    native_activation_package_sha256=source_hash, native_activation_observation=observation,
                    detail=("Removing the exact legacy duplicate model declaration through the accepted native revision update. Models, identities and continuing histories are preserved."
                        if registry_update else "Activating the accepted native instruction and flow-message configuration against its actually observed revision. Continuing histories are preserved."))
                updates._require_runtime_framework_configuration(read_receipt(directory), current)
                await supervisor.command([str(supervisor.destination / ".venv/bin/python"), "app.py",
                                          "--activate-revision", str(expected_revision)],
                                         "Native definition activation", START_TIMEOUT)
                verify_destination(read_receipt(directory), files)
                # This exact registry-only successor keeps every profile
                # instruction unchanged. Bind its observed epoch without
                # requiring the separate host instruction update carrier.
                updates._require_runtime_framework_configuration(read_receipt(directory), current)
                observed = (await supervisor.native_definition_revision(files,
                    require_carrier=False, expected_revision=expected_revision + 1)
                    if registry_update else await supervisor.native_definition_revision(files))
                if observed["definition_revision"] <= expected_revision:
                    raise RuntimeError("Native definition activation did not produce an observed later revision. No adoption was inferred from source files.")
                if registry_update and observed["definition_revision"] != expected_revision + 1:
                    raise RuntimeError("The model registry activation did not converge its exact successor revision. Preserve history and recover the accepted runtime.")
                _, root, current = updates.transaction(directory, identity)
                updates.checkpoint(directory, root, current, native_definition_activation={**observed,
                    "expected_revision": expected_revision, "restored_source": restored,
                    "instruction_adoption": ("Only the exact legacy duplicate model metadata was removed. Selected models and all profile instructions remain unchanged."
                        if registry_update else "Only subsequent new ordinary host send or keyed dispatch authors the current role into its existing session. Same-key retries replay their original admission. Native bootstrap alone is not role adoption.")})
            if restored and not updates.has_host_instruction_carrier(files):
                raise RuntimeError("Previous source and canonical configuration were restored as a new observed native revision, but its legacy host cannot restore continuing role instructions. Existing sessions and all current private records are preserved; recover the current accepted application rather than claiming role rollback.")
        updates._require_runtime_framework_configuration(read_receipt(directory), current)
        await supervisor.start(definition, on_ready=lambda: publish(restored))

    try:
        # Let the owned stdin/signal task observe cancellation before any copy.
        await asyncio.sleep(0)
        if supervisor.stop.is_set():
            raise asyncio.CancelledError
        if before_change := getattr(supervisor, "before_source_change", None):
            await before_change()
        if dependency_update and rollback:
            raise DraftConflict("This runtime dependency crossing supports recovery with the current accepted runtime. Previous runtime files are retained; a downgrade is not qualified.")
        if native_update and rollback and update.get("runtime_admission_possible") is not False:
            _, previous_files = updates.checked_package(root, "previous.zip", update["previous_package_sha256"])
            if not updates.has_host_instruction_carrier(previous_files):
                raise DraftConflict("This previous application's legacy host cannot restore continuing role instructions after native admission. Keep current state and recover the current accepted application; no rollback source or canonical definition was changed.")
        observation = None
        if registry_update and recover_current:
            # The original observation came from the verified predecessor
            # before replacing its runtime. Keep its exact epoch for CAS
            # replay after a storage crossing; a new ordinary connection
            # cannot observe an as-yet unpinned candidate configuration.
            # The current pair is independently reverified in checked_start.
            previous_observation = update.get("native_definition_observation")
            if (not isinstance(previous_observation, dict)
                    or previous_observation.get("package_sha256") != update["previous_package_sha256"]
                    or previous_observation.get("native_binary_version") != dependency_update["from_version"]
                    or type(previous_observation.get("definition_revision")) is not int
                    or previous_observation["definition_revision"] < 1
                    or not re.fullmatch("[0-9a-f]{64}", str(previous_observation.get("native_binary_sha256", "")))):
                raise RuntimeError("The runtime registry update has no bound predecessor native revision. Preserve its source and history; no epoch was guessed.")
            _, previous_files = updates.checked_package(root, "previous.zip", update["previous_package_sha256"])
            if previous_observation.get("mob_id") != json.loads(previous_files["deployment.json"][0])["slug"]:
                raise RuntimeError("The retained native revision belongs to another application. No activation was requested.")
            original_pin = update.get("native_activation_expected_revision")
            if original_pin is not None and (type(original_pin) is not int
                    or original_pin != previous_observation["definition_revision"]
                    or update.get("native_activation_package_sha256") != update["package_sha256"]
                    or not updates._same_toml(update.get("native_activation_observation"), previous_observation)):
                raise RuntimeError("The registry activation pin changed after its original observation. Preserve the accepted update.")
            observation = {**previous_observation, "activation_replay": original_pin is not None}
        elif native_update and recover_current:
            # An interrupted activation may have advanced native truth or may
            # have lost its response before admission. The exact original CAS
            # pin converges both cases; a candidate-only ordinary connection
            # cannot observe the latter because its config is still unpinned.
            previous_observation = update.get("native_activation_observation")
            carrier = previous_observation.get("host_system_prompt") if isinstance(previous_observation, dict) else None
            if (receipt["package_sha256"] in {update["package_sha256"], update["previous_package_sha256"]}
                    and update.get("native_activation_package_sha256") == receipt["package_sha256"]
                    and isinstance(previous_observation, dict)
                    and type(update.get("native_activation_expected_revision")) is int
                    and previous_observation.get("definition_revision") == update["native_activation_expected_revision"]
                    and isinstance(carrier, dict) and all(carrier.get(method) is True for method in ("send", "dispatch"))):
                _, current_files = updates.checked_package(directory, "package.zip", receipt["package_sha256"])
                verify_destination(receipt, current_files)
                artifact = supervisor.native_binary_provenance(current_files)
                if any(previous_observation.get(key) != value for key, value in artifact.items()):
                    raise RuntimeError("The owned native runtime changed after this exact activation attempt. Re-observe its canonical configuration before recovery.")
                if receipt["package_sha256"] == update["package_sha256"]:
                    observation = {**previous_observation, "activation_replay": True}
                else:
                    # A fallback CAS may also lose its response after copying
                    # previous source. Converge that exact recorded attempt
                    # before its ordinary connection can read native truth.
                    # Do not start or claim role adoption by the legacy host.
                    await supervisor.command([str(supervisor.destination / ".venv/bin/python"), "app.py",
                                              "--activate-revision", str(update["native_activation_expected_revision"])],
                                             "Interrupted fallback definition activation", START_TIMEOUT)
                    verify_destination(read_receipt(directory), current_files)
                    observation = await supervisor.native_definition_revision(current_files)
                    if observation["definition_revision"] <= update["native_activation_expected_revision"]:
                        raise RuntimeError("Interrupted fallback activation did not produce an observed later native revision.")
                    _, root, current = updates.transaction(directory, identity)
                    updates.checkpoint(directory, root, current, native_definition_observation=observation,
                        native_definition_activation={**observation, "expected_revision": update["native_activation_expected_revision"],
                            "restored_source": True, "instruction_adoption": "Only canonical fallback configuration converged. No previous application was started and no continuing role restoration is claimed."},
                        detail="Converged the exact interrupted fallback canonical activation. Retained all current history; proceeding forward to the accepted application using the newly observed native revision.")
        if observation is None and (not dependency_update or registry_update) and (native_update or host_instruction_update):
            observation = await observe_native_revision()
        if native_update and not observation.get("activation_replay"):
            _, root, current = updates.transaction(directory, identity)
            updates.checkpoint(directory, root, current,
                native_activation_expected_revision=observation["definition_revision"],
                native_activation_package_sha256=(current["previous_package_sha256"] if rollback else current["package_sha256"]),
                native_activation_observation=observation,
                detail="Bound the exact target configuration to its observed native revision before source replacement. This original CAS pin remains usable after an interrupted source check or activation response loss.")
        files = (updates.retry_candidate(directory, identity) if recover_current else
                 updates.restore(directory, identity, restore_data=restore_data) if rollback else updates.activate(directory, identity))
        activated = True
        await checked_start(files, rollback, observation)
    except BaseException as error:
        _, root, current = updates.transaction(directory, identity)
        if (dependency_update and not ready and current.get("runtime_admission_possible") is not False
                and (activated or current["status"] in {"verifying", "recovering-current", "recovery-needed"})):
            detail = supervisor.redact(str(error))[:1500] if isinstance(error, (ValueError, RuntimeError, TimeoutError)) else type(error).__name__
            updates.checkpoint(directory, root, current, status="recovery-needed", rollback_available=False,
                recovery_error=detail,
                detail="The runtime upgrade has not passed storage confirmation and live native Console health. Current source, private settings, admitted work and previous runtime files are retained. Recover this exact accepted runtime; no downgrade or automatic request resend was performed.")
            raise
        if not ready and (activated or current["status"] in {
                "applying", "verifying", "restoring", "recovering-current"}):
            if before_restore := getattr(supervisor, "before_source_restore", None):
                try:
                    await before_restore()
                except BaseException as cleanup_error:
                    _, root, current = updates.transaction(directory, identity)
                    cleaned = read_receipt(directory).get("service_cleanup_confirmed") is True
                    updates.checkpoint(directory, root, current, status="recovery-needed", rollback_available=True,
                        detail=("The owned service confirmed cleanup, but source recovery prerequisites or failed-attempt diagnostic preservation could not be verified."
                                if cleaned else "The owned service has not confirmed cleanup.")
                               + " Installed source and all current native and application records are preserved; no fallback source was copied.")
                    reason = "source recovery prerequisites or failed-attempt diagnostic preservation could not be verified" if cleaned else "background service cleanup is unconfirmed"
                    raise RuntimeError("The update needs recovery because " + reason + ". No source fallback was performed.") from cleanup_error
                _, root, current = updates.transaction(directory, identity)
        if recover_current:
            if not ready and (activated or current["status"] == "recovering-current"):
                detail = supervisor.redact(str(error))[:1500] if isinstance(error, (ValueError, RuntimeError, TimeoutError)) else type(error).__name__
                updates.checkpoint(directory, root, current, status="recovery-needed", rollback_available=True,
                    recovery_error=detail,
                    detail="The current application recovery has not passed native bootstrap and live Console health. Latest native and application records, including any recovery activity, are retained; retry this exact candidate or restore the previous source.")
            # An explicit forward recovery never switches to another source or
            # rewinds state after a failed check/start or owner interruption.
            raise
        # A late runtime failure after verified publication is an operational
        # failure, not permission to rewind work that may have used live tools.
        if ready or not (activated or current["status"] in {"applying", "verifying", "restoring"}):
            raise
        cancelled = isinstance(error, asyncio.CancelledError) or supervisor.stop.is_set()
        detail = supervisor.redact(str(error))[:1500] if isinstance(error, (ValueError, RuntimeError, TimeoutError)) else type(error).__name__
        recovery_start_possible = False
        try:
            # Observe before restoring source. Copying a previous TOML file is
            # never a rollback of the canonical native definition. If the
            # current source cannot observe an uncertain activation, retain it
            # and require explicit recovery rather than guessing an epoch.
            recovery_observation = await observe_native_revision() if native_update else None
            if rollback and current.get("rollback_kind") == "manual":
                files = updates.recover_candidate(directory, identity)
                restored = False
            else:
                files = updates.restore(directory, identity, restore_data=current.get("runtime_admission_possible") is False,
                                        rollback_kind="failed-update")
                restored = True
            _, root, current = updates.transaction(directory, identity)
            updates.checkpoint(directory, root, current, activation_error=detail)
            if cancelled:
                updates.checkpoint(directory, root, current, status="restored-stopped" if restored else "candidate-restored-stopped",
                    rollback_available=not restored,
                    detail="Verified source was restored after interruption. Current native and application state is retained. No restart or native health check has completed.",
                    activation_error=detail)
                raise asyncio.CancelledError
            journal(directory, "The requested source did not pass startup. Restored verified bytes; checking their actual runtime before claiming recovery.",
                    status="checking", phase="recovery")
            recovery_start_possible = True
            await checked_start(files, restored, recovery_observation)
        except asyncio.CancelledError:
            if recovery_start_possible and (before_restore := getattr(supervisor, "before_source_restore", None)):
                # A cancellation can arrive during the second service start,
                # after the first attempted instance was already cleaned up.
                await before_restore()
            raise
        except Exception as recovery_error:
            if recovery_start_possible and (before_restore := getattr(supervisor, "before_source_restore", None)):
                try:
                    await before_restore()
                except BaseException as cleanup_error:
                    recovery_error = cleanup_error
            _, root, current = updates.transaction(directory, identity)
            updates.checkpoint(directory, root, current, status="recovery-needed", rollback_available=True,
                activation_error=detail,
                detail="The update did not pass startup and recovery has not passed native health. Current native and application state, previous packages and private backups are retained; stop and recover this exact transaction.")
            raise RuntimeError("The source update needs recovery. Its owned package and private state snapshots are preserved; no running-system recovery is claimed.") from recovery_error


async def owner_input(supervisor):
    reader = asyncio.StreamReader()
    await asyncio.get_running_loop().connect_read_pipe(lambda: asyncio.StreamReaderProtocol(reader), sys.stdin.buffer)
    while True:
        line = await reader.readline()
        if not line:
            supervisor.stop.set()
            return "owner_lost"
        try:
            if json.loads(line).get("action") == "stop":
                supervisor.stop.set()
                return "stopped"
        except (ValueError, AttributeError):
            continue


async def run(directory, mode):
    if mode not in {"install", "start", "service", "update", "rollback", "recover-current"}:
        raise ValueError("Unknown deployment worker mode.")
    if mode == "install":
        from .deployment_updates import checked_package
        receipt = read_receipt(directory)
        _, checked = checked_package(directory, "package.zip", receipt["package_sha256"])
        if "runtimeCandidate" in json.loads(checked["deployment.json"][0]):
            raise RuntimeError("A private runtime candidate requires its checked stopped-installation update; a fresh installation is not admitted.")
    if mode == "service":
        from .deployment_service import UserServiceManager, verify_service
        receipt = read_receipt(directory)
        service = verify_service(directory, receipt)
        observation = await UserServiceManager().observe(service)
        if observation.get("pid") != os.getpid():
            raise ValueError("Only the recorded operating-system service may own this background runtime.")
        update_receipt(directory, service_supervisor_pid=os.getpid(), service_instance_id=str(uuid.uuid4()),
                       service_cleanup_confirmed=False, service_observation={**observation, "owned": True},
                       status="starting", phase="service", runtime_pid=None, console_url=None, bootstrap=None,
                       startup_attempt_id=None, startup_console_health=None, health="unknown", health_checked_at=None)
    try:
        supervisor = Supervisor(directory)
    except Exception:
        if mode == "service":
            journal(directory, "The service could not read its private installed configuration. No native runtime was started.",
                    status="failed", service_cleanup_confirmed=True, runtime_pid=None, console_url=None,
                    process_live=False, health="failed", health_checked_at=now())
        raise
    owner = asyncio.create_task(supervisor.stop.wait() if mode == "service" else owner_input(supervisor))
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, supervisor.stop.set)
    try:
        if mode in {"update", "rollback", "recover-current"}:
            admission = read_receipt(directory).get("update_action") or {}
            if admission.get("action") != ("apply-update" if mode == "update" else mode) or not admission.get("update_id"):
                raise ValueError("An exact user-admitted update action is required before changing source.")
            await update_runtime(supervisor, mode, update_id=admission["update_id"])
        else:
            payload = (Path(directory) / "package.zip").read_bytes()
            if hashlib.sha256(payload).hexdigest() != supervisor.receipt["package_sha256"]:
                raise ValueError("The saved checked package changed. No installed source was executed.")
            files = materialize(directory) if mode == "install" else package_files(payload)
            verify_destination(read_receipt(directory), files)
            definition = json.loads(files["deployment.json"][0])
            if mode == "install":
                await supervisor.install(definition)
            if supervisor.receipt.get("execution_mode") == "background" and mode != "service":
                if supervisor.stop.is_set():
                    raise asyncio.CancelledError
                from .deployment_service import UserServiceManager, prepare_service
                manager = UserServiceManager()
                if not (await manager.capability())["available"]:
                    raise RuntimeError("The logged-in user's service manager is unavailable. No background service was installed.")
                service = prepare_service(directory, read_receipt(directory))
                journal(directory, "Starting this checked application as an owned operating-system background service.",
                        status="starting", phase="service", service_cleanup_confirmed=False)
                await manager.start(service)
                journal(directory, "The operating-system service was admitted. Waiting for its native startup evidence.")
                return 0
            if not supervisor.stop.is_set():
                interrupted_update = read_receipt(directory).get("update") or {}
                callback = None
                if interrupted_update.get("status") in {"restored-stopped", "candidate-restored-stopped"}:
                    from .deployment_updates import committed
                    callback = lambda: committed(directory, interrupted_update["update_id"],
                        restored=interrupted_update["status"] == "restored-stopped")
                await supervisor.start(definition, on_ready=callback)
        reason = owner.result() if owner.done() and mode != "service" else "stopped"
        journal(directory, "Forge stopped; installed files and native state are preserved." if reason == "owner_lost"
                else "Your application is stopped. Installed files and native state are preserved.",
                status="interrupted" if reason == "owner_lost" else "stopped", phase="stop",
                runtime_pid=None, console_url=None, process_live=False)
    except asyncio.CancelledError:
        reason = owner.result() if owner.done() and mode != "service" else "stopped"
        journal(directory, "The deployment was interrupted. Installed files and native state are preserved.",
                status="interrupted" if reason == "owner_lost" else "stopped", runtime_pid=None,
                console_url=None, process_live=False)
    except Exception as error:
        message = str(error) if isinstance(error, (ValueError, RuntimeError, TimeoutError)) else f"Deployment failed ({type(error).__name__}). Inspect the redacted logs and retry."
        journal(directory, supervisor.redact(message), status="failed", runtime_pid=None, console_url=None,
                process_live=False, health="failed", health_checked_at=now())
        return 1
    finally:
        supervisor.stop.set()
        await supervisor.terminate()
        if mode == "service":
            update_receipt(directory, service_cleanup_confirmed=True)
        owner.cancel()
        await asyncio.gather(owner, return_exceptions=True)


if __name__ == "__main__":
    sys.exit(asyncio.run(run(Path(sys.argv[1]), sys.argv[2])) or 0)
